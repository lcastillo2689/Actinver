﻿const ApexChartController = (function () {
    let _elements = {
        apexChart: "#chartdiv",
        apexChartArea: "#chartdivArea",
        orga: null,
        yellow: [],
        red: [],
        green: [],
        blue: [],
        root: null,

        curvaActinver: "#1D7D9E",
        curvaArea: "#D4320E",
        lineaEmpleado1: "#FFFF00",
        lineaEmpleado2: "#FFFF00", 
        titulo1: "#1D7D9E",
        titulo2: "#D4320E",

        areaEnDesarrollo: "#DC2626",
        areaSatisfactorio: "#F87171",
        areaSobresaliente: "#A4C400",
        areaExcepcional: "#29B6F6",
    };

    const initApexChartControl = function (campanaActinver, campanaArea, empleado, estadisticas) {
        initApexChart(campanaActinver, campanaArea, empleado, estadisticas);
    };

    function initApexChart(campanaActinver, campanaArea, empleado, estadisticas) {
        let ct = "";
        switch (empleado.CalificacionTexto) {
            case "EX":
                ct = "Excepcional";
                break;
            case "SS":
                ct = "Sobresaliente";
                break;
            case "ST":
                ct = "Satisfactorio";
                break;
            case "DS":
                ct = "En Desarrollo";
                break;
            default:
        }

        var data = dataLoadApexChart(campanaActinver, campanaArea, empleado, estadisticas)
        console.log(data);
        var options = {
            chart: {
                zoom: {
                    enabled: false,
                },
                toolbar: {
                    show: false,
                },
                height: 300,
            },
            annotations: {
                yaxis: [],
                xaxis: [{
                    x: empleado.CalificacionTotal,
                    strokeDashArray: 0,
                    width: '100%',
                    borderColor: _elements.lineaEmpleado1,
                    label: {
                        borderColor: _elements.lineaEmpleado1,
                        style: {
                            fontSize: '1px',
                            color: _elements.lineaEmpleado1,
                            background: _elements.lineaEmpleado1,
                        },
                        offsetY: -20,
                        text: "########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ##########",
                    }
                }],
                points: [{
                    x: empleado.CalificacionTotal,
                    y: data.zEmpleadoActinver,
                    marker: {
                        size: 0,
                        fillColor: '#fff',
                        strokeColor: _elements.curvaActinver,
                        radius: 2,
                        cssClass: 'apexcharts-custom-class'
                    },
                    label: {
                        borderColor: _elements.curvaActinver,
                        offsetY: 0,
                        style: {
                            color: '#fff',
                            background: _elements.curvaActinver,
                        },
                    },
                    image: {
                    }
                }]
            },
            series: [{
                    name: 'En Desarrollo',
                    type: 'area',
                    data: data.zActinverED,
                stroke: {
                    curve: "straight",
                }
                }, {
                    name: 'Satisfactorio',
                    type: 'area',
                    data: data.zActinverST,
                    stroke: {
                        curve: "straight",
                    }
                }, {
                    name: 'Sobresaliente',
                    type: 'area',
                    data: data.zActinverSS,
                    stroke: {
                        curve: "straight",
                    }
                }, {
                    name: 'Excepcional',
                    type: 'area',
                    data: data.zActinverEX,
                    stroke: {
                        curve: "straight",
                    }
                },
            ],
            xaxis: {
                name: 'Calificacion',
                categories: data.calActinver,
                type: 'numeric', 
                labels: {
                    show: false,
                },
            },
            colors: [_elements.areaEnDesarrollo, _elements.areaSatisfactorio, _elements.areaSobresaliente, _elements.areaExcepcional, "#000000"],
            markers: {
                size: 0,
                hover: {
                    sizeOffset:.1
                }
            },
            stroke: {
                width:[3],
                curve: 'smooth', 
            },
            title: {
                text: "",
                style: {
                    fontSize: '14px',
                    fontWeight: 'bold',
                    color: "#000000",
                },
            },
            tooltip: {
                intersect: true,
                shared: false
            },
            theme: {
                palette: "palette1"
            },
        }
        var chart = new ApexCharts(document.querySelector(_elements.apexChart), options);
        chart.render();

        var optionsArea = {
            chart: {
                zoom: {
                    enabled: false,
                },
                toolbar: {
                    show: false,
                },
                height: 300,
                type: 'line'
            },
            annotations: {
                yaxis: [],
                xaxis: [{
                    x: empleado.CalificacionTotal,
                    strokeDashArray: 0,
                    borderColor: _elements.lineaEmpleado2,
                    label: {
                        borderColor: _elements.lineaEmpleado1,
                        style: {
                            fontSize: '1px',
                            color: _elements.lineaEmpleado2,
                            background: _elements.lineaEmpleado2,
                        },
                        offsetY: -20,
                        text: "########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ##########",
                    }
                }],
                points: [{
                    x: empleado.CalificacionTotal,
                    y: data.zEmpleadoArea,
                    marker: {
                        size: 0,
                        fillColor: '#fff',
                        strokeColor: _elements.curvaArea,
                        radius: 2,
                        cssClass: 'apexcharts-custom-class'
                    },
                    label: {
                        borderColor: _elements.curvaArea,
                        offsetY: 0,
                        style: {
                            color: '#fff',
                            background: _elements.curvaArea,
                        },
                    }
                }]
            },
            series: [{
                name: 'En Desarrollo',
                type: 'area',
                data: data.zAreaED,
                stroke: {
                    curve: "straight",
                }
            }, {
                    name: 'Satisfactorio',
                    type: 'area',
                    data: data.zAreaST,
                    stroke: {
                        curve: "straight",
                    }
                }, {
                    name: 'Sobresaliente',
                    type: 'area',
                    data: data.zAreaSS,
                    stroke: {
                        curve: "straight",
                    }
                }, {
                    name: 'Excepcional',
                    type: 'area',
                    data: data.zAreaEX,
                    stroke: {
                        curve: "straight",
                    }
                },
            ],
            yaxis: {
                min: 0,
            },
            xaxis: {
                name: 'Calificacion',
                categories: data.calArea,
                type: 'numeric',
                labels: {
                    show: false,
                },
            },
            colors: [_elements.areaEnDesarrollo, _elements.areaSatisfactorio, _elements.areaSobresaliente, _elements.areaExcepcional, "#000000"],
            markers: {
                size: 0,
                hover: {
                    sizeOffset: .1
                }
            },
            stroke: {
                width: [3],
                curve: 'smooth',
            },
            title: {
                text: "",
                style: {
                    fontSize: '14px',
                    fontWeight: 'bold',
                    color: "#000000",
                },
            },
            tooltip: {
                intersect: true,
                shared: false
            },
            theme: {
                palette: "palette1"
            },
        }
        var chartArea = new ApexCharts(document.querySelector(_elements.apexChartArea), optionsArea);
        chartArea.render();

        function dataLoadApexChart(campanaActinver, campanaArea, empleado, estadisticas) {
            console.log(campanaActinver);

            let arrApexChart = {
                calActinver: [],
                calActinverED: [],
                calActinverST: [],
                calActinverSS: [],
                calActinverEX: [],
                zActinver: [],
                zActinverED: [],
                zActinverST: [],
                zActinverSS: [],
                zActinverEX: [],
                calArea: [],
                calAreaED: [],
                calAreaST: [],
                calAreaSS: [],
                calAreaEX: [],
                zArea: [],
                zAreaED: [],
                zAreaST: [],
                zAreaSS: [],
                zAreaEX: [],
                calEmpleado: [],
                zEmpleado: [],
                zEmpleadoActinver: 0,
                zEmpleadoArea: 0,
            };

            console.log(empleado);

            arrApexChart.calActinver.push(1);
            arrApexChart.zActinver.push(0);
            arrApexChart.calEmpleado.push(1);
            arrApexChart.zEmpleado.push(0);

            arrApexChart.calActinverED.push(1);
            arrApexChart.zActinverED.push(0);

            arrApexChart.calActinverST.push(0);
            arrApexChart.zActinverST.push(null);

            arrApexChart.calActinverSS.push(0);
            arrApexChart.zActinverSS.push(null);

            arrApexChart.calActinverEX.push(0);
            arrApexChart.zActinverEX.push(null);

            $.each(campanaActinver, function () {
                switch (this.CalificacionTexto) {
                    case "DS":
                        arrApexChart.calActinverED.push(this.CalificacionTotal);
                        arrApexChart.zActinverED.push(this.Z);

                        arrApexChart.calActinverST.push(this.CalificacionTotal);
                        arrApexChart.zActinverST.push(this.Z);

                        arrApexChart.calActinverSS.push(this.CalificacionTotal);
                        arrApexChart.zActinverSS.push(null);

                        arrApexChart.calActinverEX.push(this.CalificacionTotal);
                        arrApexChart.zActinverEX.push(null);
                        break;
                    case "ST":
                        arrApexChart.calActinverED.push(this.CalificacionTotal);
                        arrApexChart.zActinverED.push(null);

                        arrApexChart.calActinverST.push(this.CalificacionTotal);
                        arrApexChart.zActinverST.push(this.Z);

                        arrApexChart.calActinverSS.push(this.CalificacionTotal);
                        arrApexChart.zActinverSS.push(this.Z);

                        arrApexChart.calActinverEX.push(this.CalificacionTotal);
                        arrApexChart.zActinverEX.push(null);
                        break;
                    case "SS":
                        arrApexChart.calActinverED.push(this.CalificacionTotal);
                        arrApexChart.zActinverED.push(null);

                        arrApexChart.calActinverST.push(this.CalificacionTotal);
                        arrApexChart.zActinverST.push(null);

                        arrApexChart.calActinverSS.push(this.CalificacionTotal);
                        arrApexChart.zActinverSS.push(this.Z);

                        arrApexChart.calActinverEX.push(this.CalificacionTotal);
                        arrApexChart.zActinverEX.push(this.Z);
                        break;
                    case "EX":
                        arrApexChart.calActinverED.push(this.CalificacionTotal);
                        arrApexChart.zActinverED.push(null);

                        arrApexChart.calActinverST.push(this.CalificacionTotal);
                        arrApexChart.zActinverST.push(null);

                        arrApexChart.calActinverSS.push(this.CalificacionTotal);
                        arrApexChart.zActinverSS.push(null);

                        arrApexChart.calActinverEX.push(this.CalificacionTotal);
                        arrApexChart.zActinverEX.push(this.Z);
                        break;
                    default:
                }

                arrApexChart.calActinver.push(this.CalificacionTotal); 
                arrApexChart.zActinver.push(this.Z);

                arrApexChart.calEmpleado.push(this.CalificacionTotal);
                arrApexChart.zEmpleado.push(null);
            });

            arrApexChart.calArea.push(1);
            arrApexChart.zArea.push(0);

            arrApexChart.calAreaED.push(1);
            arrApexChart.zAreaED.push(0);

            arrApexChart.calAreaST.push(0);
            arrApexChart.zAreaST.push(null);

            arrApexChart.calAreaSS.push(0);
            arrApexChart.zAreaSS.push(null);

            arrApexChart.calAreaEX.push(0);
            arrApexChart.zAreaEX.push(null);

            $.each(campanaArea, function () {
                switch (this.CalificacionTexto) {
                    case "DS":
                        arrApexChart.calAreaED.push(this.CalificacionTotal);
                        arrApexChart.zAreaED.push(this.Z);

                        arrApexChart.calAreaST.push(this.CalificacionTotal);
                        arrApexChart.zAreaST.push(this.Z);

                        arrApexChart.calAreaSS.push(this.CalificacionTotal);
                        arrApexChart.zAreaSS.push(null);

                        arrApexChart.calAreaEX.push(this.CalificacionTotal);
                        arrApexChart.zAreaEX.push(null);
                        break;
                    case "ST":
                        arrApexChart.calAreaED.push(this.CalificacionTotal);
                        arrApexChart.zAreaED.push(null);

                        arrApexChart.calAreaST.push(this.CalificacionTotal);
                        arrApexChart.zAreaST.push(this.Z);

                        arrApexChart.calAreaSS.push(this.CalificacionTotal);
                        arrApexChart.zAreaSS.push(this.Z);

                        arrApexChart.calAreaEX.push(this.CalificacionTotal);
                        arrApexChart.zAreaEX.push(null);
                        break;
                    case "SS":
                        arrApexChart.calAreaED.push(this.CalificacionTotal);
                        arrApexChart.zAreaED.push(null);

                        arrApexChart.calAreaST.push(this.CalificacionTotal);
                        arrApexChart.zAreaST.push(null);

                        arrApexChart.calAreaSS.push(this.CalificacionTotal);
                        arrApexChart.zAreaSS.push(this.Z);

                        arrApexChart.calAreaEX.push(this.CalificacionTotal);
                        arrApexChart.zAreaEX.push(this.Z);
                        break;
                    case "EX":
                        arrApexChart.calAreaED.push(this.CalificacionTotal);
                        arrApexChart.zAreaED.push(null);

                        arrApexChart.calAreaST.push(this.CalificacionTotal);
                        arrApexChart.zAreaST.push(null);

                        arrApexChart.calAreaSS.push(this.CalificacionTotal);
                        arrApexChart.zAreaSS.push(null);

                        arrApexChart.calAreaEX.push(this.CalificacionTotal);
                        arrApexChart.zAreaEX.push(this.Z);
                        break;
                    default:
                }
                arrApexChart.calArea.push(this.CalificacionTotal);
                arrApexChart.zArea.push(this.Z);

                if (this.CalificacionTotal == empleado.CalificacionTotal) {
                    arrApexChart.zEmpleadoArea = this.Z;
                }
            });

            var jsonString = JSON.stringify(arrApexChart);
            let jsonResult = JSON.parse(jsonString);
            return jsonResult;
        };

        _elements.root = chart;
        console.log('todo bien');
    }

    return {
        initApexChartControl,
        _elements
    };
})();