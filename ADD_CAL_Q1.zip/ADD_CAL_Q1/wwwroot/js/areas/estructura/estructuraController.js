﻿const EstructuraController = (function () {
    let _components = {
        modal: "#modal-employee",
        modalTitle: "#modal-employee-titulo",
        modalBody: "#modal-body-employee",

        divContentOrgChart: "#divOrgChart"
    };

    const initController = function () {
        getOrgChartView();
    };

    const initOrgChart = function (dataSource) {

        OrgChartController.initOrgChartControl(dataSource);
    };

    function getOrgChartView() {
        const success = function (response) {
            $(_components.divContentOrgChart).html(response);
        };

        const error = function (response) {
            ajaxErrorMessage(response);
        };

        EstructuraService.GetOrgChartView(success, error);
    }

    const configureModalEmployee = function (title, action, parameters) {
        debugger;
        $(_components.modalTitle).text(title);

        switch (action) {
            case "Detalle":
                let success = function (response) {
                    $(_components.modalBody).html(response);
                };

                let error = function (response) {
                    ajaxErrorMessage(response);
                };

                EstructuraService.GetEmployeeDetailView(parameters, success, error);

                $(_components.modal).modal('show');
                break;
            default:
        }

    }

    function addManager(nodeId) {
        chart.addNode({ id: OrgChart.randomId(), stpid: nodeId });
    }

    function nodePdfPreview(nodeId) {
        OrgChart.pdfPrevUI.show(chart, {
            format: 'A4',
            nodeId: nodeId
        });
    }
    return {
        initController,
        initOrgChart,
        configureModalEmployee
    }
})();