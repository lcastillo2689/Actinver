﻿const EstructuraController = (function () {
    let _components = {

        modal: "#modal-employee",
        modalTitle: "#modal-employee-titulo",
        modalBody: "#modal-body-employee",

        divContentOrgChart: "#divOrgChart",

        modalA: "#modal-avatar",
        modalATitle: "#modal-avatar-titulo",
        modalABody: "#modal-body-avatar",
    };

    const initController = function (cuId, av) {
        if (av != '') {
            getOrgChartView(cuId);
        }
        else {
            configureModalAvatar("Selecciona Avatar", "Avatar", getEmployeeParameters(cuId));
        }
    };

    function getEmployeeParameters(employeeId) {
        return {
            employeeId: employeeId
        }
    }

    const initOrgChart = function (employees) {
        OrgChartController.initOrgChartControl(employees);
    };

    function getOrgChartView(cuId) {
        const success = function (response) {
            OrgChartController.initOrgChartControl(response, cuId);
        };

        const error = function (response) {
            ajaxErrorMessage(response);
        };
        EstructuraService.GetOrgChartView(success, error);
    }

    const configureModalEmployee = function (title, action, parameters) {
        $(_components.modalTitle).text(title);

        switch (action) {
            case "Detalle":
                let success = function (response) {
                    $(_components.modalBody).html(response);
                };

                let error = function (response) {
                    ajaxErrorMessage(response);
                };
                EstructuraService.GetEmployeeDetailView(parameters, success, error);

                $(_components.modal).modal('show');
                break;
            default:
        }
    }

    const configureModalAvatar = function (title, action, parameters) {
        $(_components.modalATitle).text(title);

        switch (action) {
            case "Avatar":
                let success = function (response) {
                    $(_components.modalABody).html(response);
                };

                let error = function (response) {
                    ajaxErrorMessage(response);
                };
                EstructuraService.GetAvatarView(parameters, success, error);

                $(_components.modalA).modal('show');
                break;
            default:
        }
    }

    function addManager(nodeId) {
        chart.addNode({ id: OrgChart.randomId(), stpid: nodeId });
    }
    function nodePdfPreview(nodeId) {
        OrgChart.pdfPrevUI.show(chart, {
            format: 'A4',
            nodeId: nodeId
        });
    }
    return {
        initController,
        configureModalEmployee,
        configureModalAvatar
    }
})();