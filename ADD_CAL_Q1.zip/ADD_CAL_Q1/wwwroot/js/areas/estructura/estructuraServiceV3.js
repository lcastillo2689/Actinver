﻿const EstructuraService = (function () {
    let _url = `${window.location.origin}/Estructura/Organizacion`;

    const GetOrgChartView = function (success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/GetEmployeeOrgData`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const GetEmployeeDetailView = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/GetEmployeeDetailView`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const GetAvatarView = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/GetAvatarView`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };



    return {
        GetOrgChartView,
        GetEmployeeDetailView,
        GetAvatarView
    };
})();