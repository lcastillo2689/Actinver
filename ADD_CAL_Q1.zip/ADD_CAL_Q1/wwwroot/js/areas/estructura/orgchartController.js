﻿const OrgChartController = (function () {
    let _elements = {
        modal: "#modal-employee",
        modalTitle: "#modal-employee-titulo",
        modalBody: "#modal-body-employee",

        orgChart :  "orgchart"
    }

    const initOrgChartControl = function (dataSource) {
        initOrgChart(dataSource);
    }

    function initOrgChart(dataSource) {
        getOrgChartConfiguration();

        var chart = getOrgChartAttributes();

        dataLoadOrgChart(chart, dataSource)

        setOrgEvents(chart);
    }

    function getOrgChartConfiguration() {
        OrgChart.templates.group.link =
            '<path stroke-linejoin="round" stroke="#aeaeae" stroke-width="1px" fill="none" d="M{xa},{ya} {xb},{yb} {xc},{yc} L{xd},{yd}" />';
        OrgChart.templates.group.nodeMenuButton = "";
        OrgChart.templates.group.min = Object.assign(
            {},
            OrgChart.templates.group
        );
        OrgChart.templates.group.min.imgs = "{val}";
        OrgChart.templates.group.min.img_0 = "";
        OrgChart.templates.group.min.description =
            '<text data-width="230" data-text-overflow="multiline" style="font-size: 14px;" fill="#aeaeae" x="125" y="100" text-anchor="middle">{val}</text>';

        OrgChart.templates.ula.html =
            '<foreignobject style="pointer-events: none;" class="node" x="190" y="95" width="75" height="30">{val}</foreignobject>';

        OrgChart.templates.ula.nodeCircleMenuButton = {
            radius: 18,
            x: 250,
            y: 60,
            color: "#fff",
            stroke: "#aeaeae",
        };
    }

    function getOrgChartAttributes() {
        let chart = new OrgChart(document.getElementById(_elements.orgChart), {
            template: "ula",
            mouseScrool: OrgChart.action.none,
            nodeMouseClick: OrgChart.action.expandCollapse,
            enableDragDrop: true,
            nodeCircleMenu: getOrgMenu(),
            tags: getOrgTags(),

            collapse: {
                level: 2,
            },
            dragDropMenu: {
                addInGroup: { text: "Add in group" },
                addAsChild: { text: "Add as child" },
            },

            enableSearch: true,
            searchFields: ["fullName"],
            searchFieldsWeight: {
                name: 100,
            },
            nodeBinding: {
                field_0: "fullName",
                field_1: "title",
                img_0: "avatar",
                html: "html"
            },
        });

        OrgChart.loading.show(chart);

        return chart;
    }

    function getOrgTags() {
        return {
            overrideMenu: {
                addNode: {
                    icon: OrgChart.icon.user(24, 24, '#aeaeae'),
                    text: "Add node",
                    color: "white"
                },
                editNode: {
                    icon: OrgChart.icon.edit(24, 24, '#aeaeae'),
                    text: "Modificar",
                    color: "white"
                },
            }
        };
    }

    function getOrgMenu() {
        return {
            addNode: {
                icon: OrgChart.icon.user(24, 24, "#aeaeae"),
                text: "Detalle Empleado",
                color: "white"
            },
        };
    }

    function dataLoadOrgChart(orgChart, dataSource) {
        let arrOrganization = JSON.parse(dataSource);

        let arrOrgChart = [];

        $.each(arrOrganization, function () {
            arrOrgChart.push({
                id: this.empleadoId,
                pid: this.empleadoJefeId,
                fullName: this.nombreEmpleado,
                title: this.puestoDescripcion,
                avatar: this.avatar,
                html: "<span class='dot dotGreenActive'></span><span class='dot dotYellow'></span><span class='dot dotRed'></span>",
                //tags: (this.parentID > 0) ? ["overrideMenu"] : [""]
            });
        });

        var jsonString = JSON.stringify(arrOrgChart);
        let jsonResult = JSON.parse(jsonString);

        console.log(jsonResult);
        orgChart.load(jsonResult);
    }

    function setOrgEvents(chart) {
        chart.nodeCircleMenuUI.on("show", function (sender, args) {
            var node = chart.getNode(args.nodeId);

           
        });

        chart.nodeCircleMenuUI.on("click", function (sender, args) {
            console.log(args.menuItem.text);

            switch (args.menuItem.text) {
                case "Detalle Empleado":
                    {
                        let employeeId = args.nodeId;

                        EstructuraController.configureModalEmployee("Empleado", "Detalle", getEmployeeParameters(employeeId));
                    }
                    break;
                case "Modificar":
                    chart.editUI.show(args.nodeId);
                    break;

                default:
            }
        });

        chart.nodeCircleMenuUI.on('mouseenter', function (sender, args) {
            if (args.menuItem.text == "Remove node") {
                var node = document.querySelector('[data-n-id="' + args.from + '"]');
                node.style.opacity = 0.5;
            }
        });

        chart.nodeCircleMenuUI.on('mouseout', function (sender, args) {
            var node = document.querySelector('[data-n-id="' + args.from + '"]');
            node.style.opacity = 1;
        });

        chart.on('init', function (sender) {
            OrgChart.loading.hide(sender);
        });
    }

    function getEmployeeParameters(employeeId) {
        return {
            employeeId: employeeId
        }
    }
    
    return {
        initOrgChartControl
    };
})();