﻿const OrgChartController = (function () {
    let _elements = {
        orgChart: "orgchart",
        orga: null,
        yellow: [],
        endesarrollo: [],
        satisfactorios: [],
        sobresalientes: [],
        excepcionales: [],
        nodosExpandidos: [],
    };

    const initOrgChartControl = function (employees, cuId) {
        initOrgChart(employees, cuId);
    };

    function initOrgChart(employees, cuId) {
        getOrgChartConfiguration(cuId);
        var organigrama = getOrgChartAttributes(cuId);
        dataLoadOrgChart(organigrama, employees, cuId)

        setOrgEvents(organigrama, cuId);

        _elements.orga = organigrama;
    };

    function getOrgChartConfiguration(cuId) {
        OrgChart.templates.olivia.size = [350, 150];
        //OrgChart.templates.olivia.node = '<rect fill="url(#{randId})" x="0" y="0" height="{h}" width="{w}" stroke-width="0" stroke="#aeaeae" rx="7" ry="7"></rect>';

        OrgChart.templates.olivia.node = '<rect fill="url(#{randId})" x="0" y="0" height="{h}" width="{w}" stroke-width="0" stroke="#aeaeae" rx="20" ry="20"></rect>'
            //+ '<rect filter="url(#cool-shadow)"  x="0" y="0" height="190" width="310" fill="#ffffff" stroke-width="1" stroke="#eeeeee" rx="10" ry="10"></rect>'
            + '<rect fill="#ffffff" x="80" y="0" width="260" height="80" rx="10" ry="10" filter="url(#cool-shadow)"></rect>'//rec sup
            + '<rect stroke="#eeeeee" stroke-width="0" x="10" y="85" width="250" fill="#ffffff" rx="10" ry="10" height="60"></rect>'//rec inf izq
            + '<rect stroke="#eeeeee" stroke-width="0" x="265" y="85" width="80" fill="#ffffff" rx="10" ry="10" height="60"></rect>'//rec inf der
            //+ '<text  style="font-size: 11px;" fill="#afafaf" x="110" y="60">PERFORMANCE</text>'
            //+ '<image  xlink:href="https://cdn.balkan.app/shared/speedometer.svg" x="290" y="85" width="32" height="32"></image>'
            ;

        OrgChart.templates.olivia.plus = '<circle cx="15" cy="15" r="15" fill="#ffffff" stroke="#aeaeae" stroke-width="1"></circle>'
            + '<text text-anchor="middle" style="font-size: 18px;cursor:pointer;" fill="#757575" x="15" y="22">{collapsed-children-count}</text>';

        OrgChart.templates.olivia.img_0 = '<image preserveAspectRatio="xMidYMid meet" xlink:href="{val}" x="-15" y="-15" width="100" height="100"></image>';//slice meet
        OrgChart.templates.olivia.field_0 = '<text style="font-size: 18px;" fill="#757575" x="100" y="25" data-width="230" data-text-overflow="multiline">{val}</text>';//fullname
        OrgChart.templates.olivia.field_1 = '<text style="font-size: 14px;" fill="#90A4AE" x="100" y="100" data-width="180" data-text-overflow="multiline">{val}</text>';//title
        OrgChart.templates.olivia.field_2 = '<text style="font-size: 10px;" fill="#90A4AE" x="310" y="105" data-width="25">{val}</text>';//objetivos
        OrgChart.templates.olivia.field_3 = '<text style="font-size: 12px;" fill="#90A4AE" x="100" y="100" data-width="180">{val}</text>';
        OrgChart.templates.olivia.field_4 = '<text style="font-size: 10px;" fill="#90A4AE" x="280" y="110" data-width="180">{val}</text>';
        OrgChart.templates.olivia.html = '<foreignobject style="pointer-events: none;" class="node" x="265" y="115" width="125" height="30">{val}</foreignobject>';
        OrgChart.templates.olivia.svg = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="background-color:#F9F9F9;display:block;" width="{w}" height="{h}" viewBox="{viewBox}">{content}</svg>';

        OrgChart.templates.olivia.nodeMenuButton = "";

        OrgChart.templates.olivia.ripple = {
            radius: 20,
            color: "#e6e6e6",
            //rect: null
        };

        OrgChart.templates.olivia.nodeCircleMenuButton = {
            radius: 18,
            x: 350,
            y: 60,
            color: "#fff",
            stroke: "#aeaeae",
        };

    };

    function getOrgChartAttributes(cuId) {
        OrgChart.SEARCH_PLACEHOLDER = "Buscar"; // the default value is "Search"
        let chart = new OrgChart(document.getElementById(_elements.orgChart), {
            miniMap: false,
            toolbar: {
                layout: false,
                zoom: true,
                fullScreen:false
            },
            sticky: false,
            levelSeparation: 50,
            siblingSeparation: 50,
            subtreeSeparation:150,
            //mode: 'dark',
            //orientation: OrgChart.orientation.top_left,
            //layout: OrgChart.mixed,//normal,//treeRightOffset,//tree,//
            //padding: 0,
            //scaleInitial: .7,//OrgChart.match.boundary,//OrgChart.match.height,
            template: "olivia",//"ula",//
            //mouseScrool: OrgChart.action.xScroll, //scroll,
            //showYScroll: OrgChart.scroll.visible,
            //showXScroll: OrgChart.scroll.visible,
            nodeMouseClick: OrgChart.action.expandCollapse,
            //enableDragDrop: false,//true,//
            nodeCircleMenu: getOrgMenu(),
            tags: getOrgTags(),

            dragDropMenu: {
                addInGroup: { text: "Add in group" },
                addAsChild: { text: "Add as child" },
            },

            enableSearch: true,
            searchFields: ["fullName"],
            searchDisplayField: ["fullName"],
            searchFieldsWeight: {
                name: 100,
            },
            //filterBy: 'all',
            nodeBinding: {
                //imgs: "avatar",
                img_0: "avatar",
                field_0: "fullName", //"NombreCompleto",//
                field_1: "title",
                field_2: "objetivos",
                field_3: "area",
                field_4: "calificacionTexto",
                field_5: "aquiEstoy",
                html: "html"
            },
            linkBinding:
            {
                link_field_0: "",//"fechaAlta"
            },
            collapse: {
                level: 2,
                allChildren: true,
                columns: 5
            },
            expand: {
                nodes: [cuId],
                allChildren : false
            }
            //roots: rr//[532, 2030]
        });

        chart.on('searchclick', function (sender, nodeId) {
            chart.center(nodeId, {}, function () {
                let n = chart.getNode(nodeId);
                chart.expand(nodeId, n.childrenIds);

                _elements.nodosExpandidos.push(nodeId);
                //chart.magnify(nodeId, 1.25, true, null);
                //chart.ripple(nodeId, 50, 100);
                chart.searchUI.hide();
            });


            return false;
        });
        
        OrgChart.loading.show(chart);
        return chart;
    }

    function dataLoadOrgChart(orgChart, dataSource, cuId) {
        let arrOrgChart = [];

        $.each(dataSource, function () {
            let av = "";
            if (this.Avatar == null || this.Avatar == undefined) {
                av = "../../../images/av/user.png";
            }
            else {
                av = '../../../images/av/' + this.Avatar;
            }

            let amarilloAgregado = false;
            const d1 = new Date();
            const d2 = new Date(this.FechaAlta);
            const dif1 = Math.abs(d1 - d2);
            const dif2 = Math.ceil(dif1 / (1000 * 60 * 60 * 24));
            if (dif2 < 60) {
                _elements.yellow.push(this.EmpleadoId);
                amarilloAgregado = true;
            }

            let calTexto = '';
            switch (this.CalificacionTexto) {
                case 'EX':
                    calTexto = 'Excepcional';
                    _elements.excepcionales.push(this.EmpleadoId);
                    break;
                case 'SS':
                    calTexto = 'Sobresaliente';
                    _elements.sobresalientes.push(this.EmpleadoId);
                    break;
                case 'ST':
                    calTexto = 'Satisfactorio';
                    _elements.satisfactorios.push(this.EmpleadoId);
                    break;
                case 'DS':
                    calTexto = 'En Desarrollo';
                    _elements.endesarrollo.push(this.EmpleadoId);
                    break;
                default:
                    calTexto = 'Pendiente';
                    if (!amarilloAgregado) {
                        _elements.yellow.push(this.EmpleadoId);
                    }
            }
            arrOrgChart.push({
                id: this.EmpleadoId,//NumeroEmpleado,//empleadoId,//
                pid: this.EmpleadoJefeId,
                //stpid: this.Nivel == 2 ? this.NumeroEmpleadoJefe : "",
                fullName: this.NombreEmpleado,//nombreEmpleado,//
                avatar: av,
                title: this.PuestoDescripcion,//puestoDescripcion,
                //objetivos: "5/5",
                fechaAlta: new Date(this.FechaAlta).toLocaleDateString('es-mx', { day: "numeric", month: "short", year: "numeric" }),
                antig: dif2,
                calificacionTotal: this.CalificacionTotal,
                calificacionTexto: calTexto,
                html: (dif2 < 60 || this.CalificacionTexto == 'PD' ? "<span class='dot2 dotRed'></span><span class='dot2 dotRedLight'></span><span class='dot2 dotGreen'></span><span class='dot2 dotBlue'></span>"
                    : (this.CalificacionTexto == 'EX' ? "<span class='dot2 dotRed'></span><span class='dot2 dotRedLight'></span><span class='dot2 dotGreen'></span><span class='dot2 dotBlueActive'></span>" : //azul
                        (this.CalificacionTexto == 'SS' ? "<span class='dot2 dotRed'></span><span class='dot2 dotRedLight'></span><span class='dot2 dotGreenActive'></span><span class='dot2 dotBlue'></span>"//verde
                            : (this.CalificacionTexto == 'ST' ? "<span class='dot2 dotRed'></span><span class='dot2 dotRedLightActive'></span><span class='dot2 dotGreen'></span><span class='dot2 dotBlue'></span>"//rojoLight
                                : "<span class='dot2 dotRedActive'></span><span class='dot2 dotRedLight'></span><span class='dot2 dotGreen'></span><span class='dot2 dotBlue'></span>")))),//rojo
                tags: this.CalificacionTexto == 'EX' ? ["tagDepEX"] : ["tagDep99"],//[this.Color],//clTag,
                //tags: (this.Nivel === 1 ? ["tagDep01b"]
                //        : (this.Nivel === 2 ? ["tagDep02b"]
                //            : (this.Nivel === 3 ? ["tagDep03b"]
                //                : (this.Nivel === 4 ? ["tagDep04b"]
                //                    : (this.Nivel === 5 ? ["tagDep05b"]
                //                        : (this.Nivel === 6 ? ["tagDep06b"] : [""]))))))
                //tags: (this.parentID > 0) ? ["overrideMenu"] : [""]
            });

            if (this.EmpleadoId == cuId) {
                //AddSlink(orgChart, this.EmpleadoJefeId, this.EmpleadoId, "Aquí estoy");
            }
        });
        var jsonString = JSON.stringify(arrOrgChart);
        let jsonResult = JSON.parse(jsonString);
        orgChart.load(jsonResult);
    };

    function AddSlink(chart, from, to, label, template) {
        chart.addSlink(from, to, label, template);
    }

    function AddClink(chart, from, to, label, template) {
        chart.addClink(from, to, label, template);
    }

    function getOrgTags() {
        return {
            overrideMenu: {
                addNode: {
                    icon: OrgChart.icon.user(24, 24, '#aeaeae'),
                    text: "Add node",
                    color: "white"
                },
                editNode: {
                    icon: OrgChart.icon.edit(24, 24, '#aeaeae'),
                    text: "Modificar",
                    color: "white"
                },
                AvatarNode: {
                    icon: OrgChart.icon.edit(24, 24, '#aeaeae'),
                    text: "Actualizar",
                    color: "yellow"
                },
            },
            filter:
            {
                template: 'dot'
            }
        };
    }

    function getOrgMenu() {
        return {
            addNode: {
                icon: OrgChart.icon.user(24, 24, "#aeaeae"),
                text: "Detalle Empleado",
                color: "white"
            },
        };
    }

    function setOrgEvents(chart, cuId) {
        chart.nodeCircleMenuUI.on("click", function (sender, args) {

            switch (args.menuItem.text) {
                case "Detalle Empleado":
                    {
                        let periodo = moment('2022-01-01').format('YYYY-MM-DD');
                        let employeeId = args.nodeId;
                        EstructuraController.configureModalEmployee("Detalle del Colaborador", "Detalle", getEmployeeParameters(periodo, employeeId));
                    }
                    break;
                default:
            }
        });
    }

    function testBasicChart(employees) {

        var organigrama = new OrgChart(document.getElementById(_elements.orgChart), {

            nodeBinding: {
                field_0: "fullName",
                field_1: "id"
            },
            collapse: {
                level: 1,
                allChildren: true,
                columns: 5
            },
        });


        let arrOrgChart = [];

        $.each(employees, function () {
            arrOrgChart.push({
                id: this.NumeroEmpleado,
                spid: this.NumeroEmpleadoJefe,
                fullName: this.NombreEmpleado,
                avatar: this.avatar,
                html: "<span class='dot dotGreenActive'></span><span class='dot dotRed'></span>",
                title: "Mi Puesto",
            });
        });


        var jsonString = JSON.stringify(arrOrgChart);
        let jsonResult = JSON.parse(jsonString);
        organigrama.load(jsonResult);
    };

    function getEmployeeParameters(periodo, employeeId) {
        return {
            periodo: periodo,
            employeeId: employeeId
        }
    }
    
    function getAvatarParameters(employeeId) {
        return {
            periodo: periodo,
            avatar: ''
        }
    }

    return {
        initOrgChartControl,
        _elements
    };
})();