﻿const AutoevaluacionController = function () {
    let _evaluacionService = null;
    let formObjetivos = null;

    //#region Models
    function getObjetivoModel(objetivoID) {
        return {
            objetivoId: objetivoID
        }
    }

    function getObjetivoCalificacionModel(objetivoCalificacionID) {
        return {
            objetivoCalificacionId: objetivoCalificacionID,
            empleadoId: $(EvaluacionComponentes.Evaluacion.txtHiddenEempleado).val()
        }
    }

    function getObjetivoCalificaiconModel() {
        let evaluacionId = $(EvaluacionComponentes.Evaluacion.txtHiddenEvaluacion).val();
        let objetivoId = $(EvaluacionComponentes.Evaluacion.txtHiddenObjetivo).val();
        let resultadoObjetivo = $(EvaluacionComponentes.Evaluacion.txtResultadoObjetivo).val();
        let objetivoCalificacionId = $(EvaluacionComponentes.Evaluacion.txtHiddenID).val();
        let ponderacion = $(EvaluacionComponentes.Evaluacion.txtPonderacionObjetivo).val();

        return {
            ID: objetivoCalificacionId,
            EvaluacionId: evaluacionId,
            ObjetivoId: objetivoId,
            Resultado: resultadoObjetivo,
            Ponderacion: ponderacion
        }
    }

    function getPeriodo() {
        return 1;
    }

    function getRateModel(objetivoCalificacionID, rate) {
        return {
            objetivoCalificacionId: objetivoCalificacionID,
            calificacion: rate
        }
    }

    function getEvaluacionModel() {
        return {
            evaluacionId: $(EvaluacionComponentes.Evaluacion.txtHiddenEvaluacion).val(),
            empleadoId: $(EvaluacionComponentes.Evaluacion.txtHiddenEempleado).val()
        }
    }
    //#endregion 

    //#region ObjetivoListView
    const InitObjetivosColaboradores = function (objetivos) {

        initAccionesObjetivos(objetivos);
        initRatingControl(objetivos);
        iniEvaluacionActions();
    }

    function initAccionesObjetivos(objetivos) {
        $.each(objetivos, function () {
            let btnEditObjetivo = EvaluacionComponentes.Evaluacion.btnEditObjetivo + this.ObjetivoId;
            let btnResultadosClave = EvaluacionComponentes.Evaluacion.btnResultadosClave + this.ObjetivoId;


            $(btnEditObjetivo).on('click', function (e) {
                e.preventDefault();
                //let objetivoId = $(this).attr(EvaluacionComponentes.EvaluacionAtributos.objetivo);
                let objetivoCalificacionID = $(this).attr(EvaluacionComponentes.EvaluacionAtributos.Id);

                editObjetivo(objetivoCalificacionID);
            });

            $(btnResultadosClave).on('click', function (e) {
                e.preventDefault();
                debugger;
                let objetivoId = $(this).attr(EvaluacionComponentes.EvaluacionAtributos.objetivo);

                showModalResultadoClave(objetivoId);
            });

            tippy(btnEditObjetivo, { theme: "light", animation: "scale", placement: "bottom", inertia: true });

            tippy(btnResultadosClave, { theme: "light", animation: "scale", placement: "bottom", inertia: true });
        });
    }

    const InitDetalleResultadosClave = function () {

        $("#btn-kr-Card-back").on('click', function (e) {
            e.preventDefault();

            $(EvaluacionComponentes.Evaluacion.divDetalleKR).slideUp(1500);

            setTimeout(() => {
                $(EvaluacionComponentes.Evaluacion.divTarjetasOKR).slideDown(1500);

            }, 1000);


        });
    }

    function initRatingControl(objetivos) {
        var dynamic = [
            //responsive options
            { min: 0, max: 320, fontSize: 8, gap: 1, size: 20 },
            { min: 321, max: 600, fontSize: 10, gap: 2, size: 40 },
            { min: 601, max: 768, fontSize: 12, gap: 4, size: 50 },
        ];

        $.each(objetivos, function () {
            let rateControl = EvaluacionComponentes.Evaluacion.objetivoRate + this.ObjetivoId;

            WowRating.run(rateControl, {
                responsive: dynamic,
                ratingMin: 1,
                ratingMax: 4,
                type: "Wow",
                gap: 5,
                size: 32,
                rate: this.Calificacion,
                shape: 'RoundedStarRed',
                secondShape: 'RoundedStarYellow',
                firstColor: "white",
                secondColor: "yellow",
                animationSpeed: 200,
                showLabel: false,
                fontSize: 16,
                labelWelcomeText: "",
                onRate: function (rate) {
                    let objetivoId = $(this.type.$).attr(EvaluacionComponentes.EvaluacionAtributos.objetivo);

                    let objetivoCalificacionId = $(this.type.$).attr(EvaluacionComponentes.EvaluacionAtributos.Id);

                    rateObjetivo(objetivoCalificacionId, rate);

                }
            });
        });
    }

    function rateObjetivo(objetivoCalificacionId, rate) {

        let success = function (response) {

            if (response.rateSuccess) {
                toastr.success("¡La información ha sido guardada correctamente!");
                getResultadoView();
            }
            else
                toastr.error("¡Se ha presentado un error al calificar el objetivo!");
        }

        let error = function (response) {
            ajaxErrorMessage(response);
        }

        _evaluacionService.RateObjetivo(getRateModel(objetivoCalificacionId, rate), success, error);
    }

    function iniEvaluacionActions() {
        $(EvaluacionComponentes.Evaluacion.btnGuardarTemporal).on('click', function (e) {
            e.preventDefault();
            toastr.success("¡La información ha sido guardada correctamente!");
        });

        $(EvaluacionComponentes.Evaluacion.btnEnviarRevision).on('click', function (e) {
            e.preventDefault();

            confirmationMessage("¡Al enviar a Revisión tu evaluación, ya no podrás modificarla! <br /><br />¿Deseas continuar?", () => {
                e.preventDefault();
                enviarARevision();
            });
        });

        $(EvaluacionComponentes.Evaluacion.btnFinalizar).on('click', function (e) {
            e.preventDefault();
            confirmationMessage("¡La evaluación será finalizada! <br /><br />¿Deseas continuar?", () => {
                e.preventDefault();
                finalizarEvaluacion();
            });

        });

        $(EvaluacionComponentes.Evaluacion.btnAutoevaluacion).on('click', function () {
            let empleadoId = $(this).attr(EvaluacionComponentes.EvaluacionAtributos.empleado);

            getAutoevaluacionColaboradorView(empleadoId);
        });
    }

    function finalizarEvaluacion() {

        let success = function (response) {

            if (!response.revisionSuccess && !response.evaluacionValida && !response.error)
                modalMessage("error", "Error", "<span>La evaluación no puede ser finalizada</span><br /><span>Debes calificar todos los objetivos</span><br /><span>Describir el resultado del objetivo</span><br /><span>La ponderación (peso) de los objetivos debe sumar 100</span>");

            else if (response.revisionSuccess)
                modalMessage("success", "¡Muy Bien!", "La evaluación ha sido finalizada", function () {
                    window.close();
                });
            else
                toastr.error("¡Se ha presentado al finalizar tu evaluación!");
        }

        let error = function (response) {
            ajaxErrorMessage(response);
        }

        _evaluacionService.FinalizarEvaluacion(getEvaluacionModel(), success, error);
    }

    function enviarARevision() {

        let success = function (response) {

            if (!response.revisionSuccess && !response.evaluacionValida && !response.error)
                modalMessage("error", "Error", "<span>La evaluación no puede ser enviada a revisión</span><br /><span>Debes calificar todos los objetivos</span><br /><span>Describir el resultado del objetivo</span><br /><span>La ponderación (peso) de los objetivos debe sumar 100</span>");
            else if (response.revisionSuccess)
                getEvaluacion();
            else
                toastr.error("¡Se ha presentado al enviar a Revisión tu evaluación!");
        }

        let error = function (response) {
            ajaxErrorMessage(response);
        }

        _evaluacionService.SendToRevision(getEvaluacionModel(), success, error);
    }


    //#endregion

    //#region EvaluacionView
    const InitAutoevaluacionController = function (evaluacionService) {
        _evaluacionService = evaluacionService;

        validateObjetivosParaEvaluacion();

        //getEvaluacion();

        iniEvaluacionActions();

    }

    const InitEvaluacionColaborador = function () {
        updatePesoTotalObejtivos();
    }

    const InitEvaluacionFinalizada = function () {
        clearPesoObjetivos();
    }

    function getEvaluacion() {
        Loading.Show();

        let success = function (response) {
            $(EvaluacionComponentes.Evaluacion.evaluacionContainer).html('');
            $(EvaluacionComponentes.Evaluacion.evaluacionContainer).html(response);
            Loading.Hide();
        }

        let error = function (response) {
            Loading.Hide();
            ajaxErrorMessage(response);
        }

        _evaluacionService.GetEvaluacionView(getPeriodo(), success, error);
    }

    function getResultadoView(objetivoID) {
        Loading.Show();

        let success = function (response) {
            $(EvaluacionComponentes.Evaluacion.resultadosCalificacionContainer).html('');
            $(EvaluacionComponentes.Evaluacion.resultadosCalificacionContainer).html(response);
            iniEvaluacionActions();

            Loading.Hide();
        }

        let error = function (response) {
            Loading.Hide();
            ajaxErrorMessage(response);
        }

        _evaluacionService.GetResultadoView(getEvaluacionModel(), success, error);
    }

    function updatePesoTotalObejtivos() {

        let success = function (response) {
            $(EvaluacionComponentes.Evaluacion.subHeaderLayoutContainer).html("")
            $(EvaluacionComponentes.Evaluacion.subHeaderLayoutContainer).html(response);
        }

        let error = function (response) {
            ajaxErrorMessage(response);
        }

        let evaluacionId = $(EvaluacionComponentes.Evaluacion.txtHiddenEvaluacion).val();
        _evaluacionService.UpdatePesoTotalObejtivos(evaluacionId, success, error);
    }

    function clearPesoObjetivos() {

        let success = function (response) {
            $(EvaluacionComponentes.Evaluacion.subHeaderLayoutContainer).html("")
            $(EvaluacionComponentes.Evaluacion.subHeaderLayoutContainer).html(response);
        }

        let error = function (response) {
            ajaxErrorMessage(response);
        }

        _evaluacionService.ClearPesoTotalObejtivos(success, error);
    }

    function getAutoevaluacionColaboradorView(empleadoId) {
        Loading.Show();

        let success = function (response) {
            Loading.Hide();
            let url = `${window.location.origin}/Evaluacion/Autoevaluacion/AutoevaluacionEmpleadoRevision`;
            window.open(url)
        };

        let error = function (response) {
            Loading.Hide();
            ajaxErrorMessage(response);
        };

        param = {
            empleadoId: empleadoId
        };

        _evaluacionService.VerAutoevaluacionRevision(param, success, error);
    }

    function validateObjetivosParaEvaluacion() {
        Loading.Show();

        let success = function (response) {
            $(EvaluacionComponentes.Evaluacion.evaluacionContainer).html('');
            $(EvaluacionComponentes.Evaluacion.evaluacionContainer).html(response);
            Loading.Hide();
        };

        let error = function (response) {
            Loading.Hide();
            ajaxErrorMessage(response);
        };

        _evaluacionService.ValidarObjetivosAprobados(success, error);
    }

    //#endregion

    //#region ObjetivoVew

    const InitObjetivoView = function () {
        initObjetivoFormValidaciones();
        initObjetivoFormActions();
    }

    function editObjetivo(objetivoCalificacionID) {
        Loading.Show();

        let success = function (response) {
            $(EvaluacionComponentes.Evaluacion.modalObjetivoContainer).html('');
            $(EvaluacionComponentes.Evaluacion.modalObjetivoContainer).html(response);

            Loading.Hide();
        }

        let error = function (response) {
            Loading.Hide();
            ajaxErrorMessage(response);
        }

        _evaluacionService.GetObjetivoView(getObjetivoCalificacionModel(objetivoCalificacionID), success, error);
    }

    function initObjetivoFormValidaciones() {
        formObjetivos = FormValidation.formValidation(
            document.getElementById(EvaluacionComponentes.Evaluacion.frmObjetivo),
            {
                fields: {
                    "txt-ResultadoObjetivo": {
                        validators: {
                            notEmpty: {
                                message: 'Requerido'
                            },
                            stringLength: {
                                min: 50,
                                max: 500,
                                message: 'Por favor ingresa una descripción con longitud mínima de 50 caracteres'
                            }
                        }
                    },

                    "txt-PonderacionObjetivo": {
                        validators: {
                            notEmpty: {
                                message: 'Requerido'
                            },
                            integer: {
                                decimalSeparator: '',
                                decimalSeparator: '.',
                                message: 'Por favor ingresa una Ponderación (peso) a tu objetivo válida.'
                            },
                            lessThan: {
                                max: 100,
                                message: 'El valor de la Ponderación (peso) no puede ser mayor a 100%'
                            }
                        }
                    },
                },

                plugins: {
                    trigger: new FormValidation.plugins.Trigger(),
                    bootstrap: new FormValidation.plugins.Bootstrap(),
                    submitButton: new FormValidation.plugins.SubmitButton(),
                    defaultSubmit: new FormValidation.plugins.DefaultSubmit(),
                }
            },
        );
    }

    function initObjetivoFormActions() {
        $(EvaluacionComponentes.Evaluacion.btnGuardarObjetivo).on('click', function (e) {
            e.preventDefault();
            formObjetivos.validate().then(function (status) {
                if (status === 'Invalid')
                    return false;

                if (status === 'Valid')
                    saveResultadoObjetivo();
            });
        });
    }

    function saveResultadoObjetivo() {
        Loading.Show();

        let success = function (response) {

            $(EvaluacionComponentes.Evaluacion.objetivosEvaluacionContainer).html('');
            $(EvaluacionComponentes.Evaluacion.objetivosEvaluacionContainer).html(response);

            $(EvaluacionComponentes.Evaluacion.modalObjetivo).modal('hide');

            updatePesoTotalObejtivos();

            Loading.Hide();

            toastr.success("¡La información ha sido guardada correctamente!");
        }

        let error = function (response) {
            Loading.Hide();
            ajaxErrorMessage(response);
        }

        _evaluacionService.SaveObjetivoResultado(getObjetivoCalificaiconModel(), success, error);
    }

    function showModalResultadoClave(objetivoId) {
        Loading.Show();

        let success = function (response) {
            $(EvaluacionComponentes.Evaluacion.divTarjetasOKR).html('');
            $(EvaluacionComponentes.Evaluacion.divTarjetasOKR).html(response);

            $(EvaluacionComponentes.Evaluacion.divDetalleKR).slideUp(0);

            $(EvaluacionComponentes.Evaluacion.modalResultadoClave).modal('show');

            setTimeout(() => {
                $(EvaluacionComponentes.Evaluacion.divTarjetasOKR).slideDown(1000);

            }, 1000);

            Loading.Hide();
        }

        let error = function (response) {
            Loading.Hide();
            ajaxErrorMessage(response);
        }

        _evaluacionService.GetResultadoClaveView(getObjetivoModel(objetivoId), success, error);
    }

    //#endregion

    //#region Revisión Evaluación
    const InitAutoevaluacionRevisionController = function (evaluacionService, empleadoId) {
        _evaluacionService = evaluacionService;

        getEvaluacionRevision(empleadoId);

        iniEvaluacionActions();
    }

    function getEvaluacionRevision(empleadoID) {
        Loading.Show();

        let success = function (response) {
            $(EvaluacionComponentes.Evaluacion.evaluacionContainer).html('');
            $(EvaluacionComponentes.Evaluacion.evaluacionContainer).html(response);
            Loading.Hide();
        }

        let error = function (response) {
            Loading.Hide();
            ajaxErrorMessage(response);
        }

        let model = {
            empleadoId: empleadoID
        };

        _evaluacionService.GetEvaluacionRevisionView(model, success, error);
    }
    //#endregion

    return {
        InitAutoevaluacionController,
        InitObjetivosColaboradores,
        InitObjetivoView,
        InitAutoevaluacionRevisionController,
        InitEvaluacionColaborador,
        InitEvaluacionFinalizada,
        InitDetalleResultadosClave
    };
}();