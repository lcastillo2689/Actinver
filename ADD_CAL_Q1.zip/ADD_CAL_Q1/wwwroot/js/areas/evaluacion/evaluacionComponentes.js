﻿const EvaluacionComponentes = (function () {

    const Evaluacion = {
        //Containers
        evaluacionContainer: "#evaluacionContainer",
        modalObjetivoContainer: "#modal-objetivoEvaluacion-body",
        modalResultadoClaveContainer: "#modal-resultadoClave-body",
        objetivosEvaluacionContainer: "#objetivos-Evaluacion-Container",
        subHeaderLayoutContainer: "div.sub-HeaderContainer",
        resultadosCalificacionContainer: "#container-Resultados",
        divTarjetasOKR: "#divTarjetasKR",
        divDetalleKR: "#divDetalleKR",

        //Buttons
        btnEditObjetivo: "#btnEditObjetivo-",
        btnGuardarObjetivo: "#btn-GuardarObjetivo",
        btnGuardarTemporal: "#btn-GuardarEvaluacion",
        btnEnviarRevision: "#btn-RevisionEvaluacion",
        btnFinalizar: "#btn-FinalizarEvaluacion",
        btnAutoevaluacion: "#btn-VerAutoevaluacion",
        btnResultadosClave: "#btnKR-",

        //Components
        objetivoRate: "#objetivoRating-",

        //Modals
        modalObjetivo: "#modal-objetivoEvaluacion",
        modalResultadoClave: "#modal-resultadoClave",

        //Inputs
        txtResultadoObjetivo: "#txt-ResultadoObjetivo",
        txtPonderacionObjetivo: "#txt-PonderacionObjetivo",

        //Input hidden
        txtHiddenEvaluacion: "#EvaluacionId",
        txtHiddenObjetivo: "#ObjetivoId",
        txtHiddenEempleado: "#EmpleadoId",
        txtHiddenID: "#ID",



        //Forms
        frmObjetivo: "frm-Objetivo"
    };

    const Retroalimentacion = {
        //Forms
        frmAceptacionCalificacion: "frm-AceptacionCalificacion",
        frmCuestiosnarioRetroalimentacion: "frm-CuestionarioRetroalimentacion",

        //containers
        divFinalizarRetro: "#divFinalizarRetro",

        //Buttons
        btnRetroAcuerdo: "#btnRetroAcuerdo",
        btnRetroNoAcuerdo: "#btnRetroNoAcuerdo",
        btnEnviarRetro: "#btnEnviarRetro",
        btnReunionRelizada: "#btnReunionRelizada",
        btnReunionNoRelizada: "#btnReunionNoRelizada",
        btnCerrarRetro: "#btnCerrarRetro",


        //Labels
        spanRetroAcuerdo: "#spanRetroAcuerdo",
        spanRetroNoAcuerdo: "#spanRetroNoAcuerdo",
        spanReunionRealizada: "#spanReunionRealizada",
        spanReunionNoRealizada: "#spanReunionNoRealizada",

        //inputs
        txtComentarioAceptacionCalificacion: "#txtComentariosRetro",
        txtCompromisosEmpleado: "#txtCompromisosEmpleado",
        txtnecesidadesEmpleado: "#txtNecesidadesEmpleado"

    }

    const EvaluacionAtributos = {
        Id: "data-Id",
        objetivo: "data-Objetivo",
        evaluacion: "data-evaluacion",
        empleado: "data-empleado"
    }

    return {
        Evaluacion,
        EvaluacionAtributos,
        Retroalimentacion
    }
})();
