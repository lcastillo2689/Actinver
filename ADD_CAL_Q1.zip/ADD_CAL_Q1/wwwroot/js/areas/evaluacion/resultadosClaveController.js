﻿const ResutadoClaveController = function () {

    //#region Models
    function getResultadoClaveModel(resultadoClaveId) {
        return {
            resultadoClaveId: resultadoClaveId
        }
    }
    //#endregion


    let InitKewResultView = function (krSource){
        jQuery.each(krSource, function () {
            let controlName = ElementosComunesOKR.ResultadoClaveElements.cardPartialControlName + this;
            let controlTooltip = ElementosComunesOKR.ResultadoClaveElements.cardPartialBtnDetailDescriptionName + this;

            $(controlName).on('click', function (e) {
                e.preventDefault();
                let resultadoClaveId = $(this).attr(ElementosComunesOKR.ResultadoClaveElements.cardDataKRID);
                showDetailKR(resultadoClaveId);
            });

            tippy(controlTooltip, { allowHTML: true, theme: "light", animation: "scale", placement: "top", inertia: true, maxWidth: 600 });
        });

        $(EvaluacionComponentes.Evaluacion.divDetalleKR).slideUp(0);
    }

    function showDetailKR(resultadoClaveId) {
        Loading.Show();

        let success = function (response) {
            $(EvaluacionComponentes.Evaluacion.divDetalleKR).html('');
            $(EvaluacionComponentes.Evaluacion.divDetalleKR).html(response);

            $(EvaluacionComponentes.Evaluacion.modalResultadoClave).modal('show');

            Loading.Hide();

            $(EvaluacionComponentes.Evaluacion.divTarjetasOKR).slideUp(1500);

            setTimeout(() => {
                $(EvaluacionComponentes.Evaluacion.divDetalleKR).slideDown(1500);

            }, 1000);
        }

        let error = function (response) {
            Loading.Hide();
            ajaxErrorMessage(response);
        }

        EvaluacionService.GetDetalleResultadoClaveView(getResultadoClaveModel(resultadoClaveId), success, error);

     
    }

    return {
        InitKewResultView
    }
}();