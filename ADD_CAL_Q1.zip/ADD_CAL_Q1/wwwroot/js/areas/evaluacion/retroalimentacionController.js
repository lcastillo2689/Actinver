﻿const RetroalimentacionController = function () {
    let _evaluacionService = null;
    let _retroalimentacionAcordada = null;


    let _estadoRetro = {
        retroAcordada: null,
        reunionConLider: null
    }

    let formAceptacionCalificacion = null;
    let formCuestionarioRetroalimentacion = null;


    //#region Model
    function getAceptacionCalificacionModel(retroCerrada) {

        let model = {

            EvaluacionAcordada: _estadoRetro.retroAcordada,
            Comentarios: $(EvaluacionComponentes.Retroalimentacion.txtComentarioAceptacionCalificacion).val(),
            Cerrada: retroCerrada,
            Compromisos: $(EvaluacionComponentes.Retroalimentacion.txtCompromisosEmpleado).val(),
            Necesidades: $(EvaluacionComponentes.Retroalimentacion.txtnecesidadesEmpleado).val(),
        };

        return model;
    }
    //#endregion

    const InitRetroalimentacionController = function (evaluacionService) {
        _evaluacionService = evaluacionService;
        getRetroalimentacionEvaluacion();

    };

    function getRetroalimentacionEvaluacion() {
        Loading.Show();

        let success = function (response) {
            $(EvaluacionComponentes.Evaluacion.evaluacionContainer).html('');
            $(EvaluacionComponentes.Evaluacion.evaluacionContainer).html(response);
            Loading.Hide();
        }

        let error = function (response) {
            Loading.Hide();
            ajaxErrorMessage(response);
        }

        _evaluacionService.GetEvaluacionRetroalimentacionView(success, error);
    }


    //#region Aceptacion Calificacion
    const InitAceptacionCalificacionController = function () {
        initAceptacionCalificacionActions();
        initObjetivoFormValidaciones();
        toogleOpinionEvaluacion(null);
    };

    function initAceptacionCalificacionActions() {
        $(EvaluacionComponentes.Retroalimentacion.btnRetroAcuerdo).click(function (e) {
            e.preventDefault();
            toogleOpinionEvaluacion(true);
        });

        $(EvaluacionComponentes.Retroalimentacion.btnRetroNoAcuerdo).on('click', function (e) {
            e.preventDefault();
            toogleOpinionEvaluacion(false);

        });

        $(EvaluacionComponentes.Retroalimentacion.btnEnviarRetro).click(function (e) {
            if (validateRetroAcordada()) {
                formAceptacionCalificacion.validate().then(function (status) {

                    if (status === 'Invalid')
                        return false;

                    if (status === 'Valid')
                        solicitarRetro(false);
                });
            }
        });
    }


    function initObjetivoFormValidaciones() {
        formAceptacionCalificacion = FormValidation.formValidation(
            document.getElementById(EvaluacionComponentes.Retroalimentacion.frmAceptacionCalificacion),
            {
                fields: {
                    "txtComentariosRetro": {
                        validators: {
                            notEmpty: {
                                message: 'Requerido'
                            },
                            stringLength: {
                                min: 20,
                                max: 500,
                                message: 'Por favor ingresa una descripción con longitud mínima de 20 caracteres'
                            }
                        }
                    },
                },

                plugins: {
                    trigger: new FormValidation.plugins.Trigger(),
                    bootstrap: new FormValidation.plugins.Bootstrap(),
                    submitButton: new FormValidation.plugins.SubmitButton(),
                    defaultSubmit: new FormValidation.plugins.DefaultSubmit(),
                }
            },
        );
    }

    function validateRetroAcordada() {
        if (_estadoRetro.retroAcordada === null) {
            modalMessage(
                "warning",
                "Atención",
                "Selecciona una opción sobre tu evaluación.",
                () => { }
            );

            return false;
        }

        return true;
    }

    function solicitarRetro(retroCerrada) {
        if (retroCerrada === false) {
            let model = getAceptacionCalificacionModel(retroCerrada);

            let success = function (response) {

                modalMessage(
                    "info",
                    "Importante",
                    "<span>Acuerda un espacio con tu líder para recibir retroalimentación sobre tu <strong>Evaluación Trimestral de OKR's 2022.</strong></span><br /> <span>Una vez concluida, deberás regresar a <strong>CERRAR</strong> la retroalimentación en esta misma plataforma.</span>",
                    () => {
                        window.location.reload();
                    }
                );


            };

            let error = function (response) {
                ajaxErrorMessage(response);
            };

            _evaluacionService.SaveRetroalimentacion(model, success, error);
        }
    }
    //#endregion

    //#region Reunion Lider
    const InitCuestionarioRetroalimentacion = function (retroalimentacionAcordada) {
        _retroalimentacionAcordada = retroalimentacionAcordada

        initCuestionarioFormActions();
        initAceptacionCalificacionActions();
        initCuestionarioFormValidaciones();
        toogleReunionConLider(null);
        toogleOpinionEvaluacion(null);
    }

    function initCuestionarioFormActions() {
        $(EvaluacionComponentes.Retroalimentacion.btnReunionRelizada).on('click', function (e) {
            e.preventDefault();
            toogleReunionConLider(true);

        });

        $(EvaluacionComponentes.Retroalimentacion.btnReunionNoRelizada).on('click', function (e) {
            e.preventDefault();
            toogleReunionConLider(false);
            modalMessage(
                "info",
                "Importante",
                "Reúnete con tu líder para recibir retroalimentación."
            );
        });

        $(EvaluacionComponentes.Retroalimentacion.btnCerrarRetro).on('click', function (e) {
            e.preventDefault();

            if (validateFinalizarRetro()) {
                formCuestionarioRetroalimentacion.validate().then(function (status) {

                    if (status === 'Invalid')
                        return false;

                    if (status === 'Valid')
                        finalizarRetro(true);

                });
            };
        });

    }

    function finalizarRetro(retroCerrada) {
        if (retroCerrada === true) {
            let model = getAceptacionCalificacionModel(retroCerrada);

            let success = function (response) {
                modalMessage(
                    "success",
                    "¡Excelente!",
                    "¡Muchas gracias!, has concluido el proceso de retroalimentación de tu Evaluación Trimestral de OKR's 2022. La información permanecerá aquí para que puedas consultarla más adelante.",
                    () => {
                        window.location.reload();
                    }
                );
            };

            let error = function (response) {
                ajaxErrorMessage(response);
            };

            _evaluacionService.SaveRetroalimentacion(model, success, error);
        }
    }



    function initCuestionarioFormValidaciones() {
        formCuestionarioRetroalimentacion = FormValidation.formValidation(
            document.getElementById(EvaluacionComponentes.Retroalimentacion.frmCuestiosnarioRetroalimentacion),
            {
                fields: {
                    "txtcompromisosEmpleado": {
                        validators: {
                            notEmpty: {
                                message: 'Requerido'
                            },
                            stringLength: {
                                min: 20,
                                max: 500,
                                message: 'Por favor ingresa una descripción con longitud mínima de 20 caracteres'
                            }
                        }
                    },
                    "txtnecesidadesEmpleado": {
                        validators: {
                            notEmpty: {
                                message: 'Requerido'
                            },
                            stringLength: {
                                min: 20,
                                max: 500,
                                message: 'Por favor ingresa una descripción con longitud mínima de 20 caracteres'
                            }
                        }
                    },
                },

                plugins: {
                    trigger: new FormValidation.plugins.Trigger(),
                    bootstrap: new FormValidation.plugins.Bootstrap(),
                    submitButton: new FormValidation.plugins.SubmitButton(),
                    defaultSubmit: new FormValidation.plugins.DefaultSubmit(),
                }
            },
        );
    }

    function validateFinalizarRetro() {
        if (_retroalimentacionAcordada === false && _estadoRetro.retroAcordada === null) {

            modalMessage(
                "warning",
                "Atención",
                "Selecciona una nueva opción sobre tu evaluación.",
                () => { }
            );

            return false;
        }

        if (_retroalimentacionAcordada === true && _estadoRetro.retroAcordada === null)
            _estadoRetro.retroAcordada = true;

        return true;
    }
    //#endregion

    //#region Retroalimnetacin Finalizada
    const InitEvaluacionCerrada = function (retroalimentacionAcordada) {
        toogleOpinionEvaluacion(retroalimentacionAcordada);
    }
    //#endregion

    //#region Tooggle
    function toogleOpinionEvaluacion(estado) {

        _estadoRetro.retroAcordada = estado;

        if (estado === null) {

            $(EvaluacionComponentes.Retroalimentacion.btnRetroAcuerdo).addClass('seleccionOff');
            $(EvaluacionComponentes.Retroalimentacion.spanRetroAcuerdo).addClass('svg-icon-seleccionOff');
            $(EvaluacionComponentes.Retroalimentacion.btnRetroNoAcuerdo).addClass('seleccionOff');
            $(EvaluacionComponentes.Retroalimentacion.spanRetroNoAcuerdo).addClass('svg-icon-seleccionOff');

        }


        if (estado === true) {

            $(EvaluacionComponentes.Retroalimentacion.btnRetroAcuerdo).removeClass('seleccionOff');
            $(EvaluacionComponentes.Retroalimentacion.spanRetroAcuerdo).removeClass('svg-icon-seleccionOff');
            $(EvaluacionComponentes.Retroalimentacion.btnRetroNoAcuerdo).addClass('seleccionOff');
            $(EvaluacionComponentes.Retroalimentacion.spanRetroNoAcuerdo).addClass('svg-icon-seleccionOff');


        }

        if (estado === false) {

            $(EvaluacionComponentes.Retroalimentacion.btnRetroAcuerdo).addClass('seleccionOff');
            $(EvaluacionComponentes.Retroalimentacion.spanRetroAcuerdo).addClass('svg-icon-seleccionOff');
            $(EvaluacionComponentes.Retroalimentacion.btnRetroNoAcuerdo).removeClass('seleccionOff');
            $(EvaluacionComponentes.Retroalimentacion.spanRetroNoAcuerdo).removeClass('svg-icon-seleccionOff');
        }

    }

    function toogleReunionConLider(estado) {

        _estadoRetro.reunionConLider = estado;

        if (estado === null) {
            $(EvaluacionComponentes.Retroalimentacion.divFinalizarRetro).hide();
            $(EvaluacionComponentes.Retroalimentacion.btnReunionRelizada).addClass('seleccionOff');
            $(EvaluacionComponentes.Retroalimentacion.spanReunionRealizada).addClass('svg-icon-seleccionOff');
            $(EvaluacionComponentes.Retroalimentacion.btnReunionNoRelizada).addClass('seleccionOff');
            $(EvaluacionComponentes.Retroalimentacion.spanReunionNoRealizada).addClass('svg-icon-seleccionOff');

        }


        if (estado === true) {
            $(EvaluacionComponentes.Retroalimentacion.divFinalizarRetro).show();
            $(EvaluacionComponentes.Retroalimentacion.btnReunionRelizada).removeClass('seleccionOff');
            $(EvaluacionComponentes.Retroalimentacion.spanReunionRealizada).removeClass('svg-icon-seleccionOff');
            $(EvaluacionComponentes.Retroalimentacion.btnReunionNoRelizada).addClass('seleccionOff');
            $(EvaluacionComponentes.Retroalimentacion.spanReunionNoRealizada).addClass('svg-icon-seleccionOff');
        }

        if (estado === false) {
            $(EvaluacionComponentes.Retroalimentacion.divFinalizarRetro).hide();
            $(EvaluacionComponentes.Retroalimentacion.btnReunionRelizada).addClass('seleccionOff');
            $(EvaluacionComponentes.Retroalimentacion.spanReunionRealizada).addClass('svg-icon-seleccionOff');
            $(EvaluacionComponentes.Retroalimentacion.btnReunionNoRelizada).removeClass('seleccionOff');
            $(EvaluacionComponentes.Retroalimentacion.spanReunionNoRealizada).removeClass('svg-icon-seleccionOff');
        }
    }
    //#endregion

    return {
        InitRetroalimentacionController,
        InitAceptacionCalificacionController,
        InitCuestionarioRetroalimentacion,
        InitEvaluacionCerrada
    };
}();