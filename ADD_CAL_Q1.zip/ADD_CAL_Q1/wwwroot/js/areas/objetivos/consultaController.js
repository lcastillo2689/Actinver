﻿const ConsultaController = (function () {

    const _quarterPickerSelector = "#quarter-picker";

    const _gridEmpleadosEstatusSelectores = {
        grid: "#gridEmpleadosEstatus",
        btnExportar: "#btn-exportar-empleados-estatus",
        txtQuery: "#txt-query-empleados-estatus",
        btnBuscar: "#btn-query-empleados-estatus"
    };

    const InitEmpleados = function() {
        setTimeout(() => {
            ConfigureDatePickers();
            setEvents();
        }, 0);
    };

    function GetCurrentDateForQuarterPicker() {
        const currentDate = new Date();
        const initDate = new Date(2022, 0, 1);

        if (currentDate <= initDate)
            return initDate;

        const firstQuarterMonth = 3;
        const secondQuarterMonth = 6;
        const thirdQuarterMonth = 9;

        const currentMonth = currentDate.getMonth() + 1;

        if (currentMonth <= firstQuarterMonth)
            return new Date(currentDate.getFullYear(), 0, 1);

        if (currentMonth <= secondQuarterMonth)
            return new Date(currentDate.getFullYear(), 1, 1);

        if (currentMonth <= thirdQuarterMonth)
            return new Date(currentDate.getFullYear(), 2, 1);

        return new Date(currentDate.getFullYear(), 3, 1);
    }

    function ConfigureDatePickers() {
        const currentDate = new Date();
        const initDate = new Date(2022, 0, 1);
        const maxDate = new Date(2022, 0, 2);

        let monthArray = [
            "Ene&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Feb&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Mar",
            "Abr&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;May&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Jun",
            "Jul&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ago&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sep",
            "Oct&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nov&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dic",
            "", "", "", "", "", "", "", ""];

        $.fn.datepicker.dates['qtrs'] = {
            days: ["Sunday", "Moonday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
            daysShort: ["Sun", "Moon", "Tue", "Wed", "Thu", "Fri", "Sat"],
            daysMin: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
            months: ["Q1", "Q2", "Q3", "Q4", "", "", "", "", "", "", "", ""],
            monthsShort: monthArray,
            //today: "Today",
            clear: "Clear",
            format: "mm/dd/yyyy",
            titleFormat: "MM yyyy",
            /* Leverages same syntax as 'format' */
            weekStart: 0
        };

        $(_quarterPickerSelector).datepicker({
            format: "MM yyyy",
            minViewMode: 1,
            autoclose: true,
            language: "qtrs",
            forceParse: false,
            startDate: initDate,
            endDate: maxDate
        }).on("show", function (event) {
            $(".month").each(function (index, element) {
                if (index > 3) $(element).hide();
            });
        }).on('changeDate', function () {
            TablesController.ReloadGrid(_gridEmpleadosEstatusSelectores.grid);
        });

        $(_quarterPickerSelector).datepicker("setDate", GetCurrentDateForQuarterPicker());
    }

    function setEvents() {
        $(_gridEmpleadosEstatusSelectores.btnBuscar).on("click", function () {
            TablesController.ReloadGrid(_gridEmpleadosEstatusSelectores.grid);
        });
    }

    const GetGridEmpleadosEstatusData = function () {
        const periodo = $(_quarterPickerSelector).datepicker("getDate");
        return {
            periodo: formatQueryStringDateObject(periodo),
            query: $(_gridEmpleadosEstatusSelectores.txtQuery).val()
        };
    };

    const OnDataBoundEmpleadoEstatus = function (e) {
        const dataSource = TablesController.GetDataSource(_gridEmpleadosEstatusSelectores.grid);
        setToolbarTotales("#GridEmpleadosEstatusToolbarTemplate", dataSource);
        TablesController.SetRightPage(_gridEmpleadosEstatusSelectores.grid);
    }

    function setToolbarTotales(selector, dataSource) {
        const aggregateResult = dataSource._aggregateResult;
        const conteoObjetivos = aggregateResult["ConteoObjetivos"] ? aggregateResult["ConteoObjetivos"].sum : 0;
        let conteoObjetivosLabel = `${formatThousandSeparatorNumber(conteoObjetivos, 0)}`;
        $(`#lbl-objetivos-totales`).html(conteoObjetivosLabel);

        const conteoResultadosClave = aggregateResult["ConteoResultadosClave"] ? aggregateResult["ConteoResultadosClave"].sum : 0;
        let conteoResultadosClaveLabel = `${formatThousandSeparatorNumber(conteoResultadosClave, 0)}`;
        $(`#lbl-resultado-clave-totales`).html(conteoResultadosClaveLabel);

    }


    return {
        InitEmpleados,
        GetGridEmpleadosEstatusData,
        OnDataBoundEmpleadoEstatus
    };

})();