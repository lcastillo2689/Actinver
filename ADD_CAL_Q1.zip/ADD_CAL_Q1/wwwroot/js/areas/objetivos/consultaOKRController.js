﻿const ConsultaOKRController = (function () {

    const InitObjetivo = function (model) {
        const btnToggleMostrarKPIsSelector = `${ElementosComunesOKR.ObjetivoElements.btnToggleMostrarKPIsPartialID}${model.objetivoID}`;
        $(btnToggleMostrarKPIsSelector).on("click", function () {
            const objetivoID = $(this).attr('data-obtetivo-id');
            const containerKPIsSelector = `${ElementosComunesOKR.ObjetivoElements.containerKPIsPartialID}${objetivoID}`;
            const toggleState = $(containerKPIsSelector).attr('data-toggle-state');
            if (toggleState === 'hide') {
                $(containerKPIsSelector).slideDown(1000);
                $(containerKPIsSelector).attr('data-toggle-state', 'show');
                $(this).val("Ocultar KPI's del objetivo");
            }
            else {
                $(containerKPIsSelector).slideUp(1000);
                $(containerKPIsSelector).attr('data-toggle-state', 'hide');
                $(this).val("Mostrar KPI's del objetivo");
            }
        });
    }

    const InitTarjetasKR = function (okrSource) {
        InitControlKR(okrSource);
    }

    function InitControlKR(krSource) {

        jQuery.each(krSource, function () {
            let controlName = "#card-okr-consulta-data-" + this;
            let controlTooltip = "#btn-detailDescription-consulta-" + this;            

            $(controlName).on('click', function (e) {                
                e.preventDefault();
                let resultadoClaveId = $(this).attr(ElementosComunesOKR.ResultadoClaveElements.cardDataKRID);
                let trimestre = $(this).attr("data-quarter-id");
                editResultadoClave(resultadoClaveId, trimestre);
            });

            tippy(controlTooltip, { allowHTML: true, theme: "light", animation: "scale", placement: "top", inertia: true, maxWidth: 600 });
        });
    }

    function editResultadoClave(resultadoClaveId, trimestre) {
        let krId = resultadoClaveId;
        let success = function (response) {
            $("#modal-okr-titulo-consulta").text('Resultado Clave');
            $("#modal-body-okr-consulta").html(response);
        };

        let error = function (response) {
            ajaxErrorMessage(response);
        };

        let krParam = {
            resultadoClaveId: krId
        };
        

        if (trimestre > 0) {
            const periodoOKR = $(ElementosComunesOKR.PeriodoEvaluacionElements.yearPickerSelector).datepicker("getDate");
            krParam.year = periodoOKR.getFullYear();
            krParam.quarter = trimestre;
            PeriodosCongeladosService.ReadKeyResultFreezedView(krParam, success, error);
        }
        else {
            ConsultaOKRService.GetKRUpdateView(krParam, success, error)
        }        
    }

    const InitConsultaRC = function () {

        $(document).off('hidden.bs.modal');
        $(document).on('hidden.bs.modal', '.modal',
            () => $('.modal:visible').length && $(document.body).addClass('modal-open'));

    }

    const InitParticipantes = function () {
        tippy(ElementosComunesOKR.ParticipantesElements.participantesDetailDescriptionClass, { allowHTML: true, theme: "light", animation: "scale", placement: "top", inertia: true, maxWidth: 600 });
    };

    return {
        InitObjetivo,
        InitTarjetasKR,
        InitConsultaRC,
        InitParticipantes
    };
})();