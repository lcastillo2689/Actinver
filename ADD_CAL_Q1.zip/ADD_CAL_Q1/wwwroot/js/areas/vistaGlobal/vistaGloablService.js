﻿const VistaGloablService = (function () {
    let _url = `${window.location.origin}/Objetivos/VistaGlobal`;

    const ExportObjetivos = function (periodo) {
        debugger;
        window.location.href = `${_url}/ExportaExcel?periodo=${periodo}`;
    };
    const ValidarObjetivosAprobados = function (periodo, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/ValidarObjetivosAprobados?${periodo}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    }

    return {
        ExportObjetivos,
        ValidarObjetivosAprobados
    }
})();