(function ($) {
    const _breadcrumbWrapperClass = "breadcrumb-wrapper";
    const _breadcrumbStyle = "color: rgb(89, 89, 89)";
    const _breadcrumbClass = "col-md-12";
    const _liLevelClass = "li-lvl-";
    const _linkLevelClass = "bc-link-lvl-";

    let _showHideSpeed = 2000;
    let _maxLevel = 5;
    let _levelDiference = 0;

    const _template = `
        <div class="${_breadcrumbWrapperClass}" style="">
            <div class="row">
                <ul class="breadcrumb" style="margin-bottom: 3px;">
                    
                </ul>
            </div>
        </div>`;

    const _itemTemplate = `
        <li class="{id}" style="{style}">
            <a href="#" class="{linkId} data-level={level}">
                <span class="text">{name}</span>
            </a>
        </li>`;

    $.fn.breadcrumb = function (options, level) {
        if (options === "showLevel") {
            showLevel(this, level - _levelDiference);
            return this;
        }

        if (options === "hideLevel") {
            hideLevel(this, level - _levelDiference);
            return this;
        }

        if (options === "setMaxLevel") {
            _maxLevel = level;
            return this;
        }

        let settings = $.extend(
            {
                showHideSpeed: _showHideSpeed,
                class: _breadcrumbClass,
                style: _breadcrumbStyle,
                items: [],
            },
            options
        );

        setInitialStructure(this, settings);
        addItems(this, settings.items);
        setEvents(this, settings.items);

        return this;
    };

    function showLevel(breadcrumb, level) {
        const breadcrumbId = getBreadcrumbId(breadcrumb);
        const count = getItemsCount(breadcrumb);

        if (level < 1) return;
        if (level > count) return;

        for (let i = 1; i <= level; i++) {
            const selector = `#${breadcrumbId} > .${_breadcrumbWrapperClass} ul li.${getLiClass(i)}`;
            $(selector).show(_showHideSpeed);
        }
    }

    function hideLevel(breadcrumb, level) {
        const breadcrumbId = getBreadcrumbId(breadcrumb);
        const count = getItemsCount(breadcrumb);

        if (level < 1) return;
        if (level > count) return;

        for (let i = count; i >= level; i--) {
            const selector = `#${breadcrumbId} > .${_breadcrumbWrapperClass} ul li.${getLiClass(i)}`;
            $(selector).hide(_showHideSpeed);
        }
    }

    function setEvents(breadcrumb, items) {
        const breadcrumbId = getBreadcrumbId(breadcrumb);
        const count = getItemsCount(breadcrumb);

        for (let i = 0; i < count; i++) {
            const selector = `#${breadcrumbId} > .${_breadcrumbWrapperClass} ul li.${getLiClass(i + 1)}`;
            $(selector).on("click", function (e) {
                e.preventDefault();
                hideLevel(breadcrumb, i + 2);
                if (isFunction(items[i].onClick)) items[i].onClick();
            });
        }
    }

    function getBreadcrumbId(breadcrumb) {
        return breadcrumb.attr("id");
    }

    function getItemsCount(breadcrumb) {
        const breadcrumbId = getBreadcrumbId(breadcrumb);
        const itemsSelector = `#${breadcrumbId} > .${_breadcrumbWrapperClass} li`;
        return $(itemsSelector).length;
    }

    function addItems(breadcrumb, items) {
        let itemsHtml = "";

        _levelDiference = _maxLevel - items.length;

        for (let i = items.length - 1; i >= 0; i--) {
            const item = items[i];
            itemsHtml += getItemHtml(item, i);
        }

        const breadcrumbId = getBreadcrumbId(breadcrumb);
        const selector = `#${breadcrumbId} > .${_breadcrumbWrapperClass} ul`;
        $(selector).html(itemsHtml);
    }

    function getItemHtml(item, index) {
        let html = _itemTemplate;
        const style = index > 0 ? "display: none;" : "";

        const level = index + 1;
        html = html.replace("{id}", getLiClass(level));
        html = html.replace("{style}", style);
        html = html.replace("{linkId}", getLinkClass(level));
        html = html.replace("{level}", level);
        html = html.replace("{name}", item.name);

        return html;
    }

    function getLiClass(index) {
        return `${_liLevelClass}${index}`;
    }

    function getLinkClass(index) {
        return `${_linkLevelClass}${index}`;
    }

    function setInitialStructure(breadcrumb, settings) {
        _showHideSpeed = settings.showHideSpeed;

        breadcrumb.addClass("row");

        const breadcrumbId = getBreadcrumbId(breadcrumb);
        breadcrumb.html(_template);

        const selector = `#${breadcrumbId} > .${_breadcrumbWrapperClass}`;
        $(selector).addClass(settings.class);
        $(selector).attr("style", settings.style);
    }

    function isFunction(functionToCheck) {
        return functionToCheck && {}.toString.call(functionToCheck) === "[object Function]";
    }
})(jQuery);
