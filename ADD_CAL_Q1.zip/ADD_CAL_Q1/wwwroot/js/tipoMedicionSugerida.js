﻿const TipoMediconSugerida = (function () {

    const _btnSelector = '#btn-tipo-medicion-sugerida';
    const _txtSelector = '#txt-tipo-medicion-sugerida';
    const _popoverInvitacion = '#popover-sugerencia-indicador';
    const _iconSugerirIndidor = '#icon-header-nuevo-indicador';

    const Init = function () {

        $(_btnSelector).click(() => SendTipoMedicionSugerida() );

        $(_iconSugerirIndidor).click(() => localStorage.setItem('clickSugiereIndicador', 'true') );

        let aDadoClicEnSugerirIndicador = localStorage.getItem('clickSugiereIndicador');

        if (aDadoClicEnSugerirIndicador == null || aDadoClicEnSugerirIndicador !== 'true') {
            $(_popoverInvitacion).popover('show');
            setTimeout(function () {
                $(_popoverInvitacion).popover('dispose')
            }, 5000);
        }

        tippy(`#icon-header-nuevo-indicador, #icon-header-sugerencias`, { theme: "light", animation: "scale", placement: "bottom", inertia: true });


    };

    function SendTipoMedicionSugerida() {
        if (!ValidateTxt())
            return;

        let model = {
            MediconSugerida: $(_txtSelector).val()
        };

        const success = function () {
            $(_txtSelector).val("");
            modalMessage("success", "Éxito", 'En breve revisaremos tu solicitud.');
        };

        const error = function (response) {
            ajaxErrorMessage(response);
        };


        CallService(model, success, error)
    }

    function ValidateTxt() {
        if ($(_txtSelector).val() == "") {
            modalMessage("error", "Error", 'Debes colocar la descripción del tipo de medición que sugieres.');
            return false;
        }

        return true;
    }

    function CallService(model, success, error) {
        const _url = `${window.location.origin}/Catalogos/TiposMedicion/Sugerencia`;
        $.ajax({
            datatype: "json",
            data: model,
            type: "POST",
            url: _url,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    }


    return {
        Init
    };

})();