﻿const DownloadsController = (function (fileDownloadCheckTimer) {
    const fileDownloadToken = "fileDownloadToken";
    const BlockUiForDownload = function (tokenSelector) {
        GestorDocumentalApp.Loading.Show();

        const token = new Date().getTime();
        if (tokenSelector) $(tokenSelector).val(token);

        fileDownloadCheckTimer = window.setInterval(function () {
            const cookieValue = $.cookie(fileDownloadToken);
            if (cookieValue == token) finishDownload();
        }, 300);

        return token;
    };

    function finishDownload() {
        window.clearInterval(fileDownloadCheckTimer);
        $.removeCookie(fileDownloadToken);
        GestorDocumentalApp.Loading.Hide();
    }

    return {
        BlockUiForDownload,
    };
})();
