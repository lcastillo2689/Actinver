﻿const FirmaDigitalController = function () {

    const _tiposDocumento = {
        solicitudTrabajo: 1,
        cartaCompromiso: 2,
        convenioServicios: 3,
        convenioBanco: 4,
        convenioCasaBolsa: 5,
    }

    let _dataSelected = {
        documentoTipoID: -1,
        documentoNombre: '',
        firmaID: -1,
        permitirFirma: false
    }

    let _elements = {

        //containers
        divAuditoria: "#div-auditoria",
        divDrawImage: "#draw-image",
        divDrawImageElement: "draw-image",
        divDrawImageLine: "#draw-image-line",
        divBodyDocument: "#divBodyDocument",
        divPreviewDocument:"#divPreviewDocument",

        //canvas
        canvanFirma: "#canvas",

        //Buttons
        btnFinalizarFirma: "#btn-finalizar-firmar",
        btnLimpiarFirma: "#btn-limpiar",
        btnImprimir: "##btn-imprimir",
        btnsSignature: ".btnSignature",
        btnCancelarFirma : "#btnCancelarFirma",
        btnsDownload: ".btnDownload",
        btnPreviewCerrar: "#btnPreviewCerrar",
        btnPreviewEnviar: "#btnPreviewEnviar",
        btnMisDocumentos: "#btnMisDocumentos",

        //text
        lblFecha: "#fecha",

        //modal
        modalFirmaLabel:"#modalFirmaLabel",
        modalFirma: "#modal-firma",
        modalFirmaBody: "#model-general-content",
        modalPreview: "#divPreview",
        modalPrincipal: "#divPrincipal",

    }

    let _dataAttributes = {
        documentoTipoID: "data-tipoDocumentoID",
        firmaID: "data-firmaID",
        permitirFirma: "data-permitirFirma"
    };

    let _properties = {
        colorPincel: "black",
        backgroundColor: "white",
        lineHeigth: 2,
        xReal: (clientX) => clientX - canvas.getBoundingClientRect().left,
        yReal: (clientY) => clientY - canvas.getBoundingClientRect().top,
    }

    let xAnterior = 0, yAnterior = 0, xActual = 0, yActual = 0;

    let comienzaDibujo = false;

    let InitFirmaController = function (documento) {

        _dataSelected.documentoTipoID = documento.documentoTipoID;
        _dataSelected.documentoNombre = documento.documentoNombre;

        const canvas = document.querySelector(_elements.canvanFirma);
        const contexto = canvas.getContext("2d");
        const drawImage = document.getElementById(_elements.divDrawImageElement);

        $(_elements.modalFirmaLabel).html(_dataSelected.documentoNombre);

        formEvents(canvas, drawImage, contexto);

    };

    let InitCartaCompromisoController = function () {

        getCartasCompromiso();

    }

    function InitCatDocumentosTipo() {

        $(_elements.btnsSignature).on("click", function () {

            _dataSelected.permitirFirma = $(this).attr(_dataAttributes.permitirFirma);
            _dataSelected.documentoTipoID = $(this).attr(_dataAttributes.documentoTipoID);

            if (_dataSelected.documentoTipoID == _tiposDocumento.cartaCompromiso && _dataSelected.permitirFirma == "false") {
                modalMessage("warning", "Documentos Trabajo Flexible", "Primero debes firmar la Solicitud de Trabajo Remoto", null);
                return;
            }
            else {
                GetFirmaDocumentosView();
            }
            

        });

        $(_elements.btnsDownload).on("click", function () {

            _dataSelected.firmaID = $(this).attr(_dataAttributes.firmaID);
                        
            $("#downFirmaID").attr("value", _dataSelected.firmaID);
            $("#btnDownloadGlobalFile").click();

        });

    }

    function InitFirmaDocumento() {

        $(_elements.btnCancelarFirma).on("click", function () {
            ResetModal();
        });

        $(_elements.btnPreviewCerrar).on("click", function () {
            $(_elements.modalPrincipal).toggle();
            $(_elements.modalPreview).toggle();
            $(_elements.divPreviewDocument).html('');
        });

        $(_elements.btnPreviewEnviar).on("click", function () {
            saveFirma();
        });

        $(".solicitudInputText").on("keyup", function () {
            let valueText = $(this).val();
            $(this).attr("value", valueText);
        });

    }

    function ResetModal() {

        let success = function (response) {

            $(_elements.modalFirmaBody).html('');
            $(_elements.modalFirmaBody).html(response);

            InitCatDocumentosTipo();

        }

        let error = function (response) {
            ajaxErrorMessage(response);
        }

        firmaDigitalService.GetCartasCompromisoView(success, error);

    };

    function getCartasCompromiso() {

        let success = function (response) {

            $(_elements.modalFirmaBody).html('');
            $(_elements.modalFirmaBody).html(response);
            $(_elements.modalFirma).modal('show');

            InitCatDocumentosTipo();

        }

        let error = function (response) {
            ajaxErrorMessage(response);
        }

        firmaDigitalService.GetCartasCompromisoView(success, error);
    }

    function formEvents(canvas, drawImage, contexto) {

        $(_elements.btnFinalizarFirma).attr("disabled", true);

        $(_elements.btnLimpiarFirma).on("click", function () {

            contexto.fillStyle = _properties.backgroundColor;
            contexto.fillRect(0, 0, canvas.width, canvas.height);

            drawImage.setAttribute("src", "");
            $(_elements.canvanFirma).show();
            $(_elements.divDrawImage).hide();
            $(_elements.btnFinalizarFirma).show();
            $(_elements.btnFinalizarFirma).attr("disabled", true);

        });

        $(_elements.btnFinalizarFirma).on("click", function () {

            if (validateData() === false) {
                return;
            }


            $(".solicitudInputRadio").each(function () {

                $(this).removeAttr("checked");
                let isChecked = $(this).is(":checked");
                if (isChecked == true)
                {
                    $(this).attr("checked", "checked");
                }

            });

            
            let cmbArea = document.getElementById("cmbAreaEmpleado");
            
            $(".optionArea").each(function () {

                $(this).removeAttr("selected");
                let valueOption = $(this).attr("value");

                if (cmbArea.value == valueOption)
                {
                    $(this).attr("selected", "selected");
                }
                
            });


            let cmbEstadoCivil = document.getElementById("cmbEmpleadoEstadoCivil");

            $(".optionEstadoCivil").each(function () {

                $(this).removeAttr("selected");
                let valueOption = $(this).attr("value");

                if (cmbEstadoCivil.value == valueOption) {
                    $(this).attr("selected", "selected");
                }

            });

            showDocumentoPreview();

        });

        canvas.addEventListener("mousedown", evento => {
            xAnterior = xActual;
            yAnterior = yActual;
            xActual = _properties.xReal(evento.clientX);
            yActual = _properties.yReal(evento.clientY);
            contexto.beginPath();
            contexto.fillStyle = _properties.colorPincel;
            contexto.fillRect(xActual, yActual, _properties.lineHeigth, _properties.lineHeigth);
            contexto.closePath();

            comienzaDibujo = true;
        });

        canvas.addEventListener("mousemove", (evento) => {
            if (!comienzaDibujo) {
                return;
            }
            xAnterior = xActual;
            yAnterior = yActual;
            xActual = _properties.xReal(evento.clientX);
            yActual = _properties.yReal(evento.clientY);
            contexto.beginPath();
            contexto.moveTo(xAnterior, yAnterior);
            contexto.lineTo(xActual, yActual);
            contexto.strokeStyle = _properties.colorPincel;
            contexto.lineWidth = _properties.lineHeigth;
            contexto.stroke();
            contexto.closePath();
        });

        canvas.addEventListener("mouseout", (evento) => {
            comienzaDibujo = false;
            $(_elements.btnFinalizarFirma).attr("disabled", false);
        });

        canvas.addEventListener("mouseup", (evento) => {
            comienzaDibujo = false;
            $(_elements.btnFinalizarFirma).attr("disabled", false);
        });

    }

    function ocultarBotones() {
        $(_elements.btnFinalizarFirma).hide();
        $(_elements.btnFinalizarFirma).hide();
        $(_elements.btnFinalizarFirma).hide();
    }

    function getFechaActual() {
        let d = new Date;

        let day = d.getDate();
        day = (day < 10) ? `0${day}` : day;
        let month = d.getMonth() + 1;
        month = (month < 10) ? `0${month}` : month;
        let hours = d.getHours();
        hours = (hours < 10) ? `0${hours}` : hours;
        let minutes = d.getMinutes();
        minutes = (minutes < 10) ? `0${minutes}` : minutes;
        let seconds = d.getSeconds();
        seconds = (seconds < 10) ? `0${seconds}` : seconds;

        return ([day, month,
            d.getFullYear()].join('/') + ' ' +
            [hours,
                minutes,
                seconds].join(':'));
    }

    function saveFirma() {

        let success = function (response) {

            ResetModal();
        }

        let error = function (response) {
            ajaxErrorMessage(response);
        }

        firmaDigitalService.SaveFirmaCartaCompromiso(_dataSelected, success, error);
    }

    function GetFirmaDocumentosView() {

        let success = function (response) {

            $(_elements.modalFirmaBody).html('');
            $(_elements.modalFirmaBody).html(response);

            InitFirmaDocumento();

        }

        let error = function (response) {
            ajaxErrorMessage(response);
        }

        firmaDigitalService.GetFirmaDocumentosView(_dataSelected, success, error);

    }

    function showDocumentoPreview() {

        console.log("_dataSelected.TipoID", _dataSelected.documentoTipoID);

        let dataUrlFirmaImage = canvas.toDataURL();

        let htmlString = $(_elements.divBodyDocument).html();
        let htmlStringLineaNombre = $("#divFirmaNombre").html();
        let htmlStringAuditoria = $("#div-auditoria").html();
        let htmlStringFirmaPatron = $("#divPatronSignatureContainer").html();
        let htmlStringFirmaImagen = '';
        let htmlStringFirmaImage = '';

        if (_dataSelected.documentoTipoID != 3 &&
                _dataSelected.documentoTipoID != 4 &&
                    _dataSelected.documentoTipoID != 5)
        {
            htmlStringFirmaImagen = `<div class="col-12">
                                        <div class="m-0 row justify-content-center">
                                            <img width="320" height="100" src="${dataUrlFirmaImage}"/>
                                        </div>
                                    </div>`;
            htmlStringFirmaImage = `<div class="row mt-5">${htmlStringFirmaImagen}
                                        <div class="col-12 pb-2">${htmlStringLineaNombre}</div>
                                    </div>`;
        }

        if (_dataSelected.documentoTipoID == 3 ||
            _dataSelected.documentoTipoID == 4 ||
            _dataSelected.documentoTipoID == 5) {

            htmlStringFirmaImagen = `<div class="col-12">
                                        <div class="m-0 row justify-content-center">
                                            <img width="320" height="100" src="${dataUrlFirmaImage}"/>
                                        </div>
                                    </div>`;
            htmlStringFirmaImage = `<div class="row my-5">
                                        <div class="col-6">
                                            ${htmlStringFirmaPatron}
                                        </div>
                                        <div class="col-6">
                                            ${htmlStringFirmaImagen}
                                            <div class="col-12 pb-2">${htmlStringLineaNombre}</div>
                                        </div>
                                    </div>`;
        }



        let htmlStringPie = `<div class="row">
                                    <div class="col-12 d-flex justify-content-between">${htmlStringAuditoria}</div>
                            </div>`;

        htmlString = htmlString + htmlStringFirmaImage + htmlStringPie;


        $(_elements.divPreviewDocument).html(htmlString);
        $(_elements.modalPrincipal).toggle();
        $(_elements.modalPreview).toggle();

    }

    function validateData() {

        if (_dataSelected.documentoTipoID === _tiposDocumento.cartaCompromiso ) {

            let _numero = $("#txtNumeroTelefonico").val();

            if (_numero.length == 0) {
                modalMessage("warning", "Datos Incompletos", "Ingresa un número de contacto", null);
                return false;
            }

            let _diasSeleccionados = 0;

            $(".solicitudInputRadio.diaSemana").each(function () {

                let isChecked = $(this).is(":checked");
                if (isChecked == true) {
                    _diasSeleccionados = _diasSeleccionados + 1;
                }

            });

            if (_diasSeleccionados == 0 || _diasSeleccionados > 2)
            {
                modalMessage("warning", "Dias Autorizados", "Debes seleccionar entre uno o dos días de trabajo remoto a la semana.", null);
                return false;
            }

        }

        if (_dataSelected.documentoTipoID === _tiposDocumento.convenioBanco
            || _dataSelected.documentoTipoID === _tiposDocumento.convenioCasaBolsa
            || _dataSelected.documentoTipoID === _tiposDocumento.convenioServicios) {

            let _direccion = $("#txtDireccionEmpleado").val();

            if (_direccion.length == 0) {
                modalMessage("warning", "Datos Incompletos", "Ingresa tu domicilio actual", null);
                return false;
            }

        }

        return true;

    }

    return {
        InitFirmaController,
        InitCartaCompromisoController
    }
}();