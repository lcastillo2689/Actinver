﻿const FormsController = (function () {
    const ConfirmacionGuardar = function (preconfirmFunction, thenFunction) {
        confirmationMessage("La información se guardará. <br /><br />¿Deseas continuar?", preconfirmFunction, thenFunction);
    };

    const ConfirmacionBorrar = function (preconfirmFunction, thenFunction) {
        confirmationMessage("El registro se borrará. <br /><br />¿Deseas continuar?", preconfirmFunction, thenFunction);
    };

    const ClearErrorMessages = function () {
        $(".field-validation-error").text("");
    };

    const GuardadoExitoso = function () {
        operacionExitosa("La informaci&oacute;n se guardo exitosamente.");
    }

    return {
        ConfirmacionGuardar,
        ClearErrorMessages,
        ConfirmacionBorrar,
        GuardadoExitoso
    };
})();
