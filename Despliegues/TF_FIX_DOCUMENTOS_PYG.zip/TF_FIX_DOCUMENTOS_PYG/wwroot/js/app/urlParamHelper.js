function UrlParamHelper(queryString) {
    this.queryString = isString(queryString) ? queryString : window.location.search;

    this.get = function (searchedKey) {
        if (!this.queryString || this.queryString === "?") return undefined;

        const query = this.queryString.replace("?", "");
        const params = query.split("&");
        let response = [];

        for (let i = 0; i < params.length; i++) {
            const split = params[i].split("=");
            const key = split[0];
            const value = split[1];

            if (key === searchedKey) response.push(value);
        }

        if (response.length === 0) return undefined;

        return response.length === 1 ? response[0] : response;
    };

    this.getAll = function () {
        let response = {};

        const query = this.queryString.replace("?", "");
        const params = query.split("&");

        for (let i = 0; i < params.length; i++) {
            const split = params[i].split("=");
            const key = split[0];
            const value = split[1];

            if (response[key] === undefined) {
                response[key] = value;
            } else if (response[key] === Array.isArray(response[key])) {
                response[key].push(value);
            } else {
                const temp = response[key];
                response[key] = [];
                response[key].push(temp);
                response[key].push(value);
            }
        }

        return response;
    };

    this.add = function (key, value) {
        validateKeyValueToAdd(key, value);
        if (isObject(key)) value = key;

        if (isArray(value)) {
            for (let i = 0; i < value.length; i++) this.add(key, value[i]);

            return this.queryString;
        }

        if (isObject(value)) {
            for (let item in value) {
                if (!isFunction(value[item])) this.add(item, value[item]);
            }

            return this.queryString;
        }

        if (this.queryString) this.queryString += `&${key}=${value}`;
        else this.queryString = `?${key}=${value}`;

        return this.queryString;
    };

    this.replace = function (key, value) {
        const exists = this.get(key) != undefined;
        if (!exists) return this.add(key, value);

        validateKeyValueToReplace(key, value);

        this.remove(key);
        this.add(key, value);

        return this.queryString;
    };

    this.remove = function (keyToDelete) {
        validateKeyToRemove(keyToDelete);

        const exists = this.get(keyToDelete) != undefined;
        if (!exists) return this.queryString;

        const query = this.queryString.replace("?", "");
        const params = query.split("&");

        this.queryString = "";
        for (let i = 0; i < params.length; i++) {
            const split = params[i].split("=");
            const key = split[0];
            const value = split[1];

            if (key != keyToDelete) this.add(key, value);
        }

        return this.queryString;
    };

    function validateKeyValueToAdd(key, value) {
        if (!isString(key) && !isObject(key) && value != undefined) throw "the key must be a string";

        if (isFunction(value)) throw "value can not be a function";

        if (!isObject(key) && !value) throw "please provide a valid value (array, object, number, boolean or string)";
    }

    function validateKeyValueToReplace(key, value) {
        if (isObject(value) || isFunction(value) || isArray(value)) throw "please provide a valid value (number, boolean or string)";
    }

    function validateKeyToRemove(key) {
        if (!isString(key)) throw "the key must be a string";
    }

    function isObject(obj) {
        return obj !== undefined && obj !== null && obj.constructor == Object;
    }

    function isArray(obj) {
        return obj !== undefined && obj !== null && obj.constructor == Array;
    }

    function isBoolean(obj) {
        return obj !== undefined && obj !== null && obj.constructor == Boolean;
    }

    function isFunction(obj) {
        return obj !== undefined && obj !== null && obj.constructor == Function;
    }

    function isNumber(obj) {
        return obj !== undefined && obj !== null && obj.constructor == Number;
    }

    function isString(obj) {
        return obj !== undefined && obj !== null && obj.constructor == String;
    }
}
