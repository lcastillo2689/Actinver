﻿/**
 * Funciones varias
 * */
const GestorDocumentalApp = (function () {
    function modalMessage(icon, title, text, func) {
        swal.fire({
            title: title,
            html: text,
            icon: icon,
            showCancelButton: false,
            showLoaderOnConfirm: false,
            heightAuto: false,
        }).then(func);
    }

    function esMenorAHoy(date) {
        return parseDate(date) < parseDate(getToday(true));
    }

    function confirmationMessage(text, preconfirmFunction, thenFunction, subTitle, sizeWidth) {
        Swal.fire({
            title: text,
            html: subTitle,
            icon: "warning",
            showCancelButton: true,
            heightAuto: false,
            confirmButtonText: "Sí",
            cancelButtonText: "No",
            confirmButtonColor: "#34bfa3",
            cancelButtonColor: "#f4516c",
            showLoaderOnConfirm: true,
            preConfirm: preconfirmFunction,
            reverseButtons: true,
            allowOutsideClick: () => !Swal.isLoading(),
            width: sizeWidth,
        }).then((result) => {
            if (result.value && thenFunction) thenFunction();
        });
    }

    function operacionExitosa(titulo) {
        Toast.fire({
            icon: "success",
            title: titulo,
        });
    }

    function goToByScroll(id) {
        $("html,body").animate(
            {
                scrollTop: -100 + $("#" + id).offset().top,
            },
            "slow"
        );
    }

    const genericErrorResponse = function (response) {
        ajaxErrorMessage(response);
    };

    function gridErrorRequestHandler(e) {
        const response = e.xhr;
        ajaxErrorMessage(response, "Error al leer los datos de la tabla");
    }

    function ajaxErrorMessage(response, errorTitle) {
        if (response && response.status === 401) {
            showAuthenticationError();
            return;
        }

        let message;
        if (response && response.status === 409) {
            message = response.responseText;
        } else {
            message = getErrorMessage(response);
        }

        modalMessage("error", errorTitle || "Ocurrió un error", message);
    }

    function getErrorMessage(response) {
        let message = "<span style='font-weight: bold;'>Ponte en contacto con el equipo de desarrollo.</span>";

        const errorMessage = response ? response.getResponseHeader("x-error-message") : "";
        if (errorMessage) message += `<br />ErrorMessage: ${errorMessage}`;

        const errorId = response ? response.getResponseHeader("x-error-id") : "";
        if (errorId) message += `<br />ErrorId: ${errorId}`;

        return message;
    }

    function showAuthenticationError() {
        Swal.fire({
            icon: "warning",
            title: "Error de Autenticación",
            html: "No se pudo autorizar la conexión con el servidor. Es probable que tu sesión haya expirado y debas iniciar sesión nuevamente.",
            confirmButtonText: "<i class='fa fa-sign-in-alt mr-3'></i>Iniciar sesión en otra ventana",
            footer: "Inicia sesión en otra ventana y luego regresa a ésta para que no pierdas los cambios no guardados.",
            showCloseButton: true,
            heightAuto: false,
            allowOutsideClick: false,
        }).then((result) => {
            if (result.value) window.open(window.location.origin, "_blank");
        });
    }

    function isValidDate(date, format) {
        return moment(date, format || "DD/MM/YYYY", true).isValid();
    }

    function getTomorrowsDate() {
        let date = new Date();
        date.setDate(date.getDate() + 1);
        date.setHours(0);
        date.setMinutes(0);
        date.setSeconds(0);
        date.setMilliseconds(0);

        return date;
    }

    function getToday(onlyDate) {
        const newDate = new Date();
        const month = newDate.getMonth() + 1;
        const day = newDate.getDate();
        const hour = newDate.getHours();
        const minute = newDate.getMinutes();
        const date = (("" + day).length < 2 ? "0" : "") + day + "/" + (("" + month).length < 2 ? "0" : "") + month + "/" + newDate.getFullYear();
        const time = (("" + hour).length < 2 ? "0" : "") + hour + ":" + (("" + minute).length < 2 ? "0" : "") + minute;
        return date + (onlyDate ? "" : " " + time);
    }

    function formatEditableDate(date) {
        const newDate = new Date(date);
        newDate.setDate(newDate.getDate() + 1);
        const month = newDate.getMonth() + 1;
        const day = newDate.getDate();
        return (("" + day).length < 2 ? "0" : "") + day + "/" + (("" + month).length < 2 ? "0" : "") + month + "/" + newDate.getFullYear();
    }

    function formatAjaxDate(dateString, returnLargeDate) {
        const date = dateString.substring(dateString.lastIndexOf("(") + 1, dateString.lastIndexOf(")"));

        let newDate = new Date(parseInt(date));
        return formatAjaxDateObject(newDate, returnLargeDate);
    }

    function formatAjaxDateObject(date, returnLargeDate) {
        const month = date.getMonth() + 1;
        const day = date.getDate();
        const hour = date.getHours();
        const minute = date.getMinutes();
        date =
            (("" + day).length < 2 ? "0" : "") +
            day +
            "/" +
            (("" + month).length < 2 ? "0" : "") +
            month +
            "/" +
            date.getFullYear() +
            " " +
            (("" + hour).length < 2 ? "0" : "") +
            hour +
            ":" +
            (("" + minute).length < 2 ? "0" : "") +
            minute;

        return returnLargeDate ? date : date.substring(0, 10);
    }

    function formatQueryStringDateObject(date) {
        return date.getMonth() + 1 + "-" + date.getDate() + "-" + date.getFullYear();
    }

    function convertDateToComparableString(date) {
        date = date.trim();
        let string = "";
        const split = date.split("/");
        string = split[2] + "-" + split[1] + "-" + split[0];
        return string;
    }

    function cargandoInformacionLabel() {
        return `Cargando Información... <img width='15' height='15' src='${window.location.origin}/images/iconos/Loading.gif' />`;
    }

    function isValidInputDate(e) {
        if (
            $.inArray(e.keyCode, [46, 8, 9, 27, 13, 189, 109, 55, 111]) !== -1 ||
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
            (e.keyCode >= 35 && e.keyCode <= 40)
        ) {
            return true;
        }

        if ((e.shiftKey || e.keyCode < 48 || e.keyCode > 57) && (e.keyCode < 96 || e.keyCode > 105)) return false;

        return true;
    }

    function initializeInputDate(selector) {
        $(selector).keydown(function (e) {
            if (!isValidInputDate(e)) e.preventDefault();
        });
    }

    function isValidInputDigit(e) {
        if (
            $.inArray(e.keyCode, [46, 8, 9, 27, 13, 110]) !== -1 ||
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
            (e.keyCode === 190 && !e.shiftKey) ||
            (e.keyCode >= 35 && e.keyCode <= 40) ||
            (e.ctrlKey && e.keyCode === 86) ||
            (e.ctrlKey && e.keyCode === 67)
        ) {
            return true;
        }

        if ((e.shiftKey || e.keyCode < 48 || e.keyCode > 57) && (e.keyCode < 96 || e.keyCode > 105)) return false;

        return true;
    }

    function isValidInputKNotation(e, hasKValue) {
        if (
            $.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
            (e.keyCode === 110 && !hasKValue) ||
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
            (e.keyCode === 190 && !e.shiftKey && !hasKValue) ||
            (e.keyCode >= 35 && e.keyCode <= 40) ||
            (e.ctrlKey && e.keyCode === 86) ||
            (e.ctrlKey && e.keyCode === 67)
        ) {
            return true;
        }

        if (hasKValue) return false;

        if ((e.shiftKey || e.keyCode < 48 || e.keyCode > 57) && (e.keyCode < 96 || e.keyCode > 105) && e.keyCode !== 75 && e.keyCode !== 77) return false;

        return true;
    }

    function isValidInputNumber(e) {
        if (
            $.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
            (e.keyCode >= 35 && e.keyCode <= 40) ||
            (e.ctrlKey && e.keyCode === 86) ||
            (e.ctrlKey && e.keyCode === 67)
        ) {
            return true;
        }

        if ((e.shiftKey || e.keyCode < 48 || e.keyCode > 57) && (e.keyCode < 96 || e.keyCode > 105)) return false;

        return true;
    }

    function initializeInputNumber(selector) {
        $(selector).keydown(function (e) {
            if (!isValidInputNumber(e)) e.preventDefault();
        });
    }

    function initializeCustomInputKNotation(selector, digit) {
        $(selector).blur(function () {
            const input = $(this);
            replaceKNotationValues(input);
            clearMultiplePoints(input);
            value = input.val();
            input.val(formatThousandSeparatorNumber(value, digit));
        });

        $(selector).focus(function () {
            const input = $(this);
            clearMultiplePoints(input);
            value = input.val();
            input.val(value.replace(/,/g, ""));
        });

        $(selector).keydown(function (e) {
            const input = $(this);
            const value = input.val().toLowerCase();
            const hasKValue = value.indexOf("k") !== -1 || value.indexOf("m") !== -1;

            if (!isValidInputKNotation(e, hasKValue)) e.preventDefault();

            if (value.indexOf(".") !== -1 && (e.keyCode === 190 || e.keyCode === 110)) e.preventDefault();
            if (value.indexOf(".") === value.length - 1 && (e.keyCode === 77 || e.keyCode === 75)) e.preventDefault();

            if (e.keyCode === 13) replaceKNotationValues(input);
        });
    }

    function initializeInputDigit(selector, digit) {
        $(selector).blur(function () {
            const input = $(this);
            clearMultiplePoints(input);
            value = input.val();
            input.val(formatThousandSeparatorNumber(value, digit));
        });

        $(selector).focus(function () {
            const input = $(this);
            clearMultiplePoints(input);
            value = input.val();
            input.val(value.replace(/,/g, ""));
        });

        $(selector).keydown(function (e) {
            const value = $(this).val().toLowerCase();

            if (!isValidInputDigit(e)) e.preventDefault();
            if (value.indexOf(".") !== -1 && (e.keyCode === 190 || e.keyCode === 110)) e.preventDefault();
        });
    }

    function parseDate(date, format) {
        return moment(date, format || "DD/MM/YYYY", true).toDate();
    }

    function parseBool(str) {
        return str && str.toLowerCase() === "true" ? true : false;
    }

    function formatThousandSeparatorNumber(nStr, digits) {
        if (!digits && digits != 0) digits = 2;

        if (!nStr && nStr != 0) return "";

        const response = Number(parseFloat(nStr).toFixed(digits)).toLocaleString("en", { minimumFractionDigits: digits });
        return response !== "NaN" ? response : "";
    }

    function clearMultiplePoints(input) {
        let value = input.val();
        split = value.split(".");

        if (split.length > 2) {
            value = parseFloat(value);
            input.val(value);
        }
    }

    function replaceKNotationValues(input) {
        let value = input.val().toLowerCase();
        let notationValue;
        if (value.indexOf("k") !== -1) notationValue = "k";
        if (value.indexOf("m") !== -1) notationValue = "m";

        if (!notationValue) return;

        const indexDot = value.indexOf(".");
        const indexNotationValue = value.indexOf(notationValue);

        if (indexDot === -1 || indexDot > indexNotationValue) {
            value = value.replace("k", "000");
            value = value.replace("m", "000000");
        } else {
            value = value.replace(".", "");

            const difference = indexNotationValue - indexDot;
            let ceros = notationValue === "k" ? 3 : 6;
            let lblCeros = "";

            if (ceros - difference >= 0) {
                for (let i = 0; i <= ceros - difference; i++) lblCeros += "0";
            }

            value = value.replace("k", lblCeros);
            value = value.replace("m", lblCeros);

            let newIndexDot = indexDot + ceros;
            value = value.slice(0, newIndexDot) + "." + value.slice(newIndexDot, value.length);
        }

        input.val(value);
    }

    function setModalTitle(selector, title, setIcon) {
        if (setIcon) $(selector + " .modal-title").html(title);
        else $(selector + " .modal-title label").text(title);
    }

    const Loading = (function () {
        const show = function () {
            $.blockUI({
                overlayCSS: {
                    backgroundColor: "#fff",
                    opacity: "0.6",
                },
                css: {
                    border: "none",
                    padding: "15px",
                    "-webkit-border-radius": ".25rem",
                    "-moz-border-radius": ".25rem",
                    width: "20%",
                    left: "40%",
                    backgroundColor: "transparent",
                    "font-size": "20px",
                },
                baseZ: 100000,
                message: `<img width='100' height='100' src='${window.location.origin}/images/iconos/loading-2.gif' />`,
            });
        };

        const hide = function () {
            $.unblockUI();
        };

        return {
            Show: show,
            Hide: hide,
        };
    })();

    const Toast = Swal.mixin({
        toast: true,
        position: "top-end",
        showConfirmButton: false,
        timer: 5000,
        timerProgressBar: true,
        onOpen: (toast) => {
            toast.addEventListener("mouseenter", Swal.stopTimer);
            toast.addEventListener("mouseleave", Swal.resumeTimer);
        },
    });

    function getErrorHTMLList(errors) {
        if (!errors) return "";

        if (errors.length === 1) return errors[0];

        let items = errors.map((i) => `<li>${i}</li>`).join("");
        return `<ul style="text-align: left;">${items}</ul>`;
    }

    function initializeMontPicker(montPickerSelector) {
        $(montPickerSelector).datepicker({
            format: "M-yyyy",
            minViewMode: 1,
            maxViewMode: 2,
            language: "es",
            autoclose: true,
        });
    }

    function ObjectCan(obj, methodName) {
        return typeof obj[methodName] === "function";
    }

    function getMonthName(month) {
        switch (month) {
            case 1:
                return "Enero";
            case 2:
                return "Febrero";
            case 3:
                return "Marzo";
            case 4:
                return "Abril";
            case 5:
                return "Mayo";
            case 6:
                return "Junio";
            case 7:
                return "Julio";
            case 8:
                return "Agosto";
            case 9:
                return "Septiembre";
            case 10:
                return "Octubre";
            case 11:
                return "Noviembre";
            case 12:
                return "Diciembre";
            default:
                console.error(`No existe el mes ${month}`);
        }
    }

    function getCookie(cname) {
        const name = cname + "=";
        const decodedCookie = decodeURIComponent(document.cookie);
        const ca = decodedCookie.split(";");
        for (let i = 0; i < ca.length; i++) {
            let c = ca[i];

            while (c.charAt(0) == " ") c = c.substring(1);

            if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
        }
        return "";
    }

    function setCookie(name, value) {
        var cookieValue = encodeURIComponent(value);
        document.cookie = `${name}=${cookieValue}; path=/`;
    }

    function CleanPopoverInNextClick() {
        $("body").on("click", function (e) {
            //only buttons
            if ($(e.target).data("toggle") !== "popover" && $(e.target).parents(".popover.in").length === 0) {
                $('[data-toggle="popover"]').popover("hide");
            }
        });
    }

    function CleanPopoverWithIconInNextClick() {
        $("body").on("click", function (e) {
            //buttons and icons within buttons
            if (
                $(e.target).data("toggle") !== "popover" &&
                $(e.target).parents('[data-toggle="popover"]').length === 0 &&
                $(e.target).parents(".popover.in").length === 0
            ) {
                $('[data-toggle="popover"]').popover("hide");
            }
        });
    }

    function GetUrlParameter(sParam) {
        var sPageURL = window.location.search.substring(1),
            sURLVariables = sPageURL.split("&"),
            sParameterName,
            i;

        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split("=");

            if (sParameterName[0] === sParam) {
                return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
            }
        }
    }

    function GetDatesForDatePickers() {
        let fechaConsulta = new Date();
        fechaConsulta = GetPreviousWorkDay(fechaConsulta);

        return {
            fechaConsulta,
        };
    }

    function GetPreviousWorkDay(fecha) {
        let day = 0;
        let strDate;
        let esFeriado = false;
        do {
            fecha.setDate(fecha.getDate() - 1);
            day = fecha.getDay();
            strDate = `${fecha.getDate()}/${fecha.getMonth() + 1}/${fecha.getFullYear()}`;
            esFeriado = include(DisableDatesForHolidays(), strDate);
        } while (day === 6 || day === 0 || esFeriado);
        return fecha;
    }

    function include(arr, obj) {
        return arr.indexOf(obj) !== -1;
    }

    return {
        modalMessage,
        esMenorAHoy,
        confirmationMessage,
        operacionExitosa,
        goToByScroll,
        genericErrorResponse,
        gridErrorRequestHandler,
        ajaxErrorMessage,
        getErrorMessage,
        showAuthenticationError,
        isValidDate,
        getTomorrowsDate,
        getToday,
        formatEditableDate,
        formatAjaxDate,
        formatAjaxDateObject,

        formatQueryStringDateObject,
        convertDateToComparableString,
        cargandoInformacionLabel,
        isValidInputDate,
        initializeInputDate,
        isValidInputDigit,
        isValidInputKNotation,
        isValidInputNumber,
        initializeInputNumber,
        initializeCustomInputKNotation,
        initializeInputDigit,
        parseDate,
        parseBool,
        formatThousandSeparatorNumber,
        clearMultiplePoints,

        replaceKNotationValues,
        setModalTitle,
        Loading,
        Toast,
        getErrorHTMLList,
        initializeMontPicker,
        ObjectCan,
        getMonthName,
        getCookie,
        setCookie,
        CleanPopoverInNextClick,
        CleanPopoverWithIconInNextClick,
        GetUrlParameter,
        GetDatesForDatePickers,
        GetPreviousWorkDay,
        include
    };
})();