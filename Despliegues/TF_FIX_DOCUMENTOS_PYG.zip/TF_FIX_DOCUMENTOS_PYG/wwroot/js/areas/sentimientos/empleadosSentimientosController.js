﻿const EmpleadosSentimientosController = function () {
    let formEmpleadoSentimiento = null;

    let _elements = {
        divEmpleadoSentimiento: "#divEmpleadoSentimiento",
        divEmpleadosSentimientos: "#divEmpleadosSentimientos",
        btnEmpleadoSentimientoCancelar: "#btn-CancelarEmpleadoSentimiento",
        btnEmpleadoSentimientoGuardarJson: "#btn-GuardarEmpleadoSentimientoJson",

        /**         
         */
        frmEmpleadoSentimiento: "frm-EmpleadoSentimiento",
    };

    function setEmpleadoSentimientoEventHandler() {
        $(_elements.btnEmpleadoSentimientoGuardarJson).on('click', {}, function (e) {
            e.preventDefault();
            GuardarEmpleadoSentimientoJson();
        });
    }

    function initEmpleadoSentimientoFormValidaciones() {
        formEmpleadoSentimiento = FormValidation.formValidation(
            document.getElementById(_elements.frmEmpleadoSentimiento),
            {
                fields: {
                    "txtarea": {
                        validators: {
                            notEmpty: {
                                message: 'Requerido'
                            },
                            stringLength: {
                                min: 50,
                                max: 1000,
                                message: 'Por favor ingresa una descripción con longitud mínima de 50 caracteres'
                            }
                        }
                    },
                },

                plugins: {
                    trigger: new FormValidation.plugins.Trigger(),
                    bootstrap: new FormValidation.plugins.Bootstrap(),
                    submitButton: new FormValidation.plugins.SubmitButton(),
                    defaultSubmit: new FormValidation.plugins.DefaultSubmit(),
                }
            },
        );
    }

    const Init = function (fecha) {
        GetEmpleadosSentimientos(532, fecha);
        //setEventHandler();
        //initEmpleadoSentimientoFormValidaciones();
    }

    /**
     * Para registrar sentimiento
     * @param {any} empleadoId
     * @param {any} fecha
     */
    function GetEmpleadoSentimiento(empleadoId, fecha) {
        let success = function (response) {

            $(_elements.divEmpleadoSentimiento).html('');
            $(_elements.divEmpleadoSentimiento).html(response);

            setEmpleadoSentimientoEventHandler();
        }

        let error = function (response) {
            ajaxErrorMessage(response);
        }

        EmpleadosSentimientosService.GetEmpleadoSentimiento(getModelEmpleadoSentimiento(empleadoId, moment(fecha).format("YYYY-MM-DD HH:mm")), success, error);
    }

    /**
     * Consultas
     * @param {any} empleadoId
     * @param {any} fecha
     * @param {any} tabColaboradoresSeleccionado
     */
    function GetEmpleadosSentimientos(empleadoId, fecha, tabColaboradoresSeleccionado, cargarModal = true) {
        let success = function (response) {
            $(_elements.divEmpleadosSentimientos).html('');
            $(_elements.divEmpleadosSentimientos).html(response);

            if (cargarModal) {
                GetEmpleadoSentimiento(532, fecha);
            }
        }

        let error = function (response) {
            ajaxErrorMessage(response);
        }
        EmpleadosSentimientosService.GetEmpleadosSentimientos(getModelEmpleadoSentimiento(empleadoId, moment(fecha).format("YYYY-MM-DD HH:mm"), tabColaboradoresSeleccionado), success, error);
    }

    /**
     * 
     * @param {any} empleadoId
     * @param {any} fecha
     * @param {any} tcs - ¿Tab Colaboradores Seleccionado?
     */
    function getModelEmpleadoSentimiento(empleadoId, fecha, tcs) {
        return {
            empleadoId: empleadoId,
            fecha: fecha,
            tcs : tcs
        }
    }

    function getModelEmpleadoSentimientoComentario(empleadoId, empleadoSentimientoId) {
        return {
            empleadoId: empleadoId,
            empleadoSentimientoId: empleadoSentimientoId
        }
    }

    function getModelEmpleadoSentimientoGuardar(fecha, empleadoId, sentimientoId, comentario) {
        return {
            Fecha: fecha,
            EmpleadoId: empleadoId,
            SentimientoId: sentimientoId,
            Comentario: comentario
        }
    }
    /**
     * guardar registro de sentimiento de empleado
     * */
    function GuardarEmpleadoSentimientoJson() {
        let fecha = document.getElementById("frm-empleado-sentimiento-fecha").value;
        let empleadoId = document.getElementsByName("EmpleadoId")[0].value;
        let sentimientoIds = document.getElementsByName("SentimientoId");
        let sentimientoId = 0;
        let comentario = document.getElementById("txtarea").value;

        for (var i = 0; i < sentimientoIds.length; i++) {
            if (sentimientoIds[i].checked) {
                sentimientoId = sentimientoIds[i].value;
            }
        }
        if (sentimientoId == 0) {
            modalMessage("warning", "Advertencia", "<span>No seleccionaste un sentimiento</span><br /><span>Debes seleccionar un sentimiento de la lista</span><br /><span></span><br /><span></span>");
            return;
        }

        var model = getModelEmpleadoSentimientoGuardar(fecha, empleadoId, sentimientoId, comentario);

        let success = function (response) {

            console.log(response);
            if (response.updateErrores) {
                console.log(response.updateErrores);
                if (response.updateErrores.length > 0) {
                    let error = response.updateErrores[0];
                    modalMessage("error", "Error", "<span>No se registró el sentimiento</span><br /><span>" + error + "</span><br /><span></span><br /><span></span>");
                }
                else {
                    modalMessage("error", "Error", "<span>No se registró el sentimiento</span><br /><span></span><br /><span></span><br /><span></span>");
                }
            }
            else if(response.updateSuccess){
                toastr.success("¡La información ha sido guardada correctamente!");

                let tabColaboradoresSeleccionado = false;
                GetEmpleadosSentimientos(empleadoId, fecha, tabColaboradoresSeleccionado, false);

                $('#modal-registro-sentimiento').modal('hide');

                document.getElementById("txtarea").value = '';
                _e.btnSeleccionado = '';
                _e.inputSeleccionado = '';
                _e.sentimientoSeleccionado = '';
                $("#spanSentimiento").html('');
                $("#txtarea").prop("placeholder", "¿Por qué me siento así?")
                _e.registrosPersonales = _e.registrosPersonales+1;

                for (var i = 0; i < sentimientoIds.length; i++) {
                    document.getElementById(sentimientoIds[i].parentElement.id).classList.remove('btn-warning');
                    document.getElementById(sentimientoIds[i].parentElement.id).classList.remove('btn-primary');
                    document.getElementById(sentimientoIds[i].parentElement.id).classList.add('btn-clean');
                    sentimientoIds[i].checked = false;
                }
            }
        }

        let error = function (response) {
            console.log(response);
            ajaxErrorMessage(response);
        }

        EmpleadosSentimientosService.GuardarEmpleadoSentimientoJson(model, success, error);
    }

    function UpdateComentario(empleadoId, empleadoSentimientoId) {

        var model = getModelEmpleadoSentimientoComentario;

        let success = function (response) {

            if (!response.updateSuccess)
                modalMessage("error", "Error", "<span>La evaluación no puede ser enviada a revisión</span><br /><span>Debes calificar todos los objetivos</span><br /><span>Describir el resultado del objetivo</span><br /><span>La ponderación (peso) de los objetivos debe sumar 100</span>");
            else {
                toastr.success("¡La información ha sido guardada correctamente!");

                //GetEmpleadosSentimientos(empleadoId, cuestionarioEmpleadoId);
            }
        }

        let error = function (response) {
            ajaxErrorMessage(response);
        }

        EmpleadosSentimientosService.UpdateComentario(model, success, error);
    }

    function setEventHandler() {
        $(_elements.swPregunta).change(function (e) {
            let state = $(this).prop('checked');
            let empleadoId = $(this).attr(_dataAttributes.empleadoId);
            let cuestionarioEmpleadoId = $(this).attr(_dataAttributes.cuestionarioEmpleadoId);
            let preguntaId = $(this).attr(_dataAttributes.preguntaId);


            updateCuestionarioEmpleado(empleadoId, cuestionarioEmpleadoId, preguntaId, 0, state);
        })

        $(_elements.chkDay).change(function (e) {
            let state = $(this).prop('checked');
            let empleadoId = $(this).attr(_dataAttributes.empleadoId);
            let cuestionarioEmpleadoId = $(this).attr(_dataAttributes.cuestionarioEmpleadoId);
            let dayHomeOffice = $(this).attr(_dataAttributes.dayHomeOffice);

            updateCuestionarioEmpleado(empleadoId, cuestionarioEmpleadoId, 0, dayHomeOffice, state);
        })
    }
    return {
        Init,
        GetEmpleadosSentimientos,
        UpdateComentario,
        GuardarEmpleadoSentimientoJson
    }
}();