(function ($) {
    $.fn.countTo = function (options) {
        options = $.extend({}, $.fn.countTo.defaults, options || {});

        const loops = Math.ceil(options.speed / options.refreshInterval);
        const increment = (options.to - options.from) / loops;

        return $(this).each(function () {
            const _this = this;
            const interval = setInterval(updateTimer, options.refreshInterval);
            let loopCount = 0;
            let value = options.from;

            function updateTimer() {
                value += increment;
                loopCount++;
                const number = Number(parseFloat(value).toFixed(options.decimals));
                const valueToPrint = number.toLocaleString("en", { minimumFractionDigits: options.decimals });
                $(_this).html(valueToPrint);

                if (typeof options.onUpdate == "function") options.onUpdate.call(_this, value);

                if (loopCount >= loops) {
                    clearInterval(interval);
                    value = options.to;

                    if (typeof options.onComplete == "function") options.onComplete.call(_this, value);
                }
            }
        });
    };

    $.fn.countTo.defaults = {
        from: 0, // the number the element should start at
        to: 100, // the number the element should end at
        speed: 1000, // how long it should take to count between the target numbers
        refreshInterval: 100, // how often the element should be updated
        decimals: 0, // the number of decimal places to show
        onUpdate: null, // callback method for every time the element is updated,
        onComplete: null, // callback method for when the element finishes updating
    };
})(jQuery);
