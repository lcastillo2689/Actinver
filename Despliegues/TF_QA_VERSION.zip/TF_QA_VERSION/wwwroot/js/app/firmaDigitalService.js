﻿const firmaDigitalService = (function () {

    let _urlFirmaDigital = `${window.location.origin}/Firma`;

    let GetCartasCompromisoView = function (success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlFirmaDigital}/GetCartasCompromisoView`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                success(response);
            },
        });
    }

    let GetFirmaDocumentosView = function ( dataDocumento ,success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            data: { documentoTipoID: dataDocumento.documentoTipoID },
            url: `${_urlFirmaDigital}/GetFirmaDocumentosView`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                success(response);
            },
        });
    }

    let SaveFirmaCartaCompromiso = function (dataSelected, success, error) {

        var opt = {
            margin: 0.5,
            filename: 'Documento_Trabajo_Flexible.pdf',
            image: { type: 'jpeg', quality: 0.98 },
            jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' }
        };

        html2pdf().set(opt).from(document.getElementById("divPreviewDocument"))
            .save()
            .outputPdf()
            .then((url2) => {

                const base64 = btoa(url2);

                $.ajax({
                    url: '/Firma/SaveFirma',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        base64: base64,
                        ip: $('#ip').text(),
                        documentoTipoID: dataSelected.documentoTipoID ,
                        nombre: dataSelected.documentoNombre
                    },
                    error: function (response) {
                        success(response);
                    },
                    success: function (response) {
                        success(response);
                    },
                });
            });
    };

    //function SaveFirma() {

    //    var opt = {
    //        margin: 1,
    //        filename: 'CartaCompromiso.pdf',
    //        image: { type: 'jpeg', quality: 0.98 },
    //        jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' }
    //    };

    //    html2pdf().set(opt).from(document.getElementById("modal-firma-body"))
    //        .save()
    //        .outputPdf()
    //        .then((url2) => {
    //            const base64 = btoa(url2);

    //            $.ajax({
    //                url: '/Firma/SaveFirma',
    //                type: 'POST',
    //                dataType: 'json',
    //                data: {
    //                    base64: base64,
    //                    ip: $('#ip').text()
    //                },
    //                error: function (xmlHttpRequest, errorText, thrownError) {
    //                    alert(xmlHttpRequest + "|" + errorText + "|" + thrownError);
    //                },
    //                success: function (data) {
    //                    modalMessage("success", "", data.Result, function () {
    //                    });

    //                    $("#modal-firma-body").html('');
    //                    $("#modal-firma").modal('hide');
    //                }
    //            });
    //        });
    //}

    return {
        GetCartasCompromisoView,
        GetFirmaDocumentosView,
        SaveFirmaCartaCompromiso,
        //SaveFirma
    };
})();