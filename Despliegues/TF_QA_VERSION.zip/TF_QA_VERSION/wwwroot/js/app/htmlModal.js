function HtmlModal(modalName) {
    const _modal = {
        name: `#div${modalName}Modal`,
        bodyName: `#div${modalName}ModalBody`,
    };

    this.show = () => $(_modal.name).modal("show");

    this.hide = () => $(_modal.name).modal("hide");

    this.displayLoadingLabel = () => $(_modal.bodyName).html(cargandoInformacionLabel());

    this.setHtmlBody = (html) => $(_modal.bodyName).html(html);

    this.setTitle = (title) => $(`${_modal.name} .modal-title label`).text(title);

    this.setIcon = (icon) => $(`${_modal.name} .modal-title i`).removeClass().addClass(icon).addClass("mr-2");

    this.hideCloseButton = function () {
        $(`${_modal.name} .modal-header button.close`).css("display", "none");
    };

    this.onClose = (func) => {
        $(`${_modal.name}`).on("hidden.bs.modal", func);
    };

    this.onOpen = (func) => {
        $(`${_modal.name}`).on("shown.bs.modal", func);
    };
}
