﻿const ColaboradoresController = function () {
    let _elements = {
        divColaboradores: "#divColaboradores",
        divColaborador: "#divColaborador",
        divModalBody: "#modal-tf-body",
        divModalBodyOKR: "#modal-okr-body",
        divModalBodyDocumentos: "#modal-documentos-body",
        divCuestionario: "#divCuestionario",
        divEstatusHO: '#divEstatusHO-',

        btnCalificar: ".btn-Calificar",
        btnGuardarCuestionarioGestion: "btn-GuardarCuestionarioExtraordianario",
        btnConsideracion: '.btn-consideracion',
        btnNotificacionDesempenio: ".btn-notificacionDesempenio",
        btnDocumentoFirmado: ".btn-documento-firmado",

        modalTrabajoFlexible: '#modal-trabajoFelxible',
        modalDocumentosFirmados: '#modal-documentosFirmados',
        modalDetalleOKR: '#modal-resultadoOKR',

    };

    let _dataAttributes = {
        empleadoId: "data-num",
        estatusOKR: "data-estatus",
        estatusEvaluacionQ2: "data-estatusEvaluacion",
        candidatoTF: "data-candidatoTF",
        tutorialCompleto: "data-tutorialTF",
        fullRemote: "data-fullRemote",
    };

    const Init = function () {
        getColaboradoresACargo();

    }

    const InitColaborador = function () {
        getDataColaborador();

    }

    const InitColaboradoresForm = function (empleados) {
        setControlEvents();
    }

    function getModelCuestionario(empleadoId) {
        return {
            empleadoId: empleadoId
        }
    }

    function setControlEvents() {
        $(_elements.btnCalificar).on('click', function (e) {
            e.preventDefault();
            let empleadoId = $(this).attr(_dataAttributes.empleadoId);

            let candidatoTrabajoFlexible = $(this).attr(_dataAttributes.candidatoTF);
            let tutorialCompleto = $(this).attr(_dataAttributes.tutorialCompleto);
            let estatusQ2 = $(this).attr(_dataAttributes.estatusEvaluacionQ2);

            if (candidatoTrabajoFlexible == "False") {
                modalMessage("warning",
                    "¡Atención!",
                    "<span>El Colaborador no es candidato para realizar Trabajo Remoto</span>");
                $(_elements.divCuestionario).html('');
            } else if (estatusQ2 == 'False') {
                modalMessage("warning",
                    "¡Atención!",
                    "<span>El Colaborador no ha finalizado su Evaluación de OKR´s Q2 2022</span>");
            }
            else {
                showEmpleadoCuestionario(empleadoId);
            }



        });

        $(_elements.btnConsideracion).on('click', function (e) {
            e.preventDefault();

            let empleadoId = $(this).attr(_dataAttributes.empleadoId);

            showEmpleadoConsideracion(empleadoId);
        });

        //$(_elements.btnNotificacionDesempenio).on('click', function (e) {
        //    e.preventDefault();

        //    let empleadoId = $(this).attr(_dataAttributes.empleadoId);

        //    showDetalleDesempenioOKR(empleadoId);
        //});

        $(_elements.btnDocumentoFirmado).on('click', function (e) {
            e.preventDefault();

            let empleadoId = $(this).attr(_dataAttributes.empleadoId);

            showDocumentosFirmados(empleadoId);
        });

        tippy(_elements.btnConsideracion, { theme: "light", animation: "scale", placement: "bottom", inertia: true });
        tippy(_elements.btnNotificacionDesempenio, { theme: "light", animation: "scale", placement: "right", inertia: true });
        tippy(_elements.btnDocumentoFirmado, { theme: "light", animation: "scale", placement: "bottom", inertia: true });
    }

    function showEmpleadoCuestionario(empleadoId) {
        Loading.Show();
        let success = function (response) {

            $(_elements.divCuestionario).html('');
            $(_elements.divCuestionario).html(response);

            Loading.Hide();
        }

        let error = function (response) {
            ajaxErrorMessage(response);

            Loading.Hide();
        }

        CuestionarioService.GetEmpleadoCuestionario(getModelCuestionario(empleadoId), success, error);
    }

    function getColaboradoresACargo() {
        Loading.Show();
        let success = function (response) {

            $(_elements.divColaboradores).html('');
            $(_elements.divColaboradores).html(response);
            Loading.Hide();
        }

        let error = function (response) {
            ajaxErrorMessage(response);
            Loading.Hide();
        }

        ColaboradoresService.GetColaboradoresACargo(success, error);
    }

    function getDataColaborador() {
        Loading.Show();
        let success = function (response) {

            $(_elements.divColaborador).html('');
            $(_elements.divColaborador).html(response);

            Loading.Hide();
        }

        let error = function (response) {
            ajaxErrorMessage(response);
            Loading.Hide();
        }

        ColaboradoresService.GetPlaneaGestionaColaboradorView(success, error);
    }

    function showEmpleadoConsideracion(empleadoId) {
        let success = function (response) {

            $(_elements.divModalBody).html('');
            $(_elements.divModalBody).html(response);
            $(_elements.modalTrabajoFlexible).modal('show');
        }

        let error = function (response) {
            ajaxErrorMessage(response);
        }

        CuestionarioService.GetEmpleadoConsideracionView(getModelCuestionario(empleadoId), success, error);
    }

    function showDetalleDesempenioOKR(empleadoId) {
        let success = function (response) {

            $(_elements.divModalBodyOKR).html('');
            $(_elements.divModalBodyOKR).html(response);
            $(_elements.modalDetalleOKR).modal('show');
        }

        let error = function (response) {
            ajaxErrorMessage(response);
            Loading.Hide();
        }

        ColaboradoresService.GetDetalleDesempenioOKRView(getModelCuestionario(empleadoId), success, error);
    }

    function showDocumentosFirmados(empleadoId) {
        Loading.Show();

        let success = function (response) {

            $(_elements.divModalBodyDocumentos).html('');
            $(_elements.divModalBodyDocumentos).html(response);
            $(_elements.modalDocumentosFirmados).modal('show');

            Loading.Hide();
        }

        let error = function (response) {
            ajaxErrorMessage(response);
            Loading.Hide();
        }

        ColaboradoresService.GetDocumentosFirmadosView(getModelCuestionario(empleadoId), success, error);
    }

    return {
        Init,
        InitColaboradoresForm,
        InitColaborador
    }

}();