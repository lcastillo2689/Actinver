﻿const ColaboradoresService = (function () {
    const _urlColaboradores = `${window.location.origin}/TrabajoFlexible/Colaboradores`;
    
    const GetColaboradoresACargo = function (success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlColaboradores}/GetEmployeesView`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    }

    const GetDetalleDesempenioOKRView = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlColaboradores}/GetDetalleDesempenioOKRView`,
            cache: false,
            async: true,
            data: parameters,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    }

    const GetPlaneaGestionaColaboradorView = function (success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlColaboradores}/GetPlaneaGestionaColaboradorView`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    }

    const GetDocumentosFirmadosView = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlColaboradores}/GetDocumentosFirmadosView`,
            cache: false,
            async: true,
            data: parameters,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    }
    return {
        GetColaboradoresACargo,
        GetDetalleDesempenioOKRView,
        GetPlaneaGestionaColaboradorView,
        GetDocumentosFirmadosView
    }
})();