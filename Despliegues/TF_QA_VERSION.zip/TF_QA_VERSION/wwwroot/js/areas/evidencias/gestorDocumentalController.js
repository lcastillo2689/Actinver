﻿const GestorDocumentalController = (function () {
    let _selectCheckBoxes = true;
    let _checkAllClicked = false;
    let _sortName = "";
    let _sortDirection = "asc";
    let _filesToMove = [];
    let _actualizarOnCargaArchivosHidden = false;

    const _deleteTypes = {
        folder: "folder",
        file: "file",
        multipleSelection: "multipleSelection",
    };

    const _sortDirections = {
        asc: "asc",
        desc: "desc",
    };

    const _formularioCargarArchviosModal = {
        name: "#divCargarArchivosFormModal",
        bodyName: "#divCargarArchivosFormModalBody",
    };

    const _formularioFileNodeFormModal = {
        name: "#divFileNodeFormModal",
        bodyName: "#divFileNodeFormModalBody",
    };

    const _formularioColaboradorFormModal = {
        name: "#divColaboradorFormModal",
        bodyName: "#divColaboradorFormModalBody",
    };

    const _formularioMoverFormModal = {
        name: "#divMoverFormModal",
        bodyName: "#divMoverFormModalBody",
    };

    const Init = function () {
        toastr.options = {
            closeButton: false,
            progressBar: true,
            showDuration: "300",
            hideDuration: "1000",
            timeOut: "5000",
            extendedTimeOut: "1000",
            showEasing: "swing",
            hideEasing: "linear",
            showMethod: "fadeIn",
            hideMethod: "fadeOut",
        };

        makePorletFullWorkspace();
        $(".tooltips").tooltip();

        var elems = Array.prototype.slice.call(document.querySelectorAll(".form-check-input-switchery"));
        elems.forEach(function (html) {
            new Switchery(html, { size: "small", color: "#3598dc" });
        });

        window.onresize = function () {
            makePorletFullWorkspace();
        };

        $("#btn-view-grid").on("click", function () {
            $(this).tooltip("hide");
            $(".tooltips").tooltip();

            setCookie("isGridView", "true");
            showGridView();
        });

        $("#btn-view-list").on("click", function () {
            $(this).tooltip("hide");
            $(".tooltips").tooltip();

            setCookie("isGridView", "false");
            showListView();
        });

        $("#btn-buscar").on("click", function () {
            actualizarFilesContent();
        });

        $("#txt-buscar").keyup(function (e) {
            if (e.keyCode === 13) actualizarFilesContent();
        });

        $("#btn-cargar-archivos").on("click", function () {
            openCargarArchivosFormModal();
        });

        $("#btn-agregar-carpeta").on("click", function () {
            openFileNodeFormModal("");
        });

        $("#btn-seleccionar-colaborador").on("click", function () {
            openColaboradorFormModal("");
        });

        $("#btn-mis-evidencias").on("click", function () {
            setCookie("esVistaColaborador", 'false');
            const url = `${window.location.origin}/Evidencias/GestorDocumental/Index`;
            window.location = url;
        });

        $("#files-container").on("click", ".item-menu:not(.locked)", function () {
            const button = $(this);
            const id = button.attr("data-location-id");

            window.location = `${window.location.origin}/Evidencias/GestorDocumental/Index?id=${folderId}&colaboradorId=${colaboradorId}`;
        });

        $("#btn-borrar-seleccion").on("click", function (e) {
            e.preventDefault();
            deleteFileNodes(getSelectedFileNodeIds(), _deleteTypes.multipleSelection);
        });

        $("#btn-descargar-seleccion").on("click", function (e) {
            e.preventDefault();
            downloadFileNodes(getSelectedFileNodeIds());
        });

        $("#btn-mover-seleccion").on("click", function (e) {
            e.preventDefault();
            _filesToMove = [...getSelectedFileNodeIds()];
            openMoverFormModal($("#parentId").val());
        });
    };

    function getSelectedFileNodeIds() {
        return $(".file-chkbox:checked")
            .map((i, o) => $(o).closest(".item-content").attr("data-node-id"))
            .toArray();
    }

    const InitMenuContent = function () {
        const accesoDenegado = $("#data-acceso-denegado").val();
        if (accesoDenegado) toastr.error("No tienes permisos para acceder a la carpeta.");
    };

    const InitFileNodeForm = function () {
        setTimeout(() => {
            $("#Nombre").select();
        }, 150);

        $("#fileNodeForm").on("submit", function (e) {
            e.preventDefault();
            saveFileNode();
        });
    };

    const InitColaboradorForm = function () {
        $(".tooltips").tooltip();
        new PerfectScrollbar("#mover-content");

        $(".mover-row:not(.disabled)").on("click", function () {
            const row = $(this);
            const isSelected = row.hasClass("selected");
            if (isSelected) {
                row.removeClass("selected");
            } else {
                $(".mover-row.selected").removeClass("selected");
                row.addClass("selected");
                $("#colaboradorId").val(row.data("colaborador-id"));
            }
        });

        $("#btn-evidencias-colaborador").on("click", function () {
            consultarEvidenciasColaborador();
        });
    };

    const InitMover = function () {
        setMoverFormModalTitle();

        $(".tooltips").tooltip();
        new PerfectScrollbar("#mover-content");

        $(".mover-row:not(.disabled)").on("click", function () {
            const row = $(this);
            const isSelected = row.hasClass("selected");
            if (isSelected) {
                row.removeClass("selected");

                $("#btn-mover-carpeta").css("display", "none");
                $("#btn-mover-aqui").css("display", "");
            } else {
                $(".mover-row.selected").removeClass("selected");
                row.addClass("selected");

                $("#btn-mover-carpeta").css("display", "");
                $("#btn-mover-aqui").css("display", "none");
            }
        });

        $("#btn-mover-aqui").on("click", function () {
            const destinationFolderId = $("#CurrentFolderId").val();
            moveToFolder(destinationFolderId);
        });

        $("#btn-mover-carpeta").on("click", function () {
            const destinationFolderId = $("#mover-content .selected").attr("data-node-id");
            moveToFolder(destinationFolderId);
        });

        $("#btn-mover-agregar-carpeta").on("click", async function () {
            const { value: folderName } = await Swal.fire({
                title: "Agregar Carpeta",
                input: "text",
                inputValue: "Nueva Carpeta",
                showCancelButton: true,
                reverseButtons: true,
                confirmButtonText: "<i class='fa fa-save mr-2'></i>Guardar",
                cancelButtonText: "<i class='fa fa-times mr-2'></i>Cancelar",
                confirmButtonColor: "#34bfa3",
                cancelButtonColor: "#f4516c",
                inputValidator: (value) => {
                    let errorMessage = "";

                    if (!value) errorMessage = "El nombre es requerido.";

                    const repeated = $("#mover-content .td-folder-name span")
                        .map((i, o) => $(o).text())
                        .toArray()
                        .includes(value);
                    if (repeated) errorMessage = "Ya existe una carpeta con ese nombre.";

                    if (errorMessage) {
                        setTimeout(() => {
                            $(".swal2-content .swal2-input").select();
                        }, 0);
                        return errorMessage;
                    }
                },
                onOpen: () => {
                    $(".swal2-content .swal2-input").select();
                },
            });

            const currentFolderId = $("#CurrentFolderId").val();
            if (folderName) addFolderFromMoverForm(currentFolderId, folderName);
        });

        $("#mover-content").on("click", ".btn-entrar", function () {
            $(this).tooltip("hide");
            $(".tooltips").tooltip();

            const nodeId = $(this).closest("tr").attr("data-node-id");
            openMoverFormModal(nodeId);
        });

        $("#btn-go-back").on("click", function () {
            const nodeId = $(this).attr("data-node-id");
            openMoverFormModal(nodeId);
        });
    };

    function addFolderFromMoverForm(parentId, folderName) {
        const success = function () {
            let toastrMessage = "Carpeta agregada exitosamente.";
            actualizarFilesContent(() => toastr.success(toastrMessage));
            openMoverFormModal(parentId);
        };

        const model = {
            nombre: folderName,
            parentId: parentId,
            areaId: $("#areaId").val(),
        };
        return GestorDocumentalService.SaveFileNode(model, success, genericErrorResponse);
    }

    function consultarEvidenciasColaborador() {
        closeColaboradorFormModal();
        setCookie("esVistaColaborador", 'true');
        var colaboradorId = $("#colaboradorId").val();
        const url = `${window.location.origin}/Evidencias/GestorDocumental/Index?colaboradorId=${colaboradorId}`;
        window.location = url;
    }

    function moveToFolder(destinationFolderId) {
        const success = function (response) {
            const multipleFiles = _filesToMove.length > 1;
            _filesToMove = [];

            closeMoverFormModal();
            let toastrMessage = multipleFiles ? "Los elementos se movieron exitosamente." : "El elemento se movió exitosanente.";

            actualizarFilesContent(() => toastr.success(toastrMessage));
        };

        return GestorDocumentalService.MoveToFolder({ destinationFolderId, filesToMove: _filesToMove }, success, genericErrorResponse);
    }

    function setMoverFormModalTitle() {
        const currentFolderName = $("#CurrentFolderName").val();
        const currentFolderParentId = $("#CurrentFolderParentId").val();
        const goBackIcon = `<i id="btn-go-back" class="fa fa-arrow-left mr-2 tooltips" style="cursor: pointer;"data-node-id="${currentFolderParentId}" data-container="body" data-placement="top" data-original-title="Regresar"></i>`;
        const folderIcon = `<i class="fa fa-folder mr-2"></i>`;
        const modalTitle = `${currentFolderParentId ? goBackIcon : folderIcon} <label>${currentFolderName}</label>`;

        setModalTitle(_formularioMoverFormModal.name, modalTitle, true);
    }

    function saveFileNode() {
        const success = function (response) {
            if (response) {
                $(_formularioFileNodeFormModal.bodyName).html(response);
                $("#Nombre").focus();
            } else {
                closeFileNodeFormModal();
                let toastrMessage = $("#Id").val() ? "Cambios guardados exitosamente." : "Carpeta agregada exitosamente.";
                actualizarFilesContent(() => toastr.success(toastrMessage));
            }
        };

        return GestorDocumentalService.SaveFileNode(getFileNodeModel(), success, genericErrorResponse);
    }

    function getFileNodeModel() {
        return {
            id: $("#Id").val(),
            nombre: $("#Nombre").val(),
            parentId: $("#parentId").val(),
            areaId: $("#areaId").val(),
        };
    }

    function closeFileNodeFormModal() {
        $(_formularioFileNodeFormModal.name).modal("hide");
    }

    function closeCargarArchivosFormModal() {
        $(_formularioCargarArchviosModal.name).modal("hide");
    }

    function closeColaboradorFormModal() {
        $(_formularioColaboradorFormModal.name).modal("hide");
    }

    function closeMoverFormModal() {
        $(_formularioMoverFormModal.name).modal("hide");
    }

    const InitFilesContent = function () {
        $(".tooltips").tooltip();

        $(".file-name-tooltip").tooltip();
        $(".file-name-tooltip").on("show.bs.tooltip", function () {
            if (this && this.scrollWidth <= this.clientWidth) return false;
        });

        $("#files-container").on("click", ".folder-content img, .folder-content .file-name", function () {
            const folderId = $(this).closest(".folder-content").attr("data-node-id");
            const colaboradorId = $(this).closest(".folder-content").attr("data-colaborador-id");
            const url = `${window.location.origin}/Evidencias/GestorDocumental/Index?id=${folderId}&colaboradorId=${colaboradorId}`;
            window.location = url;
        });

        $("#files-container").on("click", ".btn-descargar", function (e) {
            e.preventDefault();
            const nodeId = $(this).closest(".item-content").attr("data-node-id");
            downloadFileNodes([nodeId]);
        });

        $("#files-container").on("click", ".btn-borrar", function (e) {
            e.preventDefault();
            const itemContent = $(this).closest(".item-content");
            const nodeId = itemContent.attr("data-node-id");
            const usuarioOwner = $(this).attr("data-user-owner");
            let type = itemContent.hasClass("folder-content") ? _deleteTypes.folder : _deleteTypes.file;
            deleteFileNodes([nodeId], type, usuarioOwner);
        });

        $("#files-container").on("click", ".btn-renombrar", function (e) {
            e.preventDefault();
            const nodeId = $(this).closest(".item-content").attr("data-node-id");
            openFileNodeFormModal(nodeId);
        });

        $("#files-container").on("click", ".btn-mover", function (e) {
            e.preventDefault();
            const nodeId = $(this).closest(".item-content").attr("data-node-id");
            _filesToMove = [nodeId];
            openMoverFormModal($("#parentId").val());
        });

        $("#list-file-check-all").on("click", function () {
            const selectAllIsChecked = $(this).prop("checked");
            const gridCheckAllChecked = $("#grid-file-check-all input").prop("checked");
            if (selectAllIsChecked != gridCheckAllChecked && _selectCheckBoxes) {
                _selectCheckBoxes = false;
                $("#grid-file-check-all").trigger("click");
                _selectCheckBoxes = true;
            }

            onFileCheckAllClicked(selectAllIsChecked);
        });

        $("#grid-file-check-all").on("click", function () {
            const selectAllIsChecked = $("#grid-file-check-all input").prop("checked");
            const listCheckAllChecked = $("#list-file-check-all").prop("checked");
            if (selectAllIsChecked != listCheckAllChecked && _selectCheckBoxes) {
                _selectCheckBoxes = false;
                $("#list-file-check-all").trigger("click");
                _selectCheckBoxes = true;
            }

            onFileCheckAllClicked(selectAllIsChecked);
        });

        $("#files-container").on("click", ".file-name.orderable-column h4", function () {
            if (_sortName === "nombre") {
                setNewSortDirection();
            } else {
                _sortName = "nombre";
                _sortDirection = _sortDirections.asc;
            }

            actualizarFilesContent();
        });

        $("#files-container").on("click", ".file-user.orderable-column h4", function () {
            if (_sortName === "usuarioModifico") {
                setNewSortDirection();
            } else {
                _sortName = "usuarioModifico";
                _sortDirection = _sortDirections.asc;
            }

            actualizarFilesContent();
        });

        $("#files-container").on("click", ".file-date.orderable-column h4", function () {
            if (_sortName === "fechaModificacion") {
                setNewSortDirection();
            } else {
                _sortName = "fechaModificacion";
                _sortDirection = _sortDirections.asc;
            }

            actualizarFilesContent();
        });

        $(".file-chkbox").change(function () {
            processSelectedItems();
        });

        $(".item-content").mouseleave(function () {
            const span = $(this).find(".dropdown");
            if (span.hasClass("show")) span.removeClass("show");

            const btn = $(this).find(".btn-opciones");
            if (btn.attr("aria-expandend") == "true") btn.attr("aria-expandend", "false");

            const menu = $(this).find(".dropdown-menu");
            if (menu.hasClass("show")) menu.removeClass("show");
        });
    };

    function setNewSortDirection() {
        if (_sortDirection === "") _sortDirection = _sortDirections.asc;
        else if (_sortDirection === _sortDirections.asc) _sortDirection = _sortDirections.desc;
        else if (_sortDirection === _sortDirections.desc) {
            _sortDirection = "";
            _sortName = "";
        }
    }

    function onFileCheckAllClicked(selectAllIsChecked) {
        _checkAllClicked = true;
        setElementsSelection(selectAllIsChecked);
        _checkAllClicked = false;
        processSelectedItems();
    }

    function showGridView() {
        $("#files-container").removeClass("list");
        $("#files-container").addClass("grid");

        $("#files-container").find(".file-items").removeClass("list");
        $("#files-container").find(".file-items").addClass("grid");

        $("#btn-view-grid").addClass("btn-info").removeClass("btn-default");
        $("#btn-view-list").removeClass("btn-info").addClass("btn-default");

        $("#grid-file-check-all").css("display", "");
    }

    function showListView() {
        $("#files-container").removeClass("grid");
        $("#files-container").addClass("list");

        $("#files-container").find(".file-items").removeClass("grid");
        $("#files-container").find(".file-items").addClass("list");

        $("#btn-view-list").addClass("btn-info").removeClass("btn-default");
        $("#btn-view-grid").removeClass("btn-info").addClass("btn-default");

        $("#grid-file-check-all").css("display", "none");
    }

    const InitCargarArchivosFormModal = function () {
        $("#DropZoneFileUpload").dblclick(function () {
            $("#file").trigger("click");
        });

        $("#file").attr("title", "");

        $(_formularioCargarArchviosModal.name).on("hidden.bs.modal", function () {
            if (_actualizarOnCargaArchivosHidden) actualizarFilesContent();
            _actualizarOnCargaArchivosHidden = false;
        });
    };

    function setElementsSelection(selectAllIsChecked) {
        let checkboxes = selectAllIsChecked ? $(".file-chkbox:not(:checked)") : $(".file-chkbox:checked");
        for (let i = 0; i < checkboxes.length; i++) checkboxes[i].click();
    }

    function processSelectedItems() {
        if (_checkAllClicked) return;

        const checkboxesChecked = $(".file-chkbox:checked").length;
        if (checkboxesChecked) showSelectedItemsToolbar();
        else hideSelectedItemsToolbar();
    }

    function showSelectedItemsToolbar() {
        $("#span-not-selected-items").css("display", "none");
        $("#selected-files-group").css("display", "");

        const selectedItems = $(".file-chkbox:checked").length;
        $("#span-selected-items").html(`${selectedItems} ${selectedItems === 1 ? "elemento seleccionado" : "elementos seleccionados"}`);
    }

    function hideSelectedItemsToolbar() {
        $("#selected-files-group").css("display", "none");
        $("#span-not-selected-items").css("display", "");
    }

    function openCargarArchivosFormModal() {
        if ($(".k-upload-files .k-file-progress").length > 0) {
            $(_formularioCargarArchviosModal.name).modal("show");
            return;
        }

        $(_formularioCargarArchviosModal.bodyName).html(cargandoInformacionLabel());
        $(_formularioCargarArchviosModal.name).modal("show");

        const success = function (response) {
            $(_formularioCargarArchviosModal.bodyName).html(response);
        };

        GestorDocumentalService.LoadCargarArchivosFormModalMarkup(getCargarArchivosModel(), success, genericErrorResponse);
    }

    function openMoverFormModal(parentId) {
        $(_formularioMoverFormModal.bodyName).html(cargandoInformacionLabel());
        $(_formularioMoverFormModal.name).modal("show");

        const success = function (response) {
            $(_formularioMoverFormModal.bodyName).html(response);
        };

        const model = {
            parentOrigenId: $("#parentId").val(),
            parentId,
            fileNodesIds: _filesToMove,
            colaboradorId: $("#colaboradorId").val()
        };
        GestorDocumentalService.LoadMoverFormModalMarkup(model, success, genericErrorResponse);
    }

    function getCargarArchivosModel() {
        return {
            areaId: $("#areaId").val(),
            parentId: $("#parentId").val(),
        };
    }

    function openFileNodeFormModal(id) {
        if (id) setModalTitle(_formularioFileNodeFormModal.name, "<i class='fa fa-pencil mr-2'></i><label>Renombrar</label>", true);
        else setModalTitle(_formularioFileNodeFormModal.name, "<i class='fa fa-folder mr-2'></i><label>Agregar Carpeta</label>", true);

        $(_formularioFileNodeFormModal.bodyName).html(cargandoInformacionLabel());
        $(_formularioFileNodeFormModal.name).modal("show");

        const success = function (response) {
            $(_formularioFileNodeFormModal.bodyName).html(response);
        };

        GestorDocumentalService.LoadFileNodeFormModalMarkup(id, success, genericErrorResponse);
    }

    function openColaboradorFormModal() {
        setModalTitle(_formularioColaboradorFormModal.name, "<i class='fa fa-users mr-2'></i><label>Selecciona un Colaborador</label>", true);
        $(_formularioColaboradorFormModal.bodyName).html(cargandoInformacionLabel());
        $(_formularioColaboradorFormModal.name).modal("show");

        const success = function (response) {
            $(_formularioColaboradorFormModal.bodyName).html(response);
        };

        GestorDocumentalService.LoadColaboradorFormModalMarkup(success, genericErrorResponse);
    }

    function deleteFileNodes(fileNodesIds, type, userOwner = "1") {
        if (userOwner == 0) {
            toastr.error("No puede eliminar un archivo o carpeta de otro usuario.");
            return;
        }
        let toastrMessage = "Carpeta eliminada exitosamente.";
        let message = "La carpeta se borrará junto con todos los elementos dentro de ella, y no podrán deshacerse los cambios. <br /><br />¿Deseas continuar?";
        let subMessage = "";
        if (type === _deleteTypes.multipleSelection) {
            message =
                fileNodesIds.length > 1
                    ? "Los elementos seleccionados se borrarán y no podrán deshacerse los cambios. <br /><br />¿Deseas continuar?"
                    : "El elemento seleccionado se borrará y no podrán deshacerse los cambios. <br /><br />¿Deseas continuar?";

            subMessage = "Si eliminas una carpeta, se borrará ésta junto con todos los elementos dentro de ella.";
            toastrMessage = "Elementos eliminados exitosamente.";
        } else if (type === _deleteTypes.file) {
            message = "El archivo se borrará y no podrán deshacerse los cambios. <br /><br />¿Deseas continuar?";
            toastrMessage = "Archivo eliminado exitosamente.";
        }

        const success = function () {
            actualizarFilesContent(() => toastr.success(toastrMessage));
        };

        const error = function (response) {
            ajaxErrorMessage(response);
        };

        confirmationMessage(
            message,
            () => {
                return GestorDocumentalService.DeleteFileNodes(fileNodesIds, success, error);
            },
            null,
            subMessage
        );
    }

    function downloadFileNodes(fileNodeIds) {
        $("#div-files-ids").html("");
        for (let i = 0; i < fileNodeIds.length; i++) {
            const fileNode = fileNodeIds[i];
            const html = $("#div-files-ids").html();
            $("#div-files-ids").html(html + `<input type="hidden" name="downloadFileIds" value="${fileNode}" />`);
        }

        DownloadsController.BlockUiForDownload("#downloadFileToken");
        $("#btnDownloadFile").click();
    }

    function actualizarFilesContent(func) {
        Loading.Show();
        const success = function (response) {
            Loading.Hide();
            $("#column-content").html(response);

            const gridCheckAllChecked = $("#grid-file-check-all input").prop("checked");
            if (gridCheckAllChecked) $("#grid-file-check-all").trigger("click");

            const listCheckAllChecked = $("#list-file-check-all").prop("checked");
            if (listCheckAllChecked) $("#list-file-check-all").trigger("click");

            hideSelectedItemsToolbar();

            if (func) func();
        };

        const error = function (response) {
            Loading.Hide();
            ajaxErrorMessage(response);
        };

        GestorDocumentalService.LoadFilesContentMarkup(getFilesContentModel(), success, error);
    }

    function getFilesContentModel() {
        return {
            areaId: $("#areaId").val(),
            parentId: $("#parentId").val(),
            query: $("#txt-buscar").val(),
            isGridView: $("#files-container > .file-items").hasClass("grid"),
            sortName: _sortName,
            sortDirection: _sortDirection,
            colaboradorId: $("#colaboradorId").val(),
        };
    }

    function makePorletFullWorkspace() {
        const portletHeight = window.innerHeight - 220;
        $("#m_portlet").css("min-height", `${portletHeight}px`);
    }

    const OnFilesSelect = function () {
        setTimeout(() => {
            setErrorMessagesToDuplicatedNames();
            setButtonsStyles();
            quitFileNameTitle();
        }, 0);
    };

    function quitFileNameTitle() {
        $(".k-upload-files .k-file .k-file-name").map((i, o) => $(o).attr("title", ""));
    }

    function setButtonsStyles() {
        const clearButton = $(".k-clear-selected");
        clearButton
            .addClass("mx-2")
            .addClass("my-2")
            .removeClass("k-button")
            .addClass("btn")
            .addClass("btn-danger")
            .html(`<i class="fa fa-times mr-2"></i>Cancelar`);

        const uploadButton = $(".k-upload-selected");

        uploadButton
            .addClass("mx-2")
            .addClass("my-2")
            .removeClass("k-button")
            .addClass("btn")
            .addClass("btn-success")
            .addClass("float-right")
            .html(`<i class="fa fa-upload mr-2"></i>Cargar`);

        $(".k-upload-files").css("border-bottom", "1px solid #e3e4e4");
        $(".k-upload").addClass("text-right");
    }

    function setErrorMessagesToDuplicatedNames() {
        const filesInFolder = $("#files-container .item-content:not(.folder-content) .file-name")
            .map((i, o) => $(o).attr("data-full-name"))
            .toArray();

        const fileNamesToUpload = [];
        $(".k-upload-files .k-toupload").map((_, o) => {
            const item = $(o);
            const fileName = item.find("span.k-file-name").text();

            if (filesInFolder.includes(fileName)) {
                item.addClass("k-file-error").removeClass("k-toupload");
                item.find("span.k-file-name").text(`${fileName} - Ya existe un archivo con este nombre.`);
            } else {
                if (fileNamesToUpload.includes(fileName)) {
                    item.addClass("k-file-error").removeClass("k-toupload");
                    item.find("span.k-file-name").text(`${fileName} - No se puede cargar más de un archivo con este nombre.`);
                } else {
                    fileNamesToUpload.push(fileName);
                }
            }
        });
    }

    function setKToUploadClassToPendingFiles() {
        const files = $(".k-upload-files .k-file:not(.k-file-success):not(.k-file-error):not(.k-file-toupload)");
        for (let i = 0; i < files.length; i++) {
            const file = $(files[i]);
            file.addClass("k-toupload");
        }
    }

    const OnFilesComplete = function () {
        validateIfUploadedFinished();
    };

    function validateIfUploadedFinished() {
        const uploadedFiles = getUploadedFiles();
        const filesToUpload = getFilesToUpload();
        const unexpectedErrors = getUnexpectedErrors();
        if (filesToUpload === 0) {
            if (unexpectedErrors === 0) {
                let message = uploadedFiles == 1 ? "El archivo se cargó exitosamente." : "Los archivos se cargaron exitosamente.";
                uploadedFiles > 0 ? actualizarFilesContent(() => toastr.success(message)) : actualizarFilesContent();
                if (uploadedFiles > 0) closeCargarArchivosFormModal();
            } else {
                if (uploadedFiles > 0) actualizarFilesContent(() => toastr.warning("No todos los archivos pudieron cargarse."));
                else actualizarFilesContent(() => toastr.error("No pudieron cargarse los archivos."));
            }
        }
    }

    function getUnexpectedErrors() {
        return $(".k-upload-files .k-file-error .k-i-warning").length;
    }

    function getFilesToUpload() {
        return $(".k-upload-files .k-file:not(.k-file-error):not(.k-file-progress):not(.k-file-success)").length;
    }

    function getUploadedFiles() {
        return $(".k-upload-files .k-file-success").length;
    }

    const OnFilesError = function (e) {
        _actualizarOnCargaArchivosHidden = true;
        const errorCode = e.XMLHttpRequest.status;
        let errorMessage = "";
        switch (errorCode) {
            case 400:
                errorMessage = e.XMLHttpRequest.responseText;
                break;
            case 413: {
                errorMessage = "El tamaño del archivo supera el límite permitido.";

                break;
            }
            default: {
                errorMessage = "No se pudo cargar el archivo. Ponte en contacto con el equipo de desarrollo.";
            }
        }

        const fileUid = e.files[0].uid;

        const icon = $(`li[data-uid='${fileUid}']`).find(".k-i-warning");
        icon.addClass("tooltips").addClass("text-danger");
        icon.attr("data-container", "body");
        icon.attr("data-placement", "top");
        icon.attr("data-original-title", errorMessage);
        $(".tooltips").tooltip();

        setKToUploadClassToPendingFiles();
        actualizarFilesContent();
    };

    const OnFilesCancel = function (e) {
        const fileNodeId = e.files[0].uid;
        GestorDocumentalService.DeleteFileNodes(fileNodeId, null, genericErrorResponse);
    };

    const OnFilesRemove = function () {
        if (getUploadedFiles() > 0) validateIfUploadedFinished();
    };

    return {
        Init,
        InitMenuContent,
        InitCargarArchivosFormModal,
        InitFilesContent,
        InitFileNodeForm,
        InitMover,
        OnFilesSelect,
        OnFilesComplete,
        OnFilesError,
        OnFilesCancel,
        OnFilesRemove,
        InitColaboradorForm,
    };
})();
