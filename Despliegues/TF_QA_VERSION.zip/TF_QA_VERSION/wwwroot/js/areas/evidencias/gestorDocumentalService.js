﻿const GestorDocumentalService = (function () {
    const url = `${window.location.origin}/Evidencias/GestorDocumental`;

    const LoadCargarArchivosFormModalMarkup = function (model, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${url}/CargarArchivosFormModal`,
            data: model,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const LoadFileNodeFormModalMarkup = function (id, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${url}/FileNodeFormModal/${id}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const LoadColaboradorFormModalMarkup = function (success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${url}/ColaboradorFormModal`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };
    
    const LoadMoverFormModalMarkup = function (model, success, error) {
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${url}/MoverFormModal`,
            data: model,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const MoveToFolder = function (model, success, error) {
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${url}/MoveToFolder`,
            data: model,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const LoadFilesContentMarkup = function (model, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${url}/FilesContent`,
            data: model,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const SaveFileNode = function (model, success, error) {
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${url}/SaveFileNode`,
            data: model,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const DeleteFileNodes = function (fileNodesIds, success, error) {
        $.ajax({
            datatype: "json",
            type: "DELETE",
            url: `${url}/DeleteFileNodes`,
            data: { fileNodesIds },
            cache: false,
            async: true,
            success: function (response) {
                if (success) success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    return {
        LoadCargarArchivosFormModalMarkup,
        LoadFileNodeFormModalMarkup,
        LoadFilesContentMarkup,
        LoadMoverFormModalMarkup,
        SaveFileNode,
        MoveToFolder,
        DeleteFileNodes,
        LoadColaboradorFormModalMarkup,
    };
})();
