﻿const SentimientosService = (function () {
    let _urlSentimientos = `${window.location.origin}/Seguimiento/Sentimientos`;

    let GetSentimientos = function (success, error) {
        console.log("js/SentimientosService");
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlSentimientos}/GetSentimientosView`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    }

    return {
        GetSentimientos,
    }
})();