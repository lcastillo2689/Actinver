select distinct snapshot_date from  sl_bss_edocta;

select * from  sl_edocta
where num_asesor = 51125
;

update sl_bss_edocta
set snapshot_date = to_date('29/04/2022', 'DD/MM/YYYY')
where snapshot_date = to_date('04/01/2022', 'DD/MM/YYYY');

delete from sl_edocta
where snapshot_date = to_date('31/03/2022', 'DD/MM/YYYY');


update sl_edocta
set Segmento = ''
where snapshot_date = to_date('04/01/2022', 'DD/MM/YYYY');


    alter table sl_edocta 
    rename column ALCANCE_FONDOS to ALCANCE_FONDOS_OLD;
    alter table sl_edocta add ALCANCE_FONDOS NUMBER(8,4);
    update sl_edocta set ALCANCE_FONDOS = ALCANCE_FONDOS_OLD;
    select ALCANCE_FONDOS, ALCANCE_FONDOS_OLD from sl_edocta;
    
    alter table sl_edocta 
    rename column CUMPLIMIENTO_FONDOS to CUMPLIMIENTO_FONDOS_OLD;
    alter table sl_edocta add CUMPLIMIENTO_FONDOS NUMBER(18,4);
    update sl_edocta set CUMPLIMIENTO_FONDOS = CUMPLIMIENTO_FONDOS_OLD;
    select CUMPLIMIENTO_FONDOS, CUMPLIMIENTO_FONDOS_OLD from sl_edocta;
    alter table sl_edocta drop column CUMPLIMIENTO_FONDOS;

    alter table sl_edocta 
    rename column ALCANCE_CLIENTES to ALCANCE_CLIENTES_OLD;
    alter table sl_edocta add ALCANCE_CLIENTES NUMBER(8,4);
    update sl_edocta set ALCANCE_CLIENTES = ALCANCE_CLIENTES_OLD;
    
    alter table sl_edocta 
    rename column CUMPLIMIENTO_CLIENTES to CUMPLIMIENTO_CLIENTES_OLD;
    alter table sl_edocta add CUMPLIMIENTO_CLIENTES NUMBER(18,4);
    update sl_edocta set CUMPLIMIENTO_CLIENTES = CUMPLIMIENTO_CLIENTES_OLD;
    alter table sl_edocta drop column CUMPLIMIENTO_CLIENTES;

    alter table sl_edocta 
    rename column ALCANCE_GENERACION to ALCANCE_GENERACION_OLD;
    alter table sl_edocta add ALCANCE_GENERACION NUMBER(8,4);
    update sl_edocta set ALCANCE_GENERACION = ALCANCE_GENERACION_OLD;
    
    alter table sl_edocta 
    rename column PORCENTAJE_PAGO to PORCENTAJE_PAGO_OLD;
    alter table sl_edocta add PORCENTAJE_PAGO NUMBER(8,4);
    update sl_edocta set PORCENTAJE_PAGO = PORCENTAJE_PAGO_OLD;
    
    alter table sl_edocta 
    rename column TOTAL_CUMPLIMIENTO to TOTAL_CUMPLIMIENTO_OLD;
    alter table sl_edocta add TOTAL_CUMPLIMIENTO NUMBER(18,4);
    update sl_edocta set TOTAL_CUMPLIMIENTO = TOTAL_CUMPLIMIENTO_OLD;

    
    alter table sl_edocta 
    rename column CUMPLIMIENTO_FONDOS_FONDOS to CUMPLIMIENTO_FONDOS_FONDOS_OLD;
    alter table sl_edocta add CUMPLIMIENTO_FONDOS_FONDOS NUMBER(8,4);
    update sl_edocta set CUMPLIMIENTO_FONDOS_FONDOS = CUMPLIMIENTO_FONDOS_FONDOS_OLD;
    
    alter table sl_edocta 
    rename column CUMPLIMIENTO_SEGUROS to CUMPLIMIENTO_SEGUROS_OLD;
    alter table sl_edocta add CUMPLIMIENTO_SEGUROS NUMBER(8,4);
    update sl_edocta set CUMPLIMIENTO_SEGUROS = CUMPLIMIENTO_SEGUROS_OLD;

    alter table sl_edocta 
    rename column ALCANCE_SEGUROS_SCORE to ALCANCE_SEGUROS_SCORE_OLD;   
    alter table sl_edocta add ALCANCE_SEGUROS_SCORE NUMBER(8,4);
    update sl_edocta set ALCANCE_SEGUROS_SCORE = ALCANCE_SEGUROS_SCORE_OLD;

    alter table sl_edocta 
    rename column CUMPLIMIENTO_CREDITO to CUMPLIMIENTO_CREDITO_OLD; 
    alter table sl_edocta add CUMPLIMIENTO_CREDITO NUMBER(8,4);
    update sl_edocta set CUMPLIMIENTO_CREDITO = CUMPLIMIENTO_CREDITO_OLD;

    alter table sl_edocta 
    rename column ALCANCE_CREDITO_SCORE to ALCANCE_CREDITO_SCORE_OLD;   
    alter table sl_edocta add ALCANCE_CREDITO_SCORE NUMBER(8,4);
    update sl_edocta set ALCANCE_CREDITO_SCORE = ALCANCE_CREDITO_SCORE_OLD;
