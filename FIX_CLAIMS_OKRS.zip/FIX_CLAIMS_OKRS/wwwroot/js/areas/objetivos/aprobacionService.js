﻿const AprobacionService = (function () {
    const _url = `${window.location.origin}/Objetivos/Aprobacion`;
    let _urlResultadoClave = `${window.location.origin}/Objetivos/Aprobacion`;

    const AddObjetivo = function (periodoEvaluacionID, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/AddObjetivo?periodoEvaluacionID=${periodoEvaluacionID}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const RemoveObjetivo = function (objetivoID, success, error) {
        $.ajax({
            datatype: "json",
            type: "DELETE",
            url: `${_url}/RemoveObjetivo?objetivoID=${objetivoID}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const LoadPeriod = function (periodo, empleadoID, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/LoadPeriod?periodo=${periodo}&empleadoID=${empleadoID}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const SaveChanges = function (model, success, error) {
        $.ajax({
            datatype: "json",
            data: model,
            type: "POST",
            url: `${_url}/SaveChanges`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const ApproveAll = function (model, success, error) {
        $.ajax({
            datatype: "json",
            data: model,
            type: "POST",
            url: `${_url}/ApproveAll`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const RejectAll = function (model, success, error) {
        $.ajax({
            datatype: "json",
            data: model,
            type: "POST",
            url: `${_url}/RejectAll`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const GetBossResultadosClave = function (periodo, empleadoID, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/GetResultadosClaveSupervisor?periodo=${periodo}&empleadoID=${empleadoID}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const GetKRView = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlResultadoClave}/AddViewRC`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const GetKRUpdateView = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlResultadoClave}/EditViewRC`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const SaveKR = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${_urlResultadoClave}/SaveKR`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const DeleteKR = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${_urlResultadoClave}/DeleteKR`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };


    const RefreshOKRView = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlResultadoClave}/RefreshOKRView`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };


    const AddTareaNoMedible = function (resultadoClaveMedicionID, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlResultadoClave}/AddTareaNoMedible?resultadoClaveMedicionID=${resultadoClaveMedicionID}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const RemoveTareaNoMedible = function (medicionTareaID, success, error) {
        $.ajax({
            datatype: "json",
            type: "DELETE",
            url: `${_urlResultadoClave}/RemoveTareaNoMedible?medicionTareaID=${medicionTareaID}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const AddParticipantes = function (model, success, error) {
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${_urlResultadoClave}/AddParticipantes`,
            data: model,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const EditParticipante = function (model, success, error) {
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${_urlResultadoClave}/EditParticipante`,
            data: model,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const GetResultadoClaveParticipante = function (resultadoClaveParticipanteID, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlResultadoClave}/GetResultadoClaveParticipante?resultadoClaveParticipanteID=${resultadoClaveParticipanteID}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const RemoveResultadoClaveParticipante = function (resultadoClaveParticipanteID, resultadoClaveId, success, error) {
        $.ajax({
            datatype: "json",
            type: "DELETE",
            url: `${_urlResultadoClave}/RemoveResultadoClaveParticipante?resultadoClaveParticipanteID=${resultadoClaveParticipanteID}&resultadoClaveId=${resultadoClaveId}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const LoadLinkedOKRs = function (periodo, empleadoID, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/GetObjetivosVinculados?periodo=${periodo}&empleadoID=${empleadoID}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const GetApprovalInformation = function (perirodoEvaluacionId, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/GetApprovalInformation?perirodoEvaluacionId=${perirodoEvaluacionId}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const ReloadPeriod = function (periodo, empleadoID, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/ReloadPeriod?periodo=${periodo}&empleadoID=${empleadoID}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const GetResultadosClaveVinculados = function (objetivoID, empleadoID, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/GetResultadosClaveVinculados?objetivoID=${objetivoID}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const GetResultadosClaveEmpleado = function (periodo, empleadoID, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/GetResultadosClaveEmpleado?periodo=${periodo}&empleadoID=${empleadoID}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };


    const GetObjetivoMedicionView = function (objetivoMedicionId, objetivoId, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/GetObjetivoMedicionesView?objetivoMedicionId=${objetivoMedicionId}&objetivoId=${objetivoId}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const ValidateMedicionExistente = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/ValidateMedicionExistente`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const SaveObjetivoMedicion = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${_url}/SaveObjetivoMedicion`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };
    const DeleteObjetivoMedicion = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${_url}/DeleteObjetivoMedicion`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const UpdatePesoTotalObejtivos = function (periodo, empleadoID, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/UpdatePesoTotalObjetivos?periodo=${periodo}&empleadoId=${empleadoID}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    }

    return {
        AddObjetivo,
        RemoveObjetivo,
        LoadPeriod,
        SaveChanges,
        ApproveAll,
        RejectAll,
        GetBossResultadosClave,
        GetKRView,
        GetKRUpdateView,
        SaveKR,
        DeleteKR,
        RefreshOKRView,
        AddTareaNoMedible,
        RemoveTareaNoMedible,
        AddParticipantes,
        EditParticipante,
        GetResultadoClaveParticipante,
        RemoveResultadoClaveParticipante,
        LoadLinkedOKRs,
        GetApprovalInformation,
        ReloadPeriod,
        GetResultadosClaveVinculados,
        GetResultadosClaveEmpleado,
        GetObjetivoMedicionView,
        ValidateMedicionExistente,
        SaveObjetivoMedicion,
        DeleteObjetivoMedicion,
        UpdatePesoTotalObejtivos
    };

})();

