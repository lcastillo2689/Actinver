﻿const PeriodosCongeladosController = (function () {

    const _btnCategoriaClass = ".btn-categoria";
    const _btnCategoriaActiveClass = "btn-primary";
    const _btnCategoriaInactiveClass = "btn-outline-primary";
    const _dataCategoria = "data-categoria";

    const Init = function () {

        $(ElementosComunesOKR.PeriodoEvaluacionElements.yearPickerSelector).on("change", function () {
            loadQuarterSelector();
        });
        loadQuarterSelector();
    };

    const SetHandlers = function () {
        $(_btnCategoriaClass).on("click", function () {
            const button = $(this);
            const categoria = button.attr(_dataCategoria);
            updateCategoriaButtonClass(categoria);

            if (categoria > 0)
                loadQuarter(categoria);
            else
                CapturaObjetivosController.LoadActiveQuarterOfYear();
            
        });
    };

    function updateCategoriaButtonClass(categoria) {
        $(_btnCategoriaClass).addClass(_btnCategoriaInactiveClass).removeClass(_btnCategoriaActiveClass);
        $(`${_btnCategoriaClass}[${_dataCategoria}=${categoria}]`)
            .addClass(_btnCategoriaActiveClass)
            .removeClass(_btnCategoriaInactiveClass);
    }

    function loadQuarterSelector() {
        const periodoOKR = $(ElementosComunesOKR.PeriodoEvaluacionElements.yearPickerSelector).datepicker("getDate");

        let parameters = {
            year: periodoOKR.getFullYear(),
            empleadoID : CapturaObjetivosController.GetEmpleadoConsultado()
        };

        let success = function (response) {
            $("#quarter-selector-section").html(response);
        }

        let error = function (response) {
            ajaxErrorMessage(response);
        }

        PeriodosCongeladosService.GetFreezedQuarters(parameters, success, error);

    }

    function loadQuarter(quarter) {
        Loading.Show();
        const periodoOKR = $(ElementosComunesOKR.PeriodoEvaluacionElements.yearPickerSelector).datepicker("getDate");
        let parameters = {
            year: periodoOKR.getFullYear(),
            quarter: quarter,
            empleadoID: CapturaObjetivosController.GetEmpleadoConsultado()
        };

        let success = function (response) {
            $(ElementosComunesOKR.ObjetivoElements.objetivosContrainer).html(response);

            $(ElementosComunesOKR.ObjetivoElements.containerObjetivosVinculadosID).html("");
            $(ElementosComunesOKR.PeriodoEvaluacionElements.conatinerApprovalInfo).html("");
            
            Loading.Hide();
        }

        let error = function (response) {
            ajaxErrorMessage(response);
            Loading.Hide();
        }

        PeriodosCongeladosService.GetFreezedQuarter(parameters, success, error);
    }

    return {
        Init,
        SetHandlers
    };

})();