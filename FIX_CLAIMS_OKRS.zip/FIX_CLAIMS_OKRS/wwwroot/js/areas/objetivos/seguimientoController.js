﻿const SeguimientoController = (function () {

    const _breadcrumb = "#clientesBreadcrumb";
    const _btnDetalle = ".btn-detalle";

    const _gridEmpleadoDireccionesEjecutivasSelectors = {
        grid: "#gridEmpleadosDireccionesEjecutivas",
        panel: "#seccion-direcciones-ejecutivas",
        btnEmpleadoSeguiminetoDetail: ".btn-detail-seguimiento",
        dataNumeroEmpleado: "data-numero-empleado",
        dataEmpleadoID: "data-empleado-id",
        txtQuery: "#txt-query-empleados",
        btnQuery: "#btn-query-empleados",
        switchShowAll: "#switch-show-all-empleados",
        btnEvaluacionEmpleado: ".btn-evaluacionEmpleado",
    };

    const _countHeadersSelectors = {
        excepcional : "#header-excepcional",
        sobresaliente : "#header-sobresaliente",
        satisfactorio : "#header-satisfactorio",
        enDesarrollo : "#header-desarrollo",
        retroPendiente: "#header-retroPendiente",
        retroEnviada: "#header-retroEnviadas",
        retroConcluida: "#header-Retroconcluidas",
        coincide: "#header-Coincide",
        noCoincide: "#header-NoCoincide"


    };

    const _gridEmpleadoDireccionesSelectors = {
        grid: "#gridEmpleadosDirecciones",
        panel: "#seccion-direcciones",
        btnEmpleadoSeguiminetoDetail: ".btn-detail-seguimiento",
        btnEvaluacionEmpleado: ".btn-evaluacionEmpleado",
        dataNumeroEmpleado: "data-numero-empleado",
        dataEmpleadoID: "data-empleado-id"
    };

    const _divContainers = {
        estadisticaRetro: "#seccion-graficasRetro"
    }

    let _directorEjecutivoSeleccionadoNumero = 0;

    const Init = function () {
        setBreadcrumb();
        setGridDetalleListeners();
        setGridVerObjetivosListeners();
        setTxtQueryListeners();
    };

    function setGridDetalleListeners() {
        $(_gridEmpleadoDireccionesEjecutivasSelectors.grid).on("click", _btnDetalle, function () {
            const button = $(this);
            const numeroEmpleado = button.attr(_gridEmpleadoDireccionesEjecutivasSelectors.dataNumeroEmpleado);
            _directorEjecutivoSeleccionadoNumero = numeroEmpleado;

            ToDirecciones();
            $(_breadcrumb).breadcrumb("showLevel", 2);
        });        
    }

    function setGridVerObjetivosListeners() {
        $(_gridEmpleadoDireccionesEjecutivasSelectors.grid).on("click", _gridEmpleadoDireccionesEjecutivasSelectors.btnEmpleadoSeguiminetoDetail, function () {
            const button = $(this);
            const empleadoID = button.attr(_gridEmpleadoDireccionesEjecutivasSelectors.dataEmpleadoID);
            SeguimientoService.ShowAprobal(empleadoID);
        });

        $(_gridEmpleadoDireccionesEjecutivasSelectors.grid).on("click", _gridEmpleadoDireccionesEjecutivasSelectors.btnEvaluacionEmpleado, function () {
            const button = $(this);
            const empleadoID = button.attr(_gridEmpleadoDireccionesEjecutivasSelectors.dataEmpleadoID);
            verAutoevaluacion(empleadoID);

        });

        $(_gridEmpleadoDireccionesSelectors.grid).on("click", _gridEmpleadoDireccionesSelectors.btnEmpleadoSeguiminetoDetail, function () {
            const button = $(this);
            const empleadoID = button.attr(_gridEmpleadoDireccionesSelectors.dataEmpleadoID);
            SeguimientoService.ShowAprobal(empleadoID);
        });

        $(_gridEmpleadoDireccionesSelectors.grid).on("click", _gridEmpleadoDireccionesSelectors.btnEvaluacionEmpleado, function () {
           
            const button = $(this);
            const empleadoID = button.attr(_gridEmpleadoDireccionesSelectors.dataEmpleadoID);
            console.log(empleadoID);
        });
    }

    function setTxtQueryListeners() {
        $(_gridEmpleadoDireccionesEjecutivasSelectors.txtQuery).keyup(function (e) {
            if (e.keyCode === 13) TablesController.ReloadGrid(_gridEmpleadoDireccionesEjecutivasSelectors.grid);
        });

        $(_gridEmpleadoDireccionesEjecutivasSelectors.btnQuery).on("click", function () {
            TablesController.ReloadGrid(_gridEmpleadoDireccionesEjecutivasSelectors.grid);
        });

        $(_gridEmpleadoDireccionesEjecutivasSelectors.switchShowAll).on("change", function () {
            TablesController.ReloadGrid(_gridEmpleadoDireccionesEjecutivasSelectors.grid);
        });
    }

    const GetGridEmpleadosDirectoresEjecutivosData = function () {
        return {
            numEmpleado: null,
            verTodos: $(_gridEmpleadoDireccionesEjecutivasSelectors.switchShowAll).prop('checked'),
            query: $(_gridEmpleadoDireccionesEjecutivasSelectors.txtQuery).val()
        };
    };

    const GetGridEmpleadosDirectoresData = function () {
        return {
            numEmpleado: _directorEjecutivoSeleccionadoNumero,
            verTodos: false,
            query: ""
        };
    };

    const OnDataBoundEmpleadosDirectoresEjecutivos = function (e) {
        TablesController.SetRightPage(_gridEmpleadoDireccionesEjecutivasSelectors.grid);
        const dataSource = TablesController.GetDataSource(_gridEmpleadoDireccionesEjecutivasSelectors.grid);
        setHeadersCounter(dataSource);
        /*setToolbarTotales("#GridEmpleadosEstatusToolbarTemplate", dataSource);*/

        tippy(".btn-detalle, .btn-detail-seguimiento", { theme: "light", animation: "scale", placement: "right", inertia: true });
        tippy(".btn-evaluacionEmpleado", { theme: "light", animation: "scale", placement: "right", inertia: true });
        TablesController.SetRightPage(_gridEmpleadoDireccionesEjecutivasSelectors.grid);
    }

    function setHeadersCounter(dataSource) {
        const aggregateResult = dataSource._aggregateResult;

        const esExcepcional = aggregateResult["EsExcepcional"] ? aggregateResult["EsExcepcional"].sum : 0;
        $(_countHeadersSelectors.excepcional).attr("data-counter", esExcepcional);

        const esSobresaliente = aggregateResult["EsSobresaliente"] ? aggregateResult["EsSobresaliente"].sum : 0;
        $(_countHeadersSelectors.sobresaliente).attr("data-counter", esSobresaliente);

        const esSatisfactorio = aggregateResult["EsSatisfactorio"] ? aggregateResult["EsSatisfactorio"].sum : 0;
        $(_countHeadersSelectors.satisfactorio).attr("data-counter", esSatisfactorio);

        const esEnDesarrollo = aggregateResult["EsEnDesarrollo"] ? aggregateResult["EsEnDesarrollo"].sum : 0;
        $(_countHeadersSelectors.enDesarrollo).attr("data-counter", esEnDesarrollo);

        const aprobados = aggregateResult["EsAprobado"] ? aggregateResult["EsAprobado"].sum : 0;
        $(_countHeadersSelectors.aprobados).attr("data-counter", aprobados);

        const retroPendiente = aggregateResult["EsRetroPendiente"] ? aggregateResult["EsRetroPendiente"].sum : 0;
        $(_countHeadersSelectors.retroPendiente).attr("data-counter", retroPendiente);

        const retroEnviada = aggregateResult["EsRetroEnviada"] ? aggregateResult["EsRetroEnviada"].sum : 0;
        $(_countHeadersSelectors.retroEnviada).attr("data-counter", retroEnviada);

        const retroConcluida = aggregateResult["EsRetroConcluida"] ? aggregateResult["EsRetroConcluida"].sum : 0;
        $(_countHeadersSelectors.retroConcluida).attr("data-counter", retroConcluida);

        const coincide = aggregateResult["EsCoinciden"] ? aggregateResult["EsCoinciden"].sum : 0;
        $(_countHeadersSelectors.coincide).attr("data-counter", coincide);

        const noCoincide = aggregateResult["EsNoCoinciden"] ? aggregateResult["EsNoCoinciden"].sum : 0;
        $(_countHeadersSelectors.noCoincide).attr("data-counter", noCoincide);

        updateCounters();
    }

    function updateCounters() {
        const counters = $('.header-chart-counter');
        for (let i = 0; i < counters.length; i++) {
            const counter = $(counters[i]);
            
            let top = counter.attr("data-counter");
            if (top == undefined)
                top = 0;

            counter.countTo({
                from: 0,
                to: top,
                speed: 1000,
                refreshInterval: 50,
                decimals: 0,
            });
        }
    }

    const OnDataBoundEmpleadoDirectores = function (e) {
        const dataSource = TablesController.GetDataSource(_gridEmpleadoDireccionesEjecutivasSelectors.grid);
        /*setToolbarTotales("#GridEmpleadosEstatusToolbarTemplate", dataSource);*/

        tippy(".btn-detalle", { theme: "light", animation: "scale", placement: "right", inertia: true });
        TablesController.SetRightPage(_gridEmpleadoDireccionesEjecutivasSelectors.grid);
    }


    function setBreadcrumb() {
        const items = [];

        const itemDireccionesEjecutivas = { name: "Dirección Ejecutiva", onClick: ToDireccionesEjecutivas };
        const itemDirecciones = { name: "Dirección", onClick: ToDirecciones };

        items.push(itemDireccionesEjecutivas);
        items.push(itemDirecciones);

        $(_breadcrumb).breadcrumb("setMaxLevel", 2);

        $(_breadcrumb).breadcrumb({
            items,
        });
    }

    function ToDireccionesEjecutivas() {
        $(_gridEmpleadoDireccionesEjecutivasSelectors.panel).slideDown(2000);
        $(_gridEmpleadoDireccionesSelectors.panel).slideUp(2000);
        TablesController.ReloadGrid(_gridEmpleadoDireccionesEjecutivasSelectors.grid);
    }

    function ToDirecciones() {
        $(_gridEmpleadoDireccionesEjecutivasSelectors.panel).slideUp(2000);
        $(_gridEmpleadoDireccionesSelectors.panel).slideDown(2000);
        TablesController.ReloadGrid(_gridEmpleadoDireccionesSelectors.grid);
    }

    function verAutoevaluacion(empleadoID) {
        Loading.Show();

        let success = function (response) {
            Loading.Hide();
            let urlEvaluacion = `${window.location.origin}/Evaluacion/Autoevaluacion/EvaluacionRevisionColaborador`;
            window.open(urlEvaluacion)
        };

        let error = function (response) {
            Loading.Hide();
            ajaxErrorMessage(response);
        };

        param = {
            empleadoId: empleadoID
        };

        SeguimientoService.VerAutoevaluacion(param, success, error);
    }

    const InitEstadisticasRetro = function (){
        getEstadisticasRetroView();
    }

    function getEstadisticasRetroView() {
        Loading.Show();

        let success = function (response) {
            $(_divContainers.estadisticaRetro).html('');
            $(_divContainers.estadisticaRetro).html(response);

            Loading.Hide();
        }

        let error = function (response) {
            Loading.Hide();
            ajaxErrorMessage(response);
        }

        SeguimientoService.GetEstadisticasRetroView(success, error);
    }

    return {
        Init,
        GetGridEmpleadosDirectoresEjecutivosData,
        GetGridEmpleadosDirectoresData,
        OnDataBoundEmpleadosDirectoresEjecutivos,
        OnDataBoundEmpleadoDirectores,
        InitEstadisticasRetro
    }

})();