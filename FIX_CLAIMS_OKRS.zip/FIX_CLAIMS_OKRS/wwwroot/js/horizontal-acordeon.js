﻿const HorizontalAcordeon = (function () {

    let scrolled = false;

    const Init = function () {
        $('input[name=rad]').change(function (e) {
            DisplayContentSlide();
        });

        DisplayContentSlide();

        $(window).on('scroll', function (e) {
            scrolled = true;
        });

        var timeout = setInterval(function () {
            /* If the page was scrolled, handle the scroll */
            if (scrolled) {
                scrolled = false;
                ChangeLabelsHeight()
            }
        }, 100);
    };

    function DisplayContentSlide() {
        const valueCheckedInput = $("input[type='radio'][name='rad']:checked").val();
        $('.content').hide();
        $(`#content-${valueCheckedInput}`).show();
        ChangeLabelsHeight()        
    }

    function ChangeLabelsHeight() {        
        const valueCheckedInput = $("input[type='radio'][name='rad']:checked").val();
        let selectedContainerHeight = $(`#content-${valueCheckedInput}`).height();
        if (selectedContainerHeight > 300) 
            $(".lbl-acordeon").height(selectedContainerHeight);
        else
            $(".lbl-acordeon").height("50vh");
        
    }


    
   


    return {
        Init
    };

})();