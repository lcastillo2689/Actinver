﻿/**
 * Controlador para desplegar las gráficas de desempeño.
 * */
const ApexChartController = (function () {
    /**
     * Variables iniciales
     * */
    let _elements = {
        apexChart: "#chartdiv",//Elemento donde se mostrará la Gráfica 1: Ubicación en Actinver.
        apexChartArea: "#chartdivArea",//Elemento donde se mostrará la Gráfica 2: Ubicación en su Dirección Ejecutiva(del empleado seleccionado).
        root: null,
        
        curvaActinver: "#1D7D9E",//color de la curva Actinver
        curvaArea: "#D4320E",//color de la curva Dirección Ejecutiva
        lineaEmpleado1: "#FFFF00",//color de la línea vertical en la Gráfica 1.
        lineaEmpleado2: "#FFFF00", //color de la línea verticad en la Gráfica 2.
        titulo1: "#1D7D9E",//color del título en la Gráfica 1.
        titulo2: "#D4320E",//color del título en la Gráfica 2.

        areaEnDesarrollo: "#DC2626",//color del área para la serie de frecuencias con desempeño 'En Desarrollo', en las gráficas 1 y 2.
        areaSatisfactorio: "#F87171",//color del área para la serie de frecuencias con desempeño 'Satisfactorio', en las gráficas 1 y 2.
        areaSobresaliente: "#A4C400",//color del área para la serie de frecuencias con desempeño 'Sobresaliente', en las gráficas 1 y 2.
        areaExcepcional: "#29B6F6",//color del área para la serie de frecuencias con desempeño 'Excepcional', en las gráficas 1 y 2.
    };

    /**
     * @constructor
     * 
     * @param {any} campanaActinver - Frecuencias de calificaciones de desempeño en Actinver.
     * @param {any} campanaArea - Frecuencia de calificaciones de desempeño en Dirección Ejecutiva del empleado.
     * @param {any} empleado - Empleado.
     * @param {any} estadisticas - Estadísticas de desempeño Actinver.
     */
    const initApexChartControl = function (campanaActinver, campanaArea, empleado, estadisticas) {
        initApexChart(campanaActinver, campanaArea, empleado, estadisticas);
    };

    /**
     * Función para configurar componente ApexChart
     * 
     * @param {any} campanaActinver - Frecuencias de calificaciones de desempeño en Actinver.
     * @param {any} campanaArea - Frecuencia de calificaciones de desempeño en Dirección Ejecutiva del empleado.
     * @param {any} empleado - Empleado.
     * @param {any} estadisticas - Estadísticas de desempeño Actinver.
     */
    function initApexChart(campanaActinver, campanaArea, empleado, estadisticas) {
        let ct = "";
        switch (empleado.CalificacionTexto) {
            case "EX":
                ct = "Excepcional";
                break;
            case "SS":
                ct = "Sobresaliente";
                break;
            case "ST":
                ct = "Satisfactorio";
                break;
            case "DS":
                ct = "En Desarrollo";
                break;
            default:
        }

        var data = dataLoadApexChart(campanaActinver, campanaArea, empleado, estadisticas)
        console.log(data);
        var options = {
            chart: {
                zoom: {
                    enabled: false,
                },
                toolbar: {
                    show: false,
                },
                height: 300,
            },
            annotations: {
                yaxis: [],
                xaxis: [{
                    x: empleado.CalificacionTotal,
                    strokeDashArray: 0,
                    width: '100%',
                    borderColor: _elements.lineaEmpleado1,
                    label: {
                        borderColor: _elements.lineaEmpleado1,
                        style: {
                            fontSize: '1px',
                            color: _elements.lineaEmpleado1,
                            background: _elements.lineaEmpleado1,
                        },
                        offsetY: -20,
                        text: "########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ##########",
                    }
                }],
                points: [{
                    x: empleado.CalificacionTotal,
                    y: data.zEmpleadoActinver,
                    marker: {
                        size: 0,
                        fillColor: '#fff',
                        strokeColor: _elements.curvaActinver,
                        radius: 2,
                        cssClass: 'apexcharts-custom-class'
                    },
                    label: {
                        borderColor: _elements.curvaActinver,
                        offsetY: 0,
                        style: {
                            color: '#fff',
                            background: _elements.curvaActinver,
                        },
                    },
                    image: {
                    }
                }]
            },
            series: [{
                    name: 'En Desarrollo',
                    type: 'area',
                    data: data.zActinverED,
                stroke: {
                    curve: "straight",
                }
                }, {
                    name: 'Satisfactorio',
                    type: 'area',
                    data: data.zActinverST,
                    stroke: {
                        curve: "straight",
                    }
                }, {
                    name: 'Sobresaliente',
                    type: 'area',
                    data: data.zActinverSS,
                    stroke: {
                        curve: "straight",
                    }
                }, {
                    name: 'Excepcional',
                    type: 'area',
                    data: data.zActinverEX,
                    stroke: {
                        curve: "straight",
                    }
                },
            ],
            xaxis: {
                name: 'Calificacion',
                categories: data.calActinver,
                type: 'numeric', 
                labels: {
                    show: false,
                },
            },
            colors: [_elements.areaEnDesarrollo, _elements.areaSatisfactorio, _elements.areaSobresaliente, _elements.areaExcepcional, "#000000"],
            markers: {
                size: 0,
                hover: {
                    sizeOffset:.1
                }
            },
            stroke: {
                width:[3],
                curve: 'smooth', 
            },
            title: {
                text: "",
                style: {
                    fontSize: '14px',
                    fontWeight: 'bold',
                    color: "#000000",
                },
            },
            tooltip: {
                intersect: true,
                shared: false
            },
            theme: {
                palette: "palette1"
            },
        }
        var chart = new ApexCharts(document.querySelector(_elements.apexChart), options);
        chart.render();

        var optionsArea = {
            chart: {
                zoom: {
                    enabled: false,
                },
                toolbar: {
                    show: false,
                },
                height: 300,
                type: 'line'
            },
            annotations: {
                yaxis: [],
                xaxis: [{
                    x: empleado.CalificacionTotal,
                    strokeDashArray: 0,
                    borderColor: _elements.lineaEmpleado2,
                    label: {
                        borderColor: _elements.lineaEmpleado1,
                        style: {
                            fontSize: '1px',
                            color: _elements.lineaEmpleado2,
                            background: _elements.lineaEmpleado2,
                        },
                        offsetY: -20,
                        text: "########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ########## ##########",
                    }
                }],
                points: [{
                    x: empleado.CalificacionTotal,
                    y: data.zEmpleadoArea,
                    marker: {
                        size: 0,
                        fillColor: '#fff',
                        strokeColor: _elements.curvaArea,
                        radius: 2,
                        cssClass: 'apexcharts-custom-class'
                    },
                    label: {
                        borderColor: _elements.curvaArea,
                        offsetY: 0,
                        style: {
                            color: '#fff',
                            background: _elements.curvaArea,
                        },
                    }
                }]
            },
            series: [{
                name: 'En Desarrollo',
                type: 'area',
                data: data.zAreaED,
                stroke: {
                    curve: "straight",
                }
            }, {
                    name: 'Satisfactorio',
                    type: 'area',
                    data: data.zAreaST,
                    stroke: {
                        curve: "straight",
                    }
                }, {
                    name: 'Sobresaliente',
                    type: 'area',
                    data: data.zAreaSS,
                    stroke: {
                        curve: "straight",
                    }
                }, {
                    name: 'Excepcional',
                    type: 'area',
                    data: data.zAreaEX,
                    stroke: {
                        curve: "straight",
                    }
                },
            ],
            yaxis: {
                min: 0,
            },
            xaxis: {
                name: 'Calificacion',
                categories: data.calArea,
                type: 'numeric',
                labels: {
                    show: false,
                },
            },
            colors: [_elements.areaEnDesarrollo, _elements.areaSatisfactorio, _elements.areaSobresaliente, _elements.areaExcepcional, "#000000"],
            markers: {
                size: 0,
                hover: {
                    sizeOffset: .1
                }
            },
            stroke: {
                width: [3],
                curve: 'smooth',
            },
            title: {
                text: "",
                style: {
                    fontSize: '14px',
                    fontWeight: 'bold',
                    color: "#000000",
                },
            },
            tooltip: {
                intersect: true,
                shared: false
            },
            theme: {
                palette: "palette1"
            },
        }
        var chartArea = new ApexCharts(document.querySelector(_elements.apexChartArea), optionsArea);
        chartArea.render();

        /**
         * Función que prepara los datos que se utilizarán en las gráficas en el componente ApexChart,
         * a partir de los datos obtenidos desde la base de datos, 
         * correspondientes a las frecuencias de calificaciones de desempeño en Actinver,
         * y a las frecuencias de calificaciones de desempeño de la Dirección Ejecutiva del empleado.
         * 
         * @param {any} campanaActinver - Frecuencias de calificaciones de desempeño en Actinver.
         * @param {any} campanaArea - Frecuencia de calificaciones de desempeño en Dirección Ejecutiva del empleado.
         * @param {any} empleado - Empleado.
         * @param {any} estadisticas - Estadísticas de desempeño Actinver.
         * 
         * @returns {JSON} - objeto JSON con los datos preparados para graficarlos.
         */
        function dataLoadApexChart(campanaActinver, campanaArea, empleado, estadisticas) {
            console.log(campanaActinver);

            /**
             * Objeto que contendrá los datos necesarios para dibujar las gráficas.
             * El eje x de las gráficas corresponden a los límites de las calificaciones, por cada una de las 4 categorías prestablecidas: 
             * 1.0 a 1.79, desempeño EN DESARROLLO.
             * 1.8 a 2.79, desempeño SATISFACTORIO.
             * 2.8 a 3.69, desempeño SOBRESALIENTE.
             * 3.7 a 4, desempeño EXCEPCIONAL.
             * 
             * */
            let arrApexChart = {
                calActinver: [],//eje x, calificaciones de la serie Actinver, gráfica Actinver.
                calActinverED: [],//eje x, calificaciones de la serie En Desarrollo, gráfica Actinver.
                calActinverST: [],//eje x, calificaciones de la serie Satisfactorio, gráfica Actinver.
                calActinverSS: [],//eje x, calificaciones de la serie Sobresaliente, gráfica Actinver.
                calActinverEX: [],//eje x, calificaciones de la serie Excepcional, gráfica Actinver.
                zActinver: [],//eje y, serie Actinver, gráfica Actinver.
                zActinverED: [],//eje y, serie En Desarrollo, gráfica Actinver.
                zActinverST: [],//eje y, serie Satisfactorio, gráfica Actinver.
                zActinverSS: [],//eje y, serie Sobresaliente, gráfica Actinver.
                zActinverEX: [],//eje y, serie Excepcional, gráfica Actinver.

                calArea: [],//eje x, calificaciones de la serie DGA, gráfica DGA.
                calAreaED: [],//eje x, calificaciones de la serie En Desarrollo, , gráfica DGA.
                calAreaST: [],//eje x, calificaciones de la serie Satisfactorio, gráfica DGA.
                calAreaSS: [],//eje x, calificaciones de la serie Sobresaliente, gráfica DGA.
                calAreaEX: [],//eje x, calificaciones de la serie Excepcional, gráfica DGA.
                zArea: [],//eje y, serie DGA, gráfica DGA.
                zAreaED: [],//eje y, serie En Desarrollo, gráfica DGA.
                zAreaST: [],//eje y, serie Satisfactorio, gráfica DGA.
                zAreaSS: [],//eje y, serie Sobresaliente, gráfica DGA.
                zAreaEX: [],//eje y, serie Excepcional, gráfica DGA.

                calEmpleado: [],//eje x, calificaciones de la serie para el empleado
                zEmpleado: [],//eje y, serie empleado, se puede utilizar en ambas gráficas.
                zEmpleadoActinver: 0,//eje y, serie empleado, para utilizarse en gráfica Actinver.
                zEmpleadoArea: 0,//eje y, serie empleado, para utilizarse en gráfica DGA.
            };

            //console.log(empleado);

            arrApexChart.calActinver.push(1);
            arrApexChart.zActinver.push(0);
            arrApexChart.calEmpleado.push(1);
            arrApexChart.zEmpleado.push(0);

            arrApexChart.calActinverED.push(1);
            arrApexChart.zActinverED.push(0);

            arrApexChart.calActinverST.push(0);
            arrApexChart.zActinverST.push(null);

            arrApexChart.calActinverSS.push(0);
            arrApexChart.zActinverSS.push(null);

            arrApexChart.calActinverEX.push(0);
            arrApexChart.zActinverEX.push(null);

            /*
             * Se recorre la lista de calificaciones, que viene de base de datos.
             */
            $.each(campanaActinver, function () {
                switch (this.CalificacionTexto) {
                    /*
                     * se agregan los valores, correspondientes a la serie de datos 'En Desarrollo', gráfica Actinver.
                     */
                    case "DS":
                        arrApexChart.calActinverED.push(this.CalificacionTotal);
                        arrApexChart.zActinverED.push(this.Z);

                        arrApexChart.calActinverST.push(this.CalificacionTotal);
                        arrApexChart.zActinverST.push(this.Z);

                        arrApexChart.calActinverSS.push(this.CalificacionTotal);
                        arrApexChart.zActinverSS.push(null);

                        arrApexChart.calActinverEX.push(this.CalificacionTotal);
                        arrApexChart.zActinverEX.push(null);
                        break;
                    /*
                     * se agregan los valores, correspondientes a la serie de datos 'Satisfactorio', gráfica Actinver.
                     */
                    case "ST":
                        arrApexChart.calActinverED.push(this.CalificacionTotal);
                        arrApexChart.zActinverED.push(null);

                        arrApexChart.calActinverST.push(this.CalificacionTotal);
                        arrApexChart.zActinverST.push(this.Z);

                        arrApexChart.calActinverSS.push(this.CalificacionTotal);
                        arrApexChart.zActinverSS.push(this.Z);

                        arrApexChart.calActinverEX.push(this.CalificacionTotal);
                        arrApexChart.zActinverEX.push(null);
                        break;
                    /*
                     * se agregan los valores, correspondientes a la serie de datos 'Sobresaliente', gráfica Actinver.
                     */
                    case "SS":
                        arrApexChart.calActinverED.push(this.CalificacionTotal);
                        arrApexChart.zActinverED.push(null);

                        arrApexChart.calActinverST.push(this.CalificacionTotal);
                        arrApexChart.zActinverST.push(null);

                        arrApexChart.calActinverSS.push(this.CalificacionTotal);
                        arrApexChart.zActinverSS.push(this.Z);

                        arrApexChart.calActinverEX.push(this.CalificacionTotal);
                        arrApexChart.zActinverEX.push(this.Z);
                        break;
                    /*
                     * se agregan los valores, correspondientes a la serie de datos 'Excepcional', gráfica Actinver.
                     */
                    case "EX":
                        arrApexChart.calActinverED.push(this.CalificacionTotal);
                        arrApexChart.zActinverED.push(null);

                        arrApexChart.calActinverST.push(this.CalificacionTotal);
                        arrApexChart.zActinverST.push(null);

                        arrApexChart.calActinverSS.push(this.CalificacionTotal);
                        arrApexChart.zActinverSS.push(null);

                        arrApexChart.calActinverEX.push(this.CalificacionTotal);
                        arrApexChart.zActinverEX.push(this.Z);
                        break;
                    default:
                }

                arrApexChart.calActinver.push(this.CalificacionTotal); 
                arrApexChart.zActinver.push(this.Z);

                arrApexChart.calEmpleado.push(this.CalificacionTotal);
                arrApexChart.zEmpleado.push(null);
            });

            arrApexChart.calArea.push(1);
            arrApexChart.zArea.push(0);

            arrApexChart.calAreaED.push(1);
            arrApexChart.zAreaED.push(0);

            arrApexChart.calAreaST.push(0);
            arrApexChart.zAreaST.push(null);

            arrApexChart.calAreaSS.push(0);
            arrApexChart.zAreaSS.push(null);

            arrApexChart.calAreaEX.push(0);
            arrApexChart.zAreaEX.push(null);

            $.each(campanaArea, function () {
                switch (this.CalificacionTexto) {
                    /*
                     * se agregan los valores, correspondientes a la serie de datos 'En Desarrollo', gráfica DGA.
                     */
                    case "DS":
                        arrApexChart.calAreaED.push(this.CalificacionTotal);
                        arrApexChart.zAreaED.push(this.Z);

                        arrApexChart.calAreaST.push(this.CalificacionTotal);
                        arrApexChart.zAreaST.push(this.Z);

                        arrApexChart.calAreaSS.push(this.CalificacionTotal);
                        arrApexChart.zAreaSS.push(null);

                        arrApexChart.calAreaEX.push(this.CalificacionTotal);
                        arrApexChart.zAreaEX.push(null);
                        break;
                    /*
                     * se agregan los valores, correspondientes a la serie de datos 'Satisfactorio', gráfica DGA.
                     */
                    case "ST":
                        arrApexChart.calAreaED.push(this.CalificacionTotal);
                        arrApexChart.zAreaED.push(null);

                        arrApexChart.calAreaST.push(this.CalificacionTotal);
                        arrApexChart.zAreaST.push(this.Z);

                        arrApexChart.calAreaSS.push(this.CalificacionTotal);
                        arrApexChart.zAreaSS.push(this.Z);

                        arrApexChart.calAreaEX.push(this.CalificacionTotal);
                        arrApexChart.zAreaEX.push(null);
                        break;
                    /*
                     * se agregan los valores, correspondientes a la serie de datos 'Sobresaliente', gráfica DGA.
                     */
                    case "SS":
                        arrApexChart.calAreaED.push(this.CalificacionTotal);
                        arrApexChart.zAreaED.push(null);

                        arrApexChart.calAreaST.push(this.CalificacionTotal);
                        arrApexChart.zAreaST.push(null);

                        arrApexChart.calAreaSS.push(this.CalificacionTotal);
                        arrApexChart.zAreaSS.push(this.Z);

                        arrApexChart.calAreaEX.push(this.CalificacionTotal);
                        arrApexChart.zAreaEX.push(this.Z);
                        break;
                    /*
                     * se agregan los valores, correspondientes a la serie de datos 'Excepcional', gráfica DGA.
                     */
                    case "EX":
                        arrApexChart.calAreaED.push(this.CalificacionTotal);
                        arrApexChart.zAreaED.push(null);

                        arrApexChart.calAreaST.push(this.CalificacionTotal);
                        arrApexChart.zAreaST.push(null);

                        arrApexChart.calAreaSS.push(this.CalificacionTotal);
                        arrApexChart.zAreaSS.push(null);

                        arrApexChart.calAreaEX.push(this.CalificacionTotal);
                        arrApexChart.zAreaEX.push(this.Z);
                        break;
                    default:
                }
                arrApexChart.calArea.push(this.CalificacionTotal);
                arrApexChart.zArea.push(this.Z);

                if (this.CalificacionTotal == empleado.CalificacionTotal) {
                    arrApexChart.zEmpleadoArea = this.Z;
                }
            });

            var jsonString = JSON.stringify(arrApexChart);// se convierte valor JavaScript a cadena JSON.
            let jsonResult = JSON.parse(jsonString);// se convierte cadena JSON a objeto JSON.
            return jsonResult;
        };//fin de dataLoadApexChart

        _elements.root = chart;
    }//fin de initApexChart

    return {
        initApexChartControl,
        _elements
    };
})();