﻿/**
 * Controlador para configurar modals y componente OrgcharJS
 * */
const EstructuraController = (function () {
    /**
     * Variables iniciales.
     * */
    let _components = {

        modal: "#modal-employee", //elemento del modal de la tarjeta del empleado
        modalTitle: "#modal-employee-titulo",//elemento del título del modal de la tarjeta del empleado
        modalBody: "#modal-body-employee",//elemento del cuerpo del modal de la tarjeta del empleado

        divContentOrgChart: "#divOrgChart",//elemento que muestra el organigrama

        modalA: "#modal-avatar",//elemento del modal para seleccionar avatar.
        modalATitle: "#modal-avatar-titulo",//elemento del título del modal para seleccionar avatar.
        modalABody: "#modal-body-avatar",//elemento del cuerpo del modal para seleccionar avatar.
    };

    /**
     * Función para iniciar controlador
     * Se revisa si ya se ha definido el avatar, para mostrar el Oranigrama.
     * De lo contrario se solicita al usuario que seleccione su avatar, antes de continuar.
     * 
     * @param {any} cuId - el ID del empleado.
     * @param {any} av - el avatar del empleado.
     */
    const initController = function (cuId, av, _rutaAvatarOrigen) {
        if (av != '') {
            getOrgChartView(cuId, _rutaAvatarOrigen);
        }
        else {
            console.log("getEmployeeParameters", getEmployeeParameters(cuId));
            configureModalAvatar("Selecciona Avatar", "Avatar", getEmployeeParameters(cuId));
        }
    };

    /**
     * Función que devuelve parámetro del empleado, en formato JSON
     * @param {any} employeeId - ID del empleado
     */
    function getEmployeeParameters(employeeId) {
        return {
            employeeId: employeeId
        }
    }

    /**
     * Función que inicializa el componente OrgChartJS
     * @param {any} employees - datos de empleados en Actinver.
     */
    const initOrgChart = function (employees) {
        OrgChartController.initOrgChartControl(employees);
    };

    /**
     * Función que inicializa el componente OrgChartJS
     * @param {any} cuId - ID del empleado autenticado
     */
    function getOrgChartView(cuId, _rutaAvatarOrigen) {
        /**
         * Método invocado cuando se obtienen los datos de forma exitosa.
         * @param {any} response
         */
        const success = function (response) {
            OrgChartController.initOrgChartControl(response, cuId, _rutaAvatarOrigen);
        };

        const error = function (response) {
            ajaxErrorMessage(response);
        };
        EstructuraService.GetOrgChartView(success, error);
    }

    /**
     * Función que configura modal Detalle del Colaborador
     * @param {any} title - Título del modal.
     * @param {any} action - Acción para seleccionar el modal correspondiente.
     * @param {any} parameters - Parámetros necesarios para mostrar el modal.
     */
    const configureModalEmployee = function (title, action, parameters) {
        $(_components.modalTitle).text(title);

        switch (action) {
            case "Detalle":
                let success = function (response) {
                    $(_components.modalBody).html(response);
                };

                let error = function (response) {
                    ajaxErrorMessage(response);
                };
                EstructuraService.GetEmployeeDetailView(parameters, success, error);

                $(_components.modal).modal('show');
                break;
            default:
        }
    }

    /**
     * Función que configura modal Selecciona un Avatar
     * @param {any} title - Título del modal.
     * @param {any} action - Acción para seleccionar el modal correspondiente
     * @param {any} parameters - Parámetros necesarios para mostrar el modal.
     */
    const configureModalAvatar = function (title, action, parameters) {
        $(_components.modalATitle).text(title);

        switch (action) {
            case "Avatar":
                let success = function (response) {
                    $(_components.modalABody).html(response);
                };

                let error = function (response) {
                    ajaxErrorMessage(response);
                };
                EstructuraService.GetAvatarView(parameters, success, error);

                $(_components.modalA).modal('show');
                break;
            default:
        }
    }

    /**
     * Función de prueba, para agregar un nodo.
     * @param {any} nodeId
     */
    function addManager(nodeId) {
        chart.addNode({ id: OrgChart.randomId(), stpid: nodeId });
    }

    /**
     * Vista previa en PDF
     * @param {any} nodeId
     */
    function nodePdfPreview(nodeId) {
        OrgChart.pdfPrevUI.show(chart, {
            format: 'A4',
            nodeId: nodeId
        });
    }

    return {
        initController,
        configureModalEmployee,
        configureModalAvatar
    }
})();