﻿/**
 * Servicios de ejecución de métodos vía ajax.
 * */
const EstructuraService = (function () {
    /**
     * La ruta de la página del organigrama.
     * */
    let _url = `${window.location.origin}/Estructura/Organizacion`;

    /**
     * Función invocada desde EstructuraController
     * @param {any} success - método invocado cuando se obtienen los datos exitosamente.
     * @param {any} error - método invocado cuando ocurre algún error.
     */
    const GetOrgChartView = function (success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/GetEmployeeOrgData`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    /**
     * Función que muestra el modal de la tarjeta de empleado Detalles del colaborador
     * @param {any} parameters
     * @param {any} success
     * @param {any} error
     */
    const GetEmployeeDetailView = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/GetEmployeeDetailView`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    /**
     * Función que muestra el modal de la selección del Avatar
     * @param {any} parameters
     * @param {any} success
     * @param {any} error
     */
    const GetAvatarView = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/GetAvatarView`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };



    return {
        GetOrgChartView,
        GetEmployeeDetailView,
        GetAvatarView
    };
})();