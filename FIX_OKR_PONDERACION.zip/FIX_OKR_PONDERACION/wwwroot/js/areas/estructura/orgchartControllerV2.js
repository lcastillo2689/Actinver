﻿const OrgChartController = (function () {

    let _elements = {
        orgChart: "orgchart"
    };

    const initOrgChartControl = function (employees) {
        //testBasicChart(dataSource);
        initOrgChart(employees);

    };

    function initOrgChart(employees) {

        getOrgChartConfiguration();
        
        var organigrama = getOrgChartAttributes();
        dataLoadOrgChart(organigrama, employees)

        setOrgEvents(organigrama);

    };

    function getOrgChartConfiguration() {

        OrgChart.templates.olivia.size = [350, 130];
        OrgChart.templates.olivia.field_0 = '<text style="font-size: 16px;" fill="#757575" x="100" y="55" data-width="220">{val}</text>';
        OrgChart.templates.olivia.field_1 = '<text style="font-size: 12px;" fill="#90A4AE" x="100" y="80" data-width="180">{val}</text>';
        OrgChart.templates.olivia.field_2 = '<text style="font-size: 10px;" fill="#90A4AE" x="310" y="105" data-width="25">{val}</text>';
        OrgChart.templates.olivia.html =
        '<foreignobject style="pointer-events: none;" class="node" x="300" y="105" width="75" height="30">{val}</foreignobject>';

        //OrgChart.templates.olivia.nodeMenuButton = "";

        OrgChart.templates.olivia.nodeCircleMenuButton = {
          radius: 18,
          x: 350,
          y: 60,
          color: "#fff",
          stroke: "#aeaeae",
        };

    };

    function getOrgChartAttributes() {

        let chart = new OrgChart(document.getElementById(_elements.orgChart), {
            template: "olivia",
            nodeMouseClick: OrgChart.action.expandCollapse,
            nodeCircleMenu: getOrgMenu(),
            nodeBinding: {
                imgs: "avatar",
                img_0: "avatar",
                field_0: "fullName",
                field_1: "title",
                field_2: "objetivos",
                html: "html"
            },
            collapse: {
                level: 1,
                allChildren: true,
                columns: 5
            },
        });

        OrgChart.loading.show(chart);
        return chart;
    };

    function dataLoadOrgChart(orgChart, dataSource) {

        let arrOrgChart = [];

        $.each(dataSource, function () {
            arrOrgChart.push({
                id: this.NumeroEmpleado,
                pid: this.NumeroEmpleadoJefe,
                fullName: this.NombreEmpleado,
                avatar: this.Avatar,
                title: this.PuestoDescripcion,//"Mi Puesto",
                objetivos: "5/5",
                html: "<span class='dot dotGreenActive'></span><span class='dot dotRed'></span>",
            });
        });

        var jsonString = JSON.stringify(arrOrgChart);
        let jsonResult = JSON.parse(jsonString);

        console.log(jsonResult);

        orgChart.load(jsonResult);

    };

    function getOrgMenu() {
        return {
            addNode: {
                icon: OrgChart.icon.user(24, 24, "#aeaeae"),
                text: "Detalle Empleado",
                color: "white"
            },
        };
    }

    function setOrgEvents(chart) {

        chart.nodeCircleMenuUI.on("click", function (sender, args) {
            switch (args.menuItem.text) {
                case "Detalle Empleado":
                    {
                        let employeeId = args.nodeId;
                        EstructuraController.configureModalEmployee("Empleado", "Detalle", getEmployeeParameters(employeeId));
                    }
                    break;
                default:
            }
        });

    }

    function testBasicChart(employees) {

        var organigrama = new OrgChart(document.getElementById(_elements.orgChart), {

            nodeBinding: {
                field_0: "fullName",
                field_1: "id"
            },
            collapse: {
                level: 1,
                allChildren: true,
                columns: 5
            },
        });


        let arrOrgChart = [];

        $.each(employees, function () {
            arrOrgChart.push({
                id: this.NumeroEmpleado,
                pid: this.NumeroEmpleadoJefe,
                fullName: this.NombreEmpleado,
                avatar: this.avatar,
                html: "<span class='dot dotGreenActive'></span><span class='dot dotRed'></span>",
                title: "Mi Puesto",
                
                
                ////tags: (this.parentID > 0) ? ["overrideMenu"] : [""]
            });
        });


        var jsonString = JSON.stringify(arrOrgChart);
        let jsonResult = JSON.parse(jsonString);

        console.log(jsonResult);

        organigrama.load(jsonResult);

    };

    function getEmployeeParameters(employeeId) {
        return {
            employeeId: employeeId
        }
    }
    
    return {
        initOrgChartControl
    };
})();