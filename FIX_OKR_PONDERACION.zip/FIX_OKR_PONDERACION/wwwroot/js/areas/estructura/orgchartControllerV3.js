﻿/**
 * The built in string object.
 * @external "../../../lib/orgchart/orgchart.js"
 * @see {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String|String}
 */

/**
 * Controlador para manejar el componente OrgChartJS
 * @see {@link https://balkan.app/OrgChartJS}
 * */
const OrgChartController = (function () {
    /**
     * Variables del controlador OrgChartController
     * */
    let _elements = {
        /**
         * El elemento div donde se mostrará el organigrama en documento HTML.
         */
        orgChart: "orgchart",
        /**
         * El objeto OrgChartJS
         */
        orga: null,
        /**
         * Lista de nodos con desempeño PENDIENTE
         */
        yellow: [],
        /**
         * Lista de nodos con desempeño EN DESARROLLO
         */
        endesarrollo: [],
        /**
         * Lista de nodos con desempeño SATISFACTORIO
         */
        satisfactorios: [],
        /**
         * Lista de nodos con desempeño SOBRESALIENTE
         */
        sobresalientes: [],
        /**
         * Lista de nodos con desempeño EXCEPCIONAL
         */
        excepcionales: [],
        /**
         * Lista de nodos que se han ido expandiendo al realizar la búsqueda de algún nodo en particular.
         */
        nodosExpandidos: [],
    };

    /**
     * Método que inicializa componente.
     * Es invocado una vez que se obtienen los datos de forma exitosa.
     * @param {any} employees - los datos de empleados a mostrar en organigrama.
     * @param {any} cuId - el ID del empleado autenticado actual.
     */
    const initOrgChartControl = function (employees, cuId, _rutaAvatarOrigen) {
        initOrgChart(employees, cuId, _rutaAvatarOrigen);
    };

    /**
     * Método principal, que configura organigrama,
     * prepara los datos para mostrarlos,
     * establece los eventos.
     * @param {any} employees - origen de datos.
     * @param {any} cuId - empleado autenticado actual.
     */
    function initOrgChart(employees, cuId, _rutaAvatarOrigen) {
        getOrgChartConfiguration(cuId);
        /**
         * El objeto OrgChartJS, del organigrama.
         * */
        var organigrama = getOrgChartAttributes(cuId);
        dataLoadOrgChart(organigrama, employees, cuId, _rutaAvatarOrigen)

        setOrgEvents(organigrama, cuId);

        _elements.orga = organigrama;
    };

    /**
     * Método que configura las diferentes plantillas del organigrama.
     * Plantilla para el organigrama en general.
     * Plantilla para los nodos.
     * Plantilla para los menús en cada nodo.
     * @param {any} cuId
     */
    function getOrgChartConfiguration(cuId) {
        /**
         * @see https://balkan.app/OrgChartJS/API/interfaces/OrgChart.options
         * 
         * */
        OrgChart.templates.olivia.size = [350, 150];// el tamaño de los nodos.
        OrgChart.templates.olivia.node = '<rect fill="url(#{randId})" x="0" y="0" height="{h}" width="{w}" stroke-width="0" stroke="#aeaeae" rx="20" ry="20"></rect>' //el rectángulo principal
            + '<rect fill="#ffffff" x="80" y="0" width="260" height="80" rx="10" ry="10" filter="url(#cool-shadow)"></rect>'//rectángulo superior
            + '<rect stroke="#eeeeee" stroke-width="0" x="10" y="85" width="250" fill="#ffffff" rx="10" ry="10" height="60"></rect>'//rectángulo inferior izquierdo
            + '<rect stroke="#eeeeee" stroke-width="0" x="265" y="85" width="80" fill="#ffffff" rx="10" ry="10" height="60"></rect>'//rectángulo inferior derecho
            ;

        OrgChart.templates.olivia.plus = '<circle cx="15" cy="15" r="15" fill="#ffffff" stroke="#aeaeae" stroke-width="1"></circle>'//círculo para desplegar nodos hijos.
            + '<text text-anchor="middle" style="font-size: 18px;cursor:pointer;" fill="#757575" x="15" y="22">{collapsed-children-count}</text>';//cantidad de nodos hijos

        /**
         * Personalización de la imagen 
         * Alineación: xMidYMid
         * Escala: meet
         * Posición: x, y
         * Tamaño: w, h
         */
        OrgChart.templates.olivia.img_0 = '<image preserveAspectRatio="xMidYMid meet" xlink:href="{val}" x="-25" y="-45" width="90" height="160"></image>';//slice meet
        /**
         * Personalización de los textos
         * */
        OrgChart.templates.olivia.field_0 = '<text style="font-size: 18px;" fill="#757575" x="100" y="25" data-width="230" data-text-overflow="multiline">{val}</text>';//fullname
        OrgChart.templates.olivia.field_1 = '<text style="font-size: 14px;" fill="#90A4AE" x="100" y="100" data-width="180" data-text-overflow="multiline">{val}</text>';//title
        OrgChart.templates.olivia.field_2 = '<text style="font-size: 10px;" fill="#90A4AE" x="310" y="105" data-width="25">{val}</text>';//objetivos
        OrgChart.templates.olivia.field_3 = '<text style="font-size: 12px;" fill="#90A4AE" x="100" y="100" data-width="180">{val}</text>';
        OrgChart.templates.olivia.field_4 = '<text style="font-size: 10px;" fill="#90A4AE" x="280" y="110" data-width="180">{val}</text>';//calificacion texto

        OrgChart.templates.olivia.html = '<foreignobject style="pointer-events: none;" class="node" x="265" y="115" width="125" height="30">{val}</foreignobject>';//semáforo de calificaciones
        OrgChart.templates.olivia.svg = '<svg style="background-color:#F9F9F9;display:block;" width="{w}" height="{h}" viewBox="{viewBox}">{content}</svg>';
        //OrgChart.templates.olivia.svg = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="background-color:#F9F9F9;display:block;" width="{w}" height="{h}" viewBox="{viewBox}">{content}</svg>';

        OrgChart.templates.olivia.nodeMenuButton = "";

        /**
         * Para cambiar color, forma del nodo
         * */
        OrgChart.templates.olivia.ripple = {
            radius: 20,
            color: "#e6e6e6",
            //rect: null
        };

        OrgChart.templates.olivia.nodeCircleMenuButton = {
            radius: 18,
            x: 350,
            y: 60,
            color: "#fff",
            stroke: "#aeaeae",
        };

    };

    /**
     * Obtiene Atributos del organigrama
     * @param {any} cuId - el ID del usuario autenticado actual
     */
    function getOrgChartAttributes(cuId) {
        OrgChart.SEARCH_RESULT_LIMIT = 20; // items mostrados al buscar
        OrgChart.SEARCH_PLACEHOLDER = "Buscar"; // the default value is "Search"
        /**
         * Creación y configuración del organigrama
         * */
        let chart = new OrgChart(document.getElementById(_elements.orgChart), {
            miniMap: false,//no se muestra minimapa del organigrama
            toolbar: {
                layout: false,//botones varios
                zoom: false,//botones zoom
                fullScreen:false //botón pantalla completa
            },
            sticky: false,
            levelSeparation: 50,//separación entre niveles
            siblingSeparation: 50,//separación entre nodos del mismo nivel
            subtreeSeparation:150,//separación entre subárboles
            //mode: 'dark',
            //orientation: OrgChart.orientation.top_left,
            //layout: OrgChart.mixed,//normal,//treeRightOffset,//tree,//
            //padding: 0,
            //scaleInitial: .7,//OrgChart.match.boundary,//OrgChart.match.height,
            template: "olivia",//"ula",//
            //mouseScrool: OrgChart.action.xScroll, //scroll,
            //showYScroll: OrgChart.scroll.visible,
            //showXScroll: OrgChart.scroll.visible,
            nodeMouseClick: OrgChart.action.expandCollapse,
            //enableDragDrop: false,//true,//
            nodeCircleMenu: getOrgMenu(),
            tags: getOrgTags(),

            dragDropMenu: {
                addInGroup: { text: "Add in group" },
                addAsChild: { text: "Add as child" },
            },

            enableSearch: true,
            searchFields: ["fullName"],
            searchDisplayField: ["fullName"],
            searchFieldsWeight: {
                name: 100,
            },
            //filterBy: 'all',
            nodeBinding: {
                img_0: "avatar",//campo avatar
                field_0: "fullName", //campo NombreEmpleado
                field_1: "title",//campo PuestoDescripcion
                field_2: "objetivos",
                field_3: "area",
                field_4: "calificacionTexto",//campo CalificacionTexto
                field_5: "aquiEstoy",
                html: "html"
            },
            linkBinding:
            {
                link_field_0: "",//"fechaAlta"
            },
            collapse: {
                level: 2,
                allChildren: true,
                columns: 5
            },
            expand: {
                nodes: [cuId],
                allChildren : false
            }
            //roots: rr//[532, 2030]
        });
        OrgChart.loading.show(chart);
        return chart;
    }

    /**
     * Prepara los datos que serán utilizados para dibujar el organigrama.
     * @param {any} orgChart - el objeto OrgChartJS.
     * @param {any} dataSource - origen de datos, la lista de empleados.
     * @param {any} cuId - el ID del empleado autenticado actual. 
     */
    function dataLoadOrgChart(orgChart, dataSource, cuId, _rutaAvatarOrigen) {
        let arrOrgChart = [];
        let rutaOrigen = "";
        if (typeof ur_baseurl !== 'undefined') {
            rutaOrigen = ur_firepass_host + ur_baseurl + "../images/av";
        }
        else {
            rutaOrigen = `${window.location}/../../images/av/`;
        }
        console.log(rutaOrigen);

        $.each(dataSource, function () {
            const _url = `${window.location.href}/../../images/av/`;
            console.log('_url', _url);
            let av = "";
            
            if (this.Avatar == null || this.Avatar == undefined) {
                av = rutaOrigen + "user.png";
            }
            else {
                av = rutaOrigen + this.Avatar;
            }
            let amarilloAgregado = false;
            const d1 = new Date();
            const d2 = new Date(this.FechaAlta);
            const dif1 = Math.abs(d1 - d2);
            const dif2 = Math.ceil(dif1 / (1000 * 60 * 60 * 24));
            if (dif2 < 60) {
                _elements.yellow.push(this.EmpleadoId);
                amarilloAgregado = true;
            }

            let calTexto = '';
            switch (this.CalificacionTexto) {
                case 'EX':
                    calTexto = 'Excepcional';
                    _elements.excepcionales.push(this.EmpleadoId);
                    break;
                case 'SS':
                    calTexto = 'Sobresaliente';
                    _elements.sobresalientes.push(this.EmpleadoId);
                    break;
                case 'ST':
                    calTexto = 'Satisfactorio';
                    _elements.satisfactorios.push(this.EmpleadoId);
                    break;
                case 'DS':
                    calTexto = 'En Desarrollo';
                    _elements.endesarrollo.push(this.EmpleadoId);
                    break;
                default:
                    calTexto = 'Pendiente';
                    if (!amarilloAgregado) {
                        _elements.yellow.push(this.EmpleadoId);
                    }
            }
            arrOrgChart.push({
                id: this.EmpleadoId,//NumeroEmpleado,//empleadoId,//
                pid: this.EmpleadoJefeId,
                //stpid: this.Nivel == 2 ? this.NumeroEmpleadoJefe : "",
                fullName: this.NombreEmpleado,//nombreEmpleado,//
                avatar: av,//avatar
                title: this.PuestoDescripcion,//puestoDescripcion,
                //objetivos: "5/5",
                fechaAlta: new Date(this.FechaAlta).toLocaleDateString('es-mx', { day: "numeric", month: "short", year: "numeric" }),
                antig: dif2,
                calificacionTotal: this.CalificacionTotal,
                calificacionTexto: calTexto,
                html: (dif2 < 60 || this.CalificacionTexto == 'PD' ? "<span class='dot2 dotRed'></span><span class='dot2 dotRedLight'></span><span class='dot2 dotGreen'></span><span class='dot2 dotBlue'></span>"
                    : (this.CalificacionTexto == 'EX' ? "<span class='dot2 dotRed'></span><span class='dot2 dotRedLight'></span><span class='dot2 dotGreen'></span><span class='dot2 dotBlueActive'></span>" : //azul
                        (this.CalificacionTexto == 'SS' ? "<span class='dot2 dotRed'></span><span class='dot2 dotRedLight'></span><span class='dot2 dotGreenActive'></span><span class='dot2 dotBlue'></span>"//verde
                            : (this.CalificacionTexto == 'ST' ? "<span class='dot2 dotRed'></span><span class='dot2 dotRedLightActive'></span><span class='dot2 dotGreen'></span><span class='dot2 dotBlue'></span>"//rojoLight
                                : "<span class='dot2 dotRedActive'></span><span class='dot2 dotRedLight'></span><span class='dot2 dotGreen'></span><span class='dot2 dotBlue'></span>")))),//rojo
                tags: this.CalificacionTexto == 'EX' ? ["tagDepEX"] : ["tagDep99"],//solo se pintan nodos con empleados con desempeño Excepcional.
            });

            if (this.EmpleadoId == cuId) {
                //AddSlink(orgChart, this.EmpleadoJefeId, this.EmpleadoId, "Aquí estoy");//se agrega linea secundaria donde se ubica el usuario autenticado actual.
            }
        });
        var jsonString = JSON.stringify(arrOrgChart);// se convierte valor JavaScript a cadena JSON.
        let jsonResult = JSON.parse(jsonString);// se convierte cadena JSON a objeto JSON.
        orgChart.load(jsonResult);
    };//fin de dataLoadOrgChart

    /**
     * Agrega línea secundaria entre dos nodos específicos.
     * @param {any} chart - el objeto OrgChartJS
     * @param {any} from - nodo donde inicia la línea
     * @param {any} to - nodo donde termina la línea
     * @param {any} label - etiqueta de la línea
     * @param {any} template - plantilla
     */
    function AddSlink(chart, from, to, label, template) {
        chart.addSlink(from, to, label, template);
    }

    /**
     * Agrega línea curva entre dos nodos específicos.
     * @param {any} chart - el objeto OrgChartJS
     * @param {any} from - nodo donde inicia la línea
     * @param {any} to - nodo donde termina la línea
     * @param {any} label - etiqueta de la línea
     * @param {any} template - plantilla
     */
    function AddClink(chart, from, to, label, template) {
        chart.addClink(from, to, label, template);
    }

    /**
     * Etiquetas para el menú
     * */
    function getOrgTags() {
        return {
            overrideMenu: {
                addNode: {
                    icon: OrgChart.icon.user(24, 24, '#aeaeae'),
                    text: "Add node",
                    color: "white"
                },
                editNode: {
                    icon: OrgChart.icon.edit(24, 24, '#aeaeae'),
                    text: "Modificar",
                    color: "white"
                },
                AvatarNode: {
                    icon: OrgChart.icon.edit(24, 24, '#aeaeae'),
                    text: "Actualizar",
                    color: "yellow"
                },
            },
            filter:
            {
                template: 'dot'
            }
        };
    }

    /**
     * Configuración menú de los nodos:
     * Icono
     * Texto
     * Color
     * */
    function getOrgMenu() {
        return {
            addNode: {
                icon: OrgChart.icon.user(24, 24, "#aeaeae"),
                text: "Detalle Empleado",
                color: "white"
            },
        };
    }

    /**
     * Evento al hacer click en el menú.
     * @param {any} chart - Objeto OrgChartJS.
     * @param {any} cuId - Id del usuario autenticado actual.
     */
    function setOrgEvents(chart, cuId) {
        /*
         * Evento que se ejecuta cuando se selecciona un item de los resultados de búsqueda         
         */
        chart.on('searchclick', function (sender, nodeId) {
            /*
             * @see {https://balkan.app/OrgChartJS/API/classes/OrgChart#center}
             * se invoca método center, del objeto chart
             * @param {any} nodeId - El nodo especificado.
             * @param {any} {} - opciones de centrado.
             * @param {any} callbak - llamada cuando la animación termina. En este caso, se expanden nodos hijos del empleado buscado.
             * 
             */
            chart.center(nodeId, {}, function () {
                let n = chart.getNode(nodeId);
                chart.expand(nodeId, n.childrenIds);

                _elements.nodosExpandidos.push(nodeId);
                chart.searchUI.hide();
            });
            return false;
        });

        /**
         * Evento que se ecuta al hacer clicj en menú de cada nodo.
         */
        chart.nodeCircleMenuUI.on("click", function (sender, args) {

            switch (args.menuItem.text) {
                case "Detalle Empleado":
                    {
                        let periodo = moment('2022-01-01').format('YYYY-MM-DD');
                        let employeeId = args.nodeId;
                        EstructuraController.configureModalEmployee("Detalle del Colaborador", "Detalle", getEmployeeParameters(periodo, employeeId));
                    }
                    break;
                default:
            }
        });
    }

    function testBasicChart(employees) {

        var organigrama = new OrgChart(document.getElementById(_elements.orgChart), {

            nodeBinding: {
                field_0: "fullName",
                field_1: "id"
            },
            collapse: {
                level: 1,
                allChildren: true,
                columns: 5
            },
        });


        let arrOrgChart = [];

        $.each(employees, function () {
            arrOrgChart.push({
                id: this.NumeroEmpleado,
                spid: this.NumeroEmpleadoJefe,
                fullName: this.NombreEmpleado,
                avatar: this.avatar,
                html: "<span class='dot dotGreenActive'></span><span class='dot dotRed'></span>",
                title: "Mi Puesto",
            });
        });


        var jsonString = JSON.stringify(arrOrgChart);
        let jsonResult = JSON.parse(jsonString);
        organigrama.load(jsonResult);
    };

    function getEmployeeParameters(periodo, employeeId) {
        return {
            periodo: periodo,
            employeeId: employeeId
        }
    }
    
    function getAvatarParameters(employeeId) {
        return {
            periodo: periodo,
            avatar: ''
        }
    }

    /**
     * Función que obtiene objeto Node con ID especificado.
     * @param {any} id - El nodo especificado.
     */
    function ObtenerNodo(id) {
        return _elements.orga.getNode(id);
    };

    /**
     * Función que centra en pantalla el nodo especificado.
     * @param {any} id - El nodo especificado.
     */
    function Centrar(id) {
        _elements.orga.center(id);
    };

    /**
     * Función que expande hijos de nodo espcificado.
     * @param {any} id - El nodo especificado.
     * @param {any} idHijos - Los nodos a expandir.
     */
    function Expandir(id, idHijos) {
        _elements.orga.expand(id, idHijos);
    };

    /**
     * Función que colapsa hijos de nodo espcificado.
     * @param {any} id - El nodo especificado.
     * @param {any} idHijos - Los nodos a colapsar.
     */
    function Colapsar(id, idHijos) {
        _elements.orga.collapse(id, idHijos);
    };

    /**
     * Función que colapsa hijos de nodo espcificado.
     * @param {any} id - El nodo especificado.
     * @param {any} IDsExpandir - Los nodos a expandir.
     * @param {any} IDsColapsar - Los nodos a colapsar.
     */
    function ExpandirColapsar(id, IDsExpandir, IDsColapsar) {
        _elements.orga.expandCollapse(id, IDsExpandir, IDsColapsar);
    };

    /**
     * Función que obtiene objeto del Organigrama, 
     * muestra el nodo del usuario autenticado actual,
     * y expande sus nodos hijos, si es que los tiene.
     * @param {any} _elem - objeto que contiene el id del usuario actual
     */
    function DondeEstoy(_elem) {
        let o = _elements.orga;
        if (o != null) {
            let n = ObtenerNodo(_elem.cuId);
            Expandir(_elem.cuId, n.childrenIds);
            Centrar(_elem.cuId)
        }
    }

    /**
     * Función que obtiene el objeto del Organigrama,
     * vuelve a dibujar el organigrama, con los nodos iniciales,
     * es decir, se muestran solamente los primeros 2 niveles.
     * @param {any} _elem - objeto que contiene la lista de nodos expandidos en las búsquedas.
     */
    function ReDibujar(_elem) {
        let o = _elements.orga;
        for (var x in _elements.nodosExpandidos) {
            let n = ObtenerNodo(_elements.nodosExpandidos[x]);
            Colapsar(_elements.nodosExpandidos[x], n.childrenIds);
        }
        if (o != null) {
            var id = 2030;
            var level = 2;
            var expandIds = [];
            var collapseIds = [];
            var nodeLevel = -1;
            for (var i in o.nodes) {
                if (!o.nodes[i].level) {
                    nodeLevel = ObtenerNivel(o, o.nodes[i]);
                }
                else {
                    nodeLevel = o.nodes[i].level;
                }
                if (nodeLevel == level && !String(o.nodes[i].id).includes("mirror") && !String(o.nodes[i].id).includes("split")) {
                    collapseIds.push(o.nodes[i].id);
                }
                else if (nodeLevel < level && !String(o.nodes[i].id).includes("mirror") && !String(o.nodes[i].id).includes("split")) {
                    expandIds.push(o.nodes[i].id);
                }
            }

            ExpandirColapsar(id, expandIds, collapseIds);
            Centrar(id);
        }

        _elements.nodosExpandidos = [];
        _elem.nodosExpandidos = [];
    }

    /**
     * Función ObtenerNivel que obtiene el nivel de un nodo.
     * o - objeto OrgChart - El organigrama.
     * node - objeto Node, de OrgChart - El nodo que se desea obtener su nivel en el organigrama.
     * Return - Numero - El nivel del nodo 'node' en el organigrama 'o'.
     * @param {any} o - objeto OrgChart
     * @param {any} node - nodo del que se desea obtener su nivel
     */
    function ObtenerNivel(o, node) {
        var pnodeId = node.pid;
        var nodeLevel = 0;
        while (pnodeId) {
            nodeLevel++;
            var currentNode = o.get(pnodeId);
            pnodeId = currentNode.pid;
        }
        return nodeLevel;
    }

    /**
     * Función que busca el siguiente nodo con la información del empleado con calificación de desempeño PENDIENTE,
     * al encontrarlo lo centra en pantalla.
     * @param {any} _elem - Objeto con ID del empleado actual con desempeño PENDIENTE
     */
    function SiguienteAmarillo(_elem) {
        let o = _elements.orga;
        let aa = _elements.yellow;
        if (aa != null && o != null) {
            if (aa.length > 0) {
                let ind = 0;
                for (let i = 0; i < aa.length; i++) {
                    if (aa[i] == _elem.cuIdAmarillo) {
                        if (i == (aa.length - 1)) {
                            ind = 0;
                        }
                        else {
                            ind = i + 1;
                        }
                        break;
                    }
                }
                _elem.cuIdAmarillo = aa[ind];
                Centrar(_elem.cuIdAmarillo);
            }
        }
    }

    /**
     * Función que busca el anterior nodo con la información del empleado con calificación de desempeño PENDIENTE,
     * al encontrarlo lo centra en pantalla.
     * @param {any} _elem - Objeto con ID del empleado actual con desempeño PENDIENTE
     */
    function AnteriorAmarillo(_elem) {
        let o = _elements.orga;
        let aa = _elements.yellow;
        if (aa != null && o != null) {
            if (aa.length > 0) {
                let ind = 0;
                for (let i = 0; i < aa.length; i++) {
                    if (aa[i] == _elem.cuIdAmarillo) {
                        if (i == 0) {
                            ind = (aa.length - 1);
                        }
                        else {
                            ind = i - 1;
                        }
                        break;
                    }
                }
                _elem.cuIdAmarillo = aa[ind];
                Centrar(_elem.cuIdAmarillo);
            }
        }
    }

    /**
     * Función que busca el siguiente nodo con la información del empleado con calificación de desempeño EN DESARROLLO,
     * al encontrarlo lo centra en pantalla.
     * @param {any} _elem - Objeto con ID del empleado actual con desempeño EN DESARROLLO
     */
    function SiguienteEnDesarrollo(_elem) {
        let o = _elements.orga;
        let aa = _elements.endesarrollo;
        if (aa != null && o != null) {
            if (aa.length > 0) {
                let ind = 0;
                for (let i = 0; i < aa.length; i++) {
                    if (aa[i] == _elem.cuIdEnDesarrollo) {
                        if (i == (aa.length - 1)) {
                            ind = 0;
                        }
                        else {
                            ind = i + 1;
                        }
                        break;
                    }
                }
                _elem.cuIdEnDesarrollo = aa[ind];
                Centrar(_elem.cuIdEnDesarrollo);
            }
        }
    }

    /**
     * Función que busca el siguiente nodo con la información del empleado con calificación de desempeño EN DESARROLLO,
     * al encontrarlo lo centra en pantalla.
     * @param {any} _elem - Objeto con ID del empleado actual con desempeño EN DESARROLLO
     */
    function AnteriorEnDesarrollo(_elem) {
        let o = _elements.orga;
        let aa = _elements.endesarrollo;
        if (aa != null && o != null) {
            if (aa.length > 0) {
                let ind = 0;
                for (let i = 0; i < aa.length; i++) {
                    if (aa[i] == _elem.cuIdEnDesarrollo) {
                        if (i == 0) {
                            ind = (aa.length - 1);
                        }
                        else {
                            ind = i - 1;
                        }
                        break;
                    }
                }
                _elem.cuIdEnDesarrollo = aa[ind];
                Centrar(_elem.cuIdEnDesarrollo);
            }
        }
    }

    /**
     * Función que busca el siguiente nodo con la información del empleado con calificación de desempeño SATISFACTORIO,
     * al encontrarlo lo centra en pantalla.
     * @param {any} _elem - Objeto con ID del empleado actual con desempeño SATISFACTORIO
     */
    function SiguienteSatisfactorio(_elem) {
        let o = _elements.orga;
        let aa = _elements.satisfactorios;
        if (aa != null && o != null) {
            if (aa.length > 0) {
                let ind = 0;
                for (let i = 0; i < aa.length; i++) {
                    if (aa[i] == _elem.cuIdSatisfactorio) {
                        if (i == (aa.length - 1)) {
                            ind = 0;
                        }
                        else {
                            ind = i + 1;
                        }
                        break;
                    }
                }
                _elem.cuIdSatisfactorio = aa[ind];
                Centrar(_elem.cuIdSatisfactorio);
            }
        }
    }

    /**
     * Función que busca el siguiente nodo con la información del empleado con calificación de desempeño SATISFACTORIO,
     * al encontrarlo lo centra en pantalla.
     * @param {any} _elem - Objeto con ID del empleado actual con desempeño SATISFACTORIO
     */
    function AnteriorSatisfactorio(_elem) {
        let o = _elements.orga;
        let aa = _elements.satisfactorios;
        if (aa != null && o != null) {
            if (aa.length > 0) {
                let ind = 0;
                for (let i = 0; i < aa.length; i++) {
                    if (aa[i] == _elem.cuIdSatisfactorio) {
                        if (i == 0) {
                            ind = (aa.length - 1);
                        }
                        else {
                            ind = i - 1;
                        }
                        break;
                    }
                }
                _elem.cuIdSatisfactorio = aa[ind];
                Centrar(_elem.cuIdSatisfactorio);
            }
        }
    }

    /**
     * Función que busca el siguiente nodo con la información del empleado con calificación de desempeño SOBRESALIENTE,
     * al encontrarlo lo centra en pantalla.
     * @param {any} _elem - Objeto con ID del empleado actual con desempeño SOBRESALIENTE
     */
    function SiguienteSobresaliente(_elem) {
        let o = _elements.orga;
        let aa = _elements.sobresalientes;
        if (aa != null && o != null) {
            if (aa.length > 0) {
                let ind = 0;
                for (let i = 0; i < aa.length; i++) {
                    if (aa[i] == _elem.cuIdSobresaliente) {
                        if (i == (aa.length - 1)) {
                            ind = 0;
                        }
                        else {
                            ind = i + 1;
                        }
                        break;
                    }
                }
                _elem.cuIdSobresaliente = aa[ind];
                Centrar(_elem.cuIdSobresaliente);
            }
        }
    }

    /**
     * Función que busca el siguiente nodo con la información del empleado con calificación de desempeño SOBRESALIENTE,
     * al encontrarlo lo centra en pantalla.
     * @param {any} _elem - Objeto con ID del empleado actual con desempeño SOBRESALIENTE
     */
    function AnteriorSobresaliente(_elem) {
        let o = _elements.orga;
        let aa = _elements.sobresalientes;
        if (aa != null && o != null) {
            if (aa.length > 0) {
                let ind = 0;
                for (let i = 0; i < aa.length; i++) {
                    if (aa[i] == _elem.cuIdSobresaliente) {
                        if (i == 0) {
                            ind = (aa.length - 1);
                        }
                        else {
                            ind = i - 1;
                        }
                        break;
                    }
                }
                _elem.cuIdSobresaliente = aa[ind];
                Centrar(_elem.cuIdSobresaliente);
            }
        }
    }

    /**
     * Función que busca el siguiente nodo con la información del empleado con calificación de desempeño EXCEPCIONAL,
     * al encontrarlo lo centra en pantalla.
     * @param {any} _elem - Objeto con ID del empleado actual con desempeño EXCEPCIONAL
     */
    function SiguienteExcepcional(_elem) {
        let o = _elements.orga;
        let aa = _elements.excepcionales;
        if (aa != null && o != null) {
            if (aa.length > 0) {
                let ind = 0;
                for (let i = 0; i < aa.length; i++) {
                    if (aa[i] == _elem.cuIdExcepcional) {
                        if (i == (aa.length - 1)) {
                            ind = 0;
                        }
                        else {
                            ind = i + 1;
                        }
                        break;
                    }
                }
                _elem.cuIdExcepcional = aa[ind];
                Centrar(_elem.cuIdExcepcional);
            }
        }
    }

    /**
     * Función que busca el siguiente nodo con la información del empleado con calificación de desempeño EXCEPCIONAL,
     * al encontrarlo lo centra en pantalla.
     * @param {any} _elem - Objeto con ID del empleado actual con desempeño EXCEPCIONAL
     */
    function AnteriorExcepcional(_elem) {
        let o = _elements.orga;
        let aa = _elements.excepcionales;
        if (aa != null && o != null) {
            if (aa.length > 0) {
                let ind = 0;
                for (let i = 0; i < aa.length; i++) {
                    if (aa[i] == _elem.cuIdExcepcional) {
                        if (i == 0) {
                            ind = (aa.length - 1);
                        }
                        else {
                            ind = i - 1;
                        }
                        break;
                    }
                }
                _elem.cuIdExcepcional = aa[ind];
                Centrar(_elem.cuIdExcepcional);
            }
        }
    }

    return {
        initOrgChartControl,
        _elements,
        DondeEstoy,
        ReDibujar,
        SiguienteAmarillo,
        AnteriorAmarillo,
        SiguienteEnDesarrollo,
        AnteriorEnDesarrollo,
        SiguienteSatisfactorio,
        AnteriorSatisfactorio,
        SiguienteSobresaliente,
        AnteriorSobresaliente,
        SiguienteExcepcional,
        AnteriorExcepcional
    };
})();