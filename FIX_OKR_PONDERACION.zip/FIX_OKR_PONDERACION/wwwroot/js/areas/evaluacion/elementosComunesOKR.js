﻿const ElementosComunesOKR = (function () {

    const PeriodoEvaluacionElements = {
        yearPickerSelector: "#year-date-picker",
        periodoEvaluacionID: "#PeriodoEvaluacionID",
        btnAproveAll: "#btn-aprobar-todo",
        btnRejectAll: "#btn-rechazar-todo",
        txtMotivoRechazo: "#txt-motivo-rechazo",
        btnConfirmRejectAll: "#btn-confirm-reject-all",
        btnCloseModalRejectAll: "#close-modal-reject-all",
        conatinerApprovalInfo: "#info-aprobaciones-section"
    };

    const ObjetivoElements = {
        startDateObjetivo: "#start-date-objetivo",
        endDateObjetivo: "#end-date-objetivo",
        tipoMedicionObjetivo: "#tipo-medicion-objetivo-",
        valorMedicionObjetivo: "#valor-medicion-objetivo",
        areaObjetivoIDPartial: "area-objetivo-",
        btnResultadosClaveSuperiorSelector: "#btn-link-resultado-clave",
        resultadoClaveVinculadoID: "#ResultadoClaveVinculadoID",
        resultadoClaveVinculadoClass: ".vincula-resultado-clave",
        btnModalResultadoClaveSuperiorCloseID: "#close-modal-rc",
        btnEnviarAprobacion: "#btn-enviar-aprobacion",
        objetivosContrainer: "#alta-objetivos-container",
        objetivoContainerClass: ".objetivo-container",
        hdnObjetivoID: "#ObjetivoID",
        addObjetivoClass: ".add-objetivo",
        btnGuardar: "#btn-guardar",
        btnOKRNivelSuperior: "#btn-okrs-nivel-superior",
        acordionObjetivosID: "#accordionExample8",
        objetivoFormIDPartial: "#form-objetivo-",
        objetivoFormClass: ".objetivo-form",
        addResultadoClaveClass: ".add-resultado-clave",
        deleteObjetivoClass: ".delete-objetivo",
        txtDescripcionObjetivoID: "#DescripcionObjetivo",
        modalResultadoClaveSuperiorBodyID: "#modal-resultados-clave-body",
        comboDimensionObjetivoIDPartial: "#dimension-objetivo-",
        chkResultadoClaveSuperiorSelector: "input[name='radioRC']",
        chkResultadoClaveSuperiorIDData: "resultado-clave-id",
        containerResultadosClavePartialClass: ".container-resultados-clave-",
        containerObjetivosVinculadosID: "#consulta-objetivos-vinculados",
        ddlDireccionEjecutivaRCFilter: "#ddl-direcciones-ejecutivas-filtro-rc",
        ddlAreasRCFilter: '#ddl-areas-filtro-rc',
        ddlEmpleadosRCFilter: "#ddl-empleado-filtro-rc",
        containerResultadosClaveVinculacionListID: "#container-resultado-clave-vinculado-list",
        btnMustraResultadosClaveJefeID: "#btn-show-rc-nivel-superior",
        btnMustraResultadosClaveFiltradosID: "#btn-show-rc-filtered",
        btnDesvinculaResultadoClave: "#btn-unlink-resultado-clave",
        btnExportarExcel: "#btn-export-excel",
        addObjetivoMedicionClass: ".add-MedicionObjetivo",
        btnDeleteObjetivoMedicion: "#btn-deleteObjetivoMedicion",
        btnEditObjetivoMedicion: "#btn-editObjetivoMedicion",
        modalObjetivoMediciones: "#modal-medicionesObjetivo",
        btnGuardarMedicionObjetivo: "#btn-saveObjetivoMedicion-",
        containerObjetivoMediciones: "#div-ObjetivoMedicionesContainer-",
        modalBodyObjetivoMedicion: "#modal-medicionObjetivo-body",
        txtObjetivoMedicionHidden: "#txtHiddenObjetivo",
        txtMedicionPonderacion: "#valor-medicion-ponderacion",
        lnkPorcentajeMediciones: ".lnk-porcentajeMedicion",
        txtObjetivoMedicionIDHidden: "#txtHiddenObjetivoMedicionId",
        chkTipoMedicionMedible: "#chk-TipoMedicion-Medible",
        chkBenchmarkFormula: "#chk-benchmarkFormula",
        containerBenchmarkFormula: ".benchmarkFormula-container",
        txtBenchmarkMedicion: "#txtBenchemark",
        txtFormulaMedicion: "#txtFormula",
        txtObjetivoPondracion: "#txt-PonderacionObjetivo",
        containerSubHeaderLayout: "#sub-HeaderContainer",
        btnToggleMostrarKPIsPartialID: "#btn-toggle-mostrar-kpis-objetivo-",
        containerKPIsPartialID: "#container-kpis-",
        btnObjetivoDetalle: "#btn-objetivoDetalle-"
    };

    const ResultadoClaveElements = {
        btnKRNext: "#btn-kr-next",
        btnKRBack: "#btn-kr-back",
        btnKRFinish: "#btn-kr-finish",
        btnCloseModal: "#btn-close-kr-modal",
        txtDescripcionKR: "#Descripcion",
        txtHiddenObjetivo: "#kr-Objetivo",
        txtHiddenResultadoClave: "#kr-ResultadoClave",
        datePickerStart: "#kr-dateInit-picker",
        datePickerEnd: "#kr-dateEnd-picker",
        objetivoStartDatePicker: "#start-date-objetivo",
        objetivoEndDatePicker: "#end-date-objetivo",
        ddlFrecuencia: "#frecuencia-resultadoClave",
        frmDescripcion: "frm-DescripcionKR",
        modal: "#modal-okr",
        modalTitle: "#modal-okr-titulo",
        modalBody: "#modal-body-okr",
        cardPartialControlName: "#card-okr-data-",
        cardPartialBtnDeleteName: "#btn-Deleteokr-",
        cardPartialBtnDetailDescriptionName: "#btn-detailDescription-",
        cardDataKRID: "data-kr-id",
        cardDataObjetivoID: "data-objetivo"
    };

    const MedicionElements = {
        resultadoClaveMedicionID: '#ResultadoClaveMedicionID',
        medicionTareaID: '#MedicionTareaID',
        btnAddTareaNoMedible: '#add-tarea-no-medible',
        chkMedibleNoMedible: '#chk-medicion',
        containerTareasNoMedibles: '#medicion-no-medible-body',
        containerMedible: '#medicion-medible',
        containerNoMedible: '#medicion-no-medible',
        ddlTipoMedicion: '#tipo-medicion-resultado-clave-',
        txtValorMedicion: '#valor-medicion',
        tareaNoMedibleClass: '.tarea-no-medible',
        descripcionTareaNoMedibleClass: '.descripcion-tarea-no-medible',
        btnRemoveTareaNoMedible: '.remove-tarea-no-medible'
    }

    const ParticipantesElements = {
        ddlDireccionesEjecutivas: '#ddl-direcciones-ejecutivas',
        ddlAreas: '#ddl-areas',
        ddlEmpleados: '#ddl-empleado',
        btnAgregarParticipante: '#btn-guardar-participante',
        btnCancelaEdicion: '#btn-cancela-edicion',
        empleadoParticipanteID: '#EmpleadoParticipanteID',
        txtExplicacionParticipante: '#txt-explicacion-participante',
        panelParticipantes: '#panel-participantes',
        participantesDetailDescriptionClass: '.participante-detail-description',
        dataResultadoClaveParticipanteID: 'data-resultado-clave-participante-id',
        btnEditParticipanteClass: '.btn-edit-participante',
        btnDeleteParticipanteClass: '.btn-delete-participante',
        btnCloseModalEditParticipante: '.close-modal-edit-participante',
        modalParticipanteID: '#modal-edit-participante',
        empleadoParticipanteEditID: '#empleado-participante-modificado-id',
        resultadoClaveParticipanteEditID: '#resultado-clave-participante-modificado-id',
        empleadoEditNombre: '#empleado-modificado-nombre',
        txtMotivoParticipanteEdit: '#motivo-participacion-edicion',
        btnSaveParticipanteEdit: '#save-participante-edit'
    };


    return {
        PeriodoEvaluacionElements,
        ObjetivoElements,
        ResultadoClaveElements,
        MedicionElements,
        ParticipantesElements
    };

})();