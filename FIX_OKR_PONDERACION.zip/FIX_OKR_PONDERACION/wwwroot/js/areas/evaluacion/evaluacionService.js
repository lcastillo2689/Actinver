﻿const EvaluacionService = (function () {

    let _urlAutoevaluacion = `${window.location.origin}/Evaluacion/Autoevaluacion`;
    let _urlObjetivos = `${window.location.origin}/Evaluacion/Objetivos`;
    let _urlRetroalimentacion = `${window.location.origin}/Evaluacion/Retroalimentacion`;

    //#region Autoevaluacion

    let GetEvaluacionView = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlAutoevaluacion}/GetAutoevaluacionView?periodoId=${parameters}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    }

    let GetEvaluacionRevisionView = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlAutoevaluacion}/GetAutoevaluacionRevisionView`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    }

    let GetObjetivoView = function (parameters, success, error) {
        
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlObjetivos}/GetObjetivoView`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    }

    const SaveObjetivoResultado = function (parameters, success, error) {
        console.log(parameters);
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${_urlObjetivos}/SaveObjetivoResultado`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const RateObjetivo = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${_urlObjetivos}/RateObjetivo`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const SendToRevision = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${_urlAutoevaluacion}/EnviarARevision`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const FinalizarEvaluacion = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${_urlAutoevaluacion}/FinalizarEvaluacion`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const GetResultadoView = function (parameters, success, error) {
        console.log(parameters);
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlAutoevaluacion}/GetResultadosView`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    }

    const UpdatePesoTotalObejtivos = function (evaluacionId, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlAutoevaluacion}/UpdatePesoTotalObjetivos?evaluacionId=${evaluacionId}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    }

    const ClearPesoTotalObejtivos = function (success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlAutoevaluacion}/ClearPesoTotalObejtivos`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    }

    const VerAutoevaluacionRevision = function (parameters, success, error) {
        $.ajax({
            dataype: "json",
            contentType: 'application/json; charset=utf-8',
            type: "GET",
            url: `${_urlAutoevaluacion}/GetAutoevaluacionEmpleadoRevision`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            }
        });
    };

    const ValidarObjetivosAprobados = function (success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlAutoevaluacion}/ValidarObjetivosAprobados`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    }

    const GetNuevosObjetivosAEvaluacion = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            contentType: 'application/json; charset=utf-8',
            url: `${_urlObjetivos}/GetNuevosObjetivosAEvaluacion`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    }

    const AddNuevoObjetivoAutoevaluacion = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${_urlObjetivos}/AddNuevoObjetivoAutoevaluacion`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const GetObjetivosEvaluacion = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            contentType: 'application/json; charset=utf-8',
            url: `${_urlObjetivos}/GetObjetivosEvaluacion`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    }
    const RechazarEvaluacion = function (parameters, success, error) {
        console.log(parameters);
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${_urlAutoevaluacion}/RechazarEvaluacion`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };
    //#endregion

    //#region Retroalimentacion
    let GetEvaluacionRetroalimentacionView = function (success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlRetroalimentacion}/GetEvaluacionRetroalimentacionView`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    }

    const SaveRetroalimentacion = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${_urlRetroalimentacion}/SaveRetroAlimentacion`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    //#endregion

    //#region ResultadosClave
    let GetResultadoClaveView = function (parameters, success, error) {
        console.log(parameters);
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlObjetivos}/GetResultadosClaveView`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    }

    let GetDetalleResultadoClaveView = function (parameters, success, error) {
        console.log(parameters);
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlObjetivos}/GetDetalleResultadoClaveView`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    let DeleteObjetivoEvaluacion = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${_urlObjetivos}/DeleteObjetivoEvaluacion`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };
    //#endregion
    return {
        GetEvaluacionView,
        GetObjetivoView,
        DeleteObjetivoEvaluacion,
        SaveObjetivoResultado,
        RateObjetivo,
        SendToRevision,
        GetEvaluacionRevisionView,
        FinalizarEvaluacion,
        GetResultadoView,
        GetEvaluacionRetroalimentacionView,
        UpdatePesoTotalObejtivos,
        ClearPesoTotalObejtivos,
        VerAutoevaluacionRevision,
        GetNuevosObjetivosAEvaluacion,
        AddNuevoObjetivoAutoevaluacion,
        GetObjetivosEvaluacion,
        RechazarEvaluacion,

        SaveRetroalimentacion,
        ValidarObjetivosAprobados,

        GetResultadoClaveView,
        GetDetalleResultadoClaveView
    }
})();