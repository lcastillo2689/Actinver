﻿const ConsultaOKRService = (function () {
    let _urlResultadoClave = `${window.location.origin}/Objetivos/Consulta`;

    const GetKRView = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlResultadoClave}/AddView`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const GetKRUpdateView = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlResultadoClave}/ReadKeyResultView`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const SaveKR = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${_urlResultadoClave}/SaveKR`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const DeleteKR = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${_urlResultadoClave}/DeleteKR`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };


    const RefreshOKRView = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlResultadoClave}/RefreshOKRView`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };


    const AddTareaNoMedible = function (resultadoClaveMedicionID, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlResultadoClave}/AddTareaNoMedible?resultadoClaveMedicionID=${resultadoClaveMedicionID}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const RemoveTareaNoMedible = function (medicionTareaID, success, error) {
        $.ajax({
            datatype: "json",
            type: "DELETE",
            url: `${_urlResultadoClave}/RemoveTareaNoMedible?medicionTareaID=${medicionTareaID}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const AddParticipantes = function (model, success, error) {
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${_urlResultadoClave}/AddParticipantes`,
            data: model,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const EditParticipante = function (model, success, error) {
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${_urlResultadoClave}/EditParticipante`,
            data: model,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const GetResultadoClaveParticipante = function (resultadoClaveParticipanteID, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlResultadoClave}/GetResultadoClaveParticipante?resultadoClaveParticipanteID=${resultadoClaveParticipanteID}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const RemoveResultadoClaveParticipante = function (resultadoClaveParticipanteID, resultadoClaveId, success, error) {
        $.ajax({
            datatype: "json",
            type: "DELETE",
            url: `${_urlResultadoClave}/RemoveResultadoClaveParticipante?resultadoClaveParticipanteID=${resultadoClaveParticipanteID}&resultadoClaveId=${resultadoClaveId}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    return {
        GetKRView,
        GetKRUpdateView,
        SaveKR,
        DeleteKR,
        RefreshOKRView,
        AddTareaNoMedible,
        RemoveTareaNoMedible,
        AddParticipantes,
        EditParticipante,
        GetResultadoClaveParticipante,
        RemoveResultadoClaveParticipante
    }
})();