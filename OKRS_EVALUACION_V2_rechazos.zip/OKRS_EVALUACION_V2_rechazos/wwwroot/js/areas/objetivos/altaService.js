﻿const AltaService = (function () {
    const _url = `${window.location.origin}/Objetivos/Alta`;
    const _urlRC = `${window.location.origin}/Objetivos/ResultadoClave`;

    const AddObjetivo = function (periodoEvaluacionID, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/AddObjetivo?periodoEvaluacionID=${periodoEvaluacionID}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const RemoveObjetivo = function (objetivoID, success, error) {
        $.ajax({
            datatype: "json",
            type: "DELETE",
            url: `${_url}/RemoveObjetivo?objetivoID=${objetivoID}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const AddResultadoClave = function (objetivoID, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/AddResultadoClave?objetivoID=${objetivoID}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const RemoveResultadoClave = function (resultadoClaveID, success, error) {
        $.ajax({
            datatype: "json",
            type: "DELETE",
            url: `${_url}/RemoveResultadoClave?resultadoClaveID=${resultadoClaveID}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const LoadPeriod = function (periodo, empleadoID, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/LoadPeriod?periodo=${periodo}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const SaveChanges = function (model, success, error) {
        $.ajax({
            datatype: "json",
            data: model,
            type: "POST",
            url: `${_url}/SaveChanges`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const SendToApproval = function (model, success, error) {
        $.ajax({
            datatype: "json",
            data: model,
            type: "POST",
            url: `${_url}/SendToApproval`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const BossObjectives = function (periodo) {
        const url = `${window.location.origin}/Objetivos/Consulta/Index?periodo=${periodo}`;
        window.open(url, '_blank').focus();
    };    

    const LoadLinkedOKRs = function (periodo, empleadoID, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/GetObjetivosVinculados?periodo=${periodo}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const GetApprovalInformation = function (perirodoEvaluacionId, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/GetApprovalInformation?perirodoEvaluacionId=${perirodoEvaluacionId}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const ReloadPeriod = function (periodo, empleadoID, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/ReloadPeriod?periodo=${periodo}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const GetBossResultadosClave = function (periodo, empleadoID, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/GetResultadosClaveSupervisor?periodo=${periodo}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const GetResultadosClaveVinculados = function (objetivoID, empleadoID, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/GetResultadosClaveVinculados?objetivoID=${objetivoID}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const GetResultadosClaveEmpleado = function (periodo, empleadoID, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/GetResultadosClaveEmpleado?periodo=${periodo}&empleadoID=${empleadoID}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const GetObjetivoMedicionView = function (objetivoMedicionId, objetivoId, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/GetObjetivoMedicionesView?objetivoMedicionId=${objetivoMedicionId}&objetivoId=${objetivoId}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const SaveObjetivoMedicion = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${_url}/SaveObjetivoMedicion`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };
    const DeleteObjetivoMedicion = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${_url}/DeleteObjetivoMedicion`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const ValidateMedicionExistente = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/ValidateMedicionExistente`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const UpdatePesoTotalObejtivos = function (periodo,empleadoId, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/UpdatePesoTotalObjetivos?periodo=${periodo}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    }

    return {
        AddObjetivo,
        RemoveObjetivo,
        AddResultadoClave,
        RemoveResultadoClave,
        LoadPeriod,
        SaveChanges,
        SendToApproval,
        BossObjectives,        
        LoadLinkedOKRs,
        GetApprovalInformation,
        ReloadPeriod,
        GetBossResultadosClave,
        GetResultadosClaveVinculados,
        GetResultadosClaveEmpleado,
        GetObjetivoMedicionView,
        SaveObjetivoMedicion,
        DeleteObjetivoMedicion,
        ValidateMedicionExistente,
        UpdatePesoTotalObejtivos,
    };

})();

