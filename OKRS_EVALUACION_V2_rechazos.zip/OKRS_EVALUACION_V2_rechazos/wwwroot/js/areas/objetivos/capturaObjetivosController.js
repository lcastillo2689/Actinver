﻿const CapturaObjetivosController = (function () {

    let _empleadoIDConsultado = null;
    const validationForms = [];

    let _linkedObjetivoSelected = '';

    let _objetivoService = null;
    let _resultadoClaveService = null;

    let _objetivoId = 0;



    const InitController = function (objetivoService, resultadoClaveService, empleadoID) {
        if (objetivoService == null || resultadoClaveService == null) {
            console.log("El servicio pasado al iniciar el controlador CapturaObjetivosController es null");
            return;
        }

        _objetivoService = objetivoService;
        _resultadoClaveService = resultadoClaveService;
        _empleadoIDConsultado = empleadoID;

        InitializeDatePicker();

        $(ElementosComunesOKR.ResultadoClaveElements.btnCloseModal).on('click', function (e) {
            e.preventDefault();
            let objetivoId = $(ElementosComunesOKR.ResultadoClaveElements.txtHiddenObjetivo).val();
            refreshResultadosClave(objetivoId);
        });

        $(ElementosComunesOKR.PeriodoEvaluacionElements.btnAproveAll).on('click', function (e) {
            e.preventDefault();
            confirmationMessage("¡Se aprobaran todos los objetivos y resultados clave! <br /><br />¿Deseas continuar?", () => {
                AproveAll();
            });
        });

        $(ElementosComunesOKR.PeriodoEvaluacionElements.btnConfirmRejectAll).on('click', function (e) {
            e.preventDefault();
            RejectAll();
            $(ElementosComunesOKR.PeriodoEvaluacionElements.btnCloseModalRejectAll).trigger('click');
        });
    };

    function InitControlKR(krSource) {

        jQuery.each(krSource, function () {
            let controlName = ElementosComunesOKR.ResultadoClaveElements.cardPartialControlName + this;
            let controlDeleteName = ElementosComunesOKR.ResultadoClaveElements.cardPartialBtnDeleteName + this;
            let controlTooltip = ElementosComunesOKR.ResultadoClaveElements.cardPartialBtnDetailDescriptionName + this;

            $(controlName).on('click', function (e) {
                e.preventDefault();
                let resultadoClaveId = $(this).attr(ElementosComunesOKR.ResultadoClaveElements.cardDataKRID);
                editResultadoClave(resultadoClaveId);
            });

            $(controlDeleteName).on('click', function (e) {
                e.preventDefault();
                let resultadoClaveId = $(this).attr(ElementosComunesOKR.ResultadoClaveElements.cardDataKRID);
                let objeivoId = $(this).attr(ElementosComunesOKR.ResultadoClaveElements.cardDataObjetivoID);

                confirmationMessage("¡El Resultado Clave será eliminado! <br /><br />¿Deseas continuar?", () => {
                    e.preventDefault();
                    deleteResultadoClave(e, resultadoClaveId, objeivoId);
                });
            });

            tippy(controlTooltip, { allowHTML: true, theme: "light", animation: "scale", placement: "top", inertia: true, maxWidth: 600 });
            tippy(controlDeleteName, { allowHTML: true, theme: "light", animation: "scale", placement: "right", inertia: true, maxWidth: 600 });
        });
    }

    function InitializeDatePicker(periodo) {

        let currentDate = new Date();
        const initDate = new Date(2022, 0, 1);
        const maxDate = new Date(2022, 11, 31);
        if (currentDate < initDate)
            currentDate = initDate;

        $(ElementosComunesOKR.PeriodoEvaluacionElements.yearPickerSelector).datepicker({
            format: "yyyy",
            viewMode: "years",
            minViewMode: "years",
            autoclose: true,
            startDate: initDate,
            minDate: initDate,
            endDate: maxDate,
            setDate: currentDate
        }).on('changeDate', function () {
            LoadYear();
        });


        if (periodo !== undefined)
            $(ElementosComunesOKR.PeriodoEvaluacionElements.yearPickerSelector).datepicker("setDate", periodo);
        else
            $(ElementosComunesOKR.PeriodoEvaluacionElements.yearPickerSelector).datepicker("setDate", currentDate);
    }

    const LoadActiveQuarterOfYear = function () {
        LoadYear();
    };

    function LoadYear() {
        Loading.Show();
        const periodo = $(ElementosComunesOKR.PeriodoEvaluacionElements.yearPickerSelector).datepicker("getDate");

        const success = function (response) {
            $(ElementosComunesOKR.ObjetivoElements.objetivosContrainer).html(response);
            ShowLinkedOKRs();
            ShowApprovalInformation();
            Loading.Hide();
        };
        const error = function (response) {
            ajaxErrorMessage(response);
            Loading.Hide();
        };

        _objetivoService.LoadPeriod(formatQueryStringDateObject(periodo), _empleadoIDConsultado, success, error);
    }

    function ReloadYear() {
        Loading.Show();
        const periodo = $(ElementosComunesOKR.PeriodoEvaluacionElements.yearPickerSelector).datepicker("getDate");

        const success = function (response) {
            $(ElementosComunesOKR.ObjetivoElements.objetivosContrainer).html(response);
            ShowApprovalInformation();
            Loading.Hide();
        };
        const error = function (response) {
            ajaxErrorMessage(response);
            Loading.Hide();
        };

        _objetivoService.ReloadPeriod(formatQueryStringDateObject(periodo), _empleadoIDConsultado, success, error);
    }

    const InitYear = function (periodo, pesoTotal) {
        $(ElementosComunesOKR.ObjetivoElements.addObjetivoClass).on("click", function () {
            addObjetivo();
        });

        $(ElementosComunesOKR.ObjetivoElements.btnGuardar).on("click", function () {
            SaveChanges();
        });

        $(ElementosComunesOKR.ObjetivoElements.btnEnviarAprobacion).on("click", function () {
            ConfirmacionEnvio();
        });

        $(ElementosComunesOKR.ObjetivoElements.btnOKRNivelSuperior).on('click', function () {
            const periodo = $(ElementosComunesOKR.PeriodoEvaluacionElements.yearPickerSelector).datepicker("getDate");
            const periodoQueryString = formatQueryStringDateObject(periodo);
            _objetivoService.BossObjectives(periodoQueryString);
        });

        tippy(ElementosComunesOKR.ObjetivoElements.btnOKRNivelSuperior, { theme: "light", animation: "scale", placement: "bottom", inertia: true });
        updatePesoTotalObejtivos();
    };

    let InitObjetivoAcordeon = function (objetivos) {

        $.each(objetivos, function () {
            $(".accordionObjetivo-" + this.ObjetivoID).on('click', function (e) {
                e.preventDefault();
                let objetivoId = $(this).attr("data-objetivo");
                let objetiveActive = $(".card-" + objetivoId).attr("aria-expanded");
                if (objetiveActive === "false") {
                    $("#title-objetivo-" + objetivoId).hide();

                    $.each(objetivos, function () {
                        if (this.ObjetivoID != objetivoId) {
                            $("#title-objetivo-" + this.ObjetivoID).show();
                        }
                    });
                } else {
                    $("#title-objetivo-" + objetivoId).show();
                }
            });
        });
    }

    function addObjetivo() {
        Loading.Show();

        $('.card-title[aria-expanded="true"]').trigger("click");

        const success = function (response) {
            $(ElementosComunesOKR.ObjetivoElements.acordionObjetivosID).append(response);
            NotificaDatosGuardados(true);
            Loading.Hide();
        };
        const error = function (response) {
            ajaxErrorMessage(response);
            Loading.Hide();
        };

        _objetivoService.AddObjetivo($(ElementosComunesOKR.PeriodoEvaluacionElements.periodoEvaluacionID).val(), success, error);
    }

    const InitObjetivo = function (model) {
        var objetivoFormIDSelector = `${ElementosComunesOKR.ObjetivoElements.objetivoFormIDPartial}${model.objetivoID}`;
        AddValidacionesObjetivo(objetivoFormIDSelector);

        $(`${objetivoFormIDSelector} ${ElementosComunesOKR.ObjetivoElements.addResultadoClaveClass}`).on("click", function () {
            const objetivoFormIDSelector = this.closest(ElementosComunesOKR.ObjetivoElements.objetivoFormClass).id;
            addResultadoClave(objetivoFormIDSelector);
        });

        const deleteObjetivoSelector = `${objetivoFormIDSelector} ${ElementosComunesOKR.ObjetivoElements.deleteObjetivoClass}`;
        $(deleteObjetivoSelector).on("click", function () {
            const objetivoElement = this;
            confirmationMessage("¡El Objetivo será eliminado! <br /><br />¿Deseas continuar?", () => {
                deleteObjetivo(objetivoElement);
            });
        });

        const objetivoDescriptionSelector = `${objetivoFormIDSelector} ${ElementosComunesOKR.ObjetivoElements.txtDescripcionObjetivoID}`;
        $(objetivoDescriptionSelector).change(function () {
            this.value = CleanSpacesOfString(this.value);
            SaveChanges();
        });

        const vinculaResultadoClaveSelector = `${objetivoFormIDSelector} ${ElementosComunesOKR.ObjetivoElements.resultadoClaveVinculadoClass}`;
        $(vinculaResultadoClaveSelector).on("click", function () {
            _linkedObjetivoSelected = $(this).closest(ElementosComunesOKR.ObjetivoElements.objetivoFormClass)[0].id;
            const objetivoID = $(`#${_linkedObjetivoSelected} ${ElementosComunesOKR.ObjetivoElements.hdnObjetivoID}`)[0].value;
            GetResultadoClaveVinculado(objetivoID);
            //GetBossResultadosClave();
        });

        const resultadoClaveVinculadoID = $(`${objetivoFormIDSelector} ${ElementosComunesOKR.ObjetivoElements.resultadoClaveVinculadoID}`)[0];
        if (resultadoClaveVinculadoID.value !== undefined && resultadoClaveVinculadoID.value > 0)
            $(`${objetivoFormIDSelector} ${ElementosComunesOKR.ObjetivoElements.resultadoClaveVinculadoClass}`).css({ "background-color": "#C9F7F5" });

        initDates(model);

        const valorMedicionSelector = `${objetivoFormIDSelector} ${ElementosComunesOKR.ObjetivoElements.valorMedicionObjetivo}`;
        $(valorMedicionSelector).change(function () {
            SaveChanges();
        });

        $(valorMedicionSelector).on("keyup", function (event) {
            FloatThousandSeparatorKeyUpEvent(this, event);
        });

        tippy(deleteObjetivoSelector, { theme: "light", animation: "scale", placement: "right", inertia: true });
        tippy(vinculaResultadoClaveSelector, { theme: "light", animation: "scale", placement: "left", inertia: true });

        const addMedicionObjetivoSelector = `${objetivoFormIDSelector} ${ElementosComunesOKR.ObjetivoElements.addObjetivoMedicionClass}`;
        tippy(addMedicionObjetivoSelector, { theme: "light", animation: "scale", placement: "right", inertia: true });

        $(addMedicionObjetivoSelector).on("click", function (e) {
            e.preventDefault();

            let objetivoMedicionSelected = $(this).closest(ElementosComunesOKR.ObjetivoElements.objetivoFormClass)[0].id;

            showObjetivoMedicionView(objetivoFormIDSelector, objetivoMedicionSelected, 0);
        });

        const objetivoPonderacionSelector = `${objetivoFormIDSelector} ${ElementosComunesOKR.ObjetivoElements.txtObjetivoPondracion}`;
        $(objetivoPonderacionSelector).change(function () {
            this.value = CleanSpacesOfString(this.value);
            SaveChanges();
        });

        const btnToggleMostrarKPIsSelector = `${ElementosComunesOKR.ObjetivoElements.btnToggleMostrarKPIsPartialID}${model.objetivoID}`;
        $(btnToggleMostrarKPIsSelector).on("click", function () {
            const objetivoID = $(this).attr('data-obtetivo-id');
            const containerKPIsSelector = `${ElementosComunesOKR.ObjetivoElements.containerKPIsPartialID}${objetivoID}`;
            const toggleState = $(containerKPIsSelector).attr('data-toggle-state');
            if (toggleState === 'hide') {
                $(containerKPIsSelector).slideDown(1000);
                $(containerKPIsSelector).attr('data-toggle-state', 'show');
                $(this).val("Ocultar KPI's del objetivo");
            }
            else {
                $(containerKPIsSelector).slideUp(1000);
                $(containerKPIsSelector).attr('data-toggle-state', 'hide');
                $(this).val("Mostrar KPI's del objetivo");
            }
        });
        tippy(ElementosComunesOKR.ObjetivoElements.btnObjetivoDetalle + model.objetivoID, { theme: "light", animation: "scale", placement: "right", inertia: true });
    };


    const InitObjetivoMediciones = function (model) {
        var objetivoFormIDSelector = `${ElementosComunesOKR.ObjetivoElements.objetivoFormIDPartial}${model.objetivoID}`;

        const deleteObjetivoMedicionSelector = `${objetivoFormIDSelector} ${ElementosComunesOKR.ObjetivoElements.btnDeleteObjetivoMedicion}`;
        const editObjetivoMedicionSelector = `${objetivoFormIDSelector} ${ElementosComunesOKR.ObjetivoElements.btnEditObjetivoMedicion}`;

        const lnkPorcentajeMedicion = `${objetivoFormIDSelector} ${ElementosComunesOKR.ObjetivoElements.lnkPorcentajeMediciones}`;


        tippy(lnkPorcentajeMedicion, { theme: "light", animation: "scale", placement: "bottom", inertia: true });
        tippy(deleteObjetivoMedicionSelector, { theme: "light", animation: "scale", placement: "bottom", inertia: true });
        tippy(editObjetivoMedicionSelector, { theme: "light", animation: "scale", placement: "bottom", inertia: true });
        tippy(lnkPorcentajeMedicion, { theme: "light", animation: "scale", placement: "bottom", inertia: true });

        $(deleteObjetivoMedicionSelector).on("click", function (e) {
            e.preventDefault();
            let atrrDataMedicion = $(this).attr("data-medicion");
            let atrrDataObjetivo = $(this).attr("data-objetivo");

            confirmationMessage("¡El Tipo de Medición será eliminada! <br /><br />¿Deseas continuar?", () => {
                e.preventDefault();
                deleteObjetivoMedicion(objetivoFormIDSelector, atrrDataMedicion, atrrDataObjetivo);
            });
        });

        $(editObjetivoMedicionSelector).on("click", function (e) {
            e.preventDefault();

            let atrrDataMedicion = $(this).attr("data-medicion");
            let objetivoMedicionSelected = $(this).closest(ElementosComunesOKR.ObjetivoElements.objetivoFormClass)[0].id;

            showObjetivoMedicionView(objetivoFormIDSelector, objetivoMedicionSelected, atrrDataMedicion);
        });
    }


    function initDates(model) {
        var objetivoFormIDSelector = `${ElementosComunesOKR.ObjetivoElements.objetivoFormIDPartial}${model.objetivoID}`;
        let startDate = new Date(2022, 0, 1);
        let endDate = new Date(2022, 11, 31);

        $(`${objetivoFormIDSelector} ${ElementosComunesOKR.ObjetivoElements.startDateObjetivo}`)
            .datepicker({
                autoclose: true,
                format: "dd/M/yyyy",
                orientation: "bottom right",
                language: "es",
                daysOfWeekDisabled: "0,6",
                startDate: startDate,
                endDate: endDate
            });

        if (!$.isEmptyObject(model.fechaEstimadaInicio))
            $(`${objetivoFormIDSelector} ${ElementosComunesOKR.ObjetivoElements.startDateObjetivo}`).datepicker("setDate", model.fechaEstimadaInicio);

        $(`${objetivoFormIDSelector} ${ElementosComunesOKR.ObjetivoElements.startDateObjetivo}`)
            .datepicker()
            .on("changeDate", function (e) {
                $(`${objetivoFormIDSelector} ${ElementosComunesOKR.ObjetivoElements.endDateObjetivo}`).datepicker("setStartDate", $(this).datepicker("getDate"));
                SaveChanges();
            });

        $(`${objetivoFormIDSelector} ${ElementosComunesOKR.ObjetivoElements.endDateObjetivo}`)
            .datepicker({
                autoclose: true,
                format: "dd/M/yyyy",
                orientation: "bottom right",
                language: "es",
                daysOfWeekDisabled: "0,6",
                startDate: startDate,
                endDate: endDate
            });

        if (!$.isEmptyObject(model.fechaEstimadaFin))
            $(`${objetivoFormIDSelector} ${ElementosComunesOKR.ObjetivoElements.endDateObjetivo}`).datepicker("setDate", model.fechaEstimadaFin);

        $(`${objetivoFormIDSelector} ${ElementosComunesOKR.ObjetivoElements.endDateObjetivo}`)
            .datepicker()
            .on("changeDate", function (e) {
                SaveChanges();
            });
    }

    const InitVinculacionResultadoClave = function () {
        $(ElementosComunesOKR.ObjetivoElements.btnMustraResultadosClaveJefeID).on("click", function () {
            GetBossResultadosClave();
        });

        $(ElementosComunesOKR.ObjetivoElements.btnMustraResultadosClaveFiltradosID).on("click", function () {
            GetEmpleadoResultadosClave();
        });

        $(ElementosComunesOKR.ObjetivoElements.btnDesvinculaResultadoClave).on("click", function () {
            const resultadoClaveVinculadoID = $(`#${_linkedObjetivoSelected} ${ElementosComunesOKR.ObjetivoElements.resultadoClaveVinculadoID}`)[0];
            resultadoClaveVinculadoID.value = '';

            $(`#${_linkedObjetivoSelected} ${ElementosComunesOKR.ObjetivoElements.resultadoClaveVinculadoClass}`).css({ "color": "" });

            $(ElementosComunesOKR.ObjetivoElements.btnModalResultadoClaveSuperiorCloseID).trigger("click");
            SaveChanges();
        });

        $(ElementosComunesOKR.ObjetivoElements.btnMustraResultadosClaveJefeID).trigger("click");
    };

    const OnDimensionChange = function () {
        SaveChanges();
    };

    const OnTipoMedicionChange = function () {
        SaveChanges();
    };

    const OnAreaObjetivoChange = function () {
        SaveChanges();
    };

    function AddValidacionesObjetivo(formSelector) {
        const formID = formSelector.substring(1, formSelector.length);
        const fvo = FormValidation.formValidation(
            document.getElementById(formID),
            {
                fields: {
                    "DescripcionObjetivo": {
                        validators: {
                            notEmpty: {
                                message: 'Por favor ingresa la descripción del Objetivo'
                            }
                        }
                    },
                    "txt-PonderacionObjetivo": {
                        validators: {
                            integer: {
                                decimalSeparator: '',
                                decimalSeparator: '.',
                                message: 'Por favor ingresa una Ponderación (peso) a tu objetivo válida.'
                            },
                            lessThan: {
                                max: 100,
                                message: 'El valor de la Ponderación (peso) no puede ser mayor a 100%'
                            }
                        }
                    },
                },

                plugins: {
                    trigger: new FormValidation.plugins.Trigger(),
                    bootstrap: new FormValidation.plugins.Bootstrap(),
                    submitButton: new FormValidation.plugins.SubmitButton(),
                    defaultSubmit: new FormValidation.plugins.DefaultSubmit(),
                }
            }
        );
        validationForms[validationForms.length] = fvo;
    }

    function deleteObjetivo(source) {
        Loading.Show();
        const objetivoContainerIDSelector = source.closest(ElementosComunesOKR.ObjetivoElements.objetivoContainerClass);
        const objetivoFormIDSelector = source.closest(ElementosComunesOKR.ObjetivoElements.objetivoFormClass).id;
        const objetivoID = $(`#${objetivoFormIDSelector} ${ElementosComunesOKR.ObjetivoElements.hdnObjetivoID}`)[0].value;

        const success = function (response) {
            NotificaDatosGuardados(response);
            if (response === true) {
                objetivoContainerIDSelector.remove();
            }
            else {
                Swal.fire(
                    'Ocurrio un error',
                    'No se pudo eliminar el Objetivo, intente mas tarde.',
                    'error'
                );
            }
            Loading.Hide();
            ReloadYear();
        };
        const error = function (response) {
            ajaxErrorMessage(response);
            Loading.Hide();
        };

        _objetivoService.RemoveObjetivo(objetivoID, success, error);
    }

    function GetResultadoClaveVinculado(objetivoID) {
        $(ElementosComunesOKR.ObjetivoElements.modalResultadoClaveSuperiorBodyID).html('<i class="fa fa-spinner" aria-hidden="true"></i>');

        const success = function (response) {
            $(ElementosComunesOKR.ObjetivoElements.modalResultadoClaveSuperiorBodyID).html(response);
        };
        const error = function (response) {
            ajaxErrorMessage(response);
        };

        _objetivoService.GetResultadosClaveVinculados(objetivoID, _empleadoIDConsultado, success, error);
    }

    function GetBossResultadosClave() {

        const periodo = $(ElementosComunesOKR.PeriodoEvaluacionElements.yearPickerSelector).datepicker("getDate");

        const success = function (response) {
            $(ElementosComunesOKR.ObjetivoElements.containerResultadosClaveVinculacionListID).html(response);
        };
        const error = function (response) {
            ajaxErrorMessage(response);
        };

        _objetivoService.GetBossResultadosClave(formatQueryStringDateObject(periodo), _empleadoIDConsultado, success, error);
    }

    function GetEmpleadoResultadosClave() {
        const periodo = $(ElementosComunesOKR.PeriodoEvaluacionElements.yearPickerSelector).datepicker("getDate");
        const empleadoID = $(ElementosComunesOKR.ObjetivoElements.ddlEmpleadosRCFilter).val();

        const success = function (response) {
            $(ElementosComunesOKR.ObjetivoElements.containerResultadosClaveVinculacionListID).html(response);
        };
        const error = function (response) {
            ajaxErrorMessage(response);
        };

        _objetivoService.GetResultadosClaveEmpleado(formatQueryStringDateObject(periodo), empleadoID, success, error);
    }

    function addResultadoClave(objetivoFormIDSelector) {
        //Loading.Show();
        const objetivoID = $(`#${objetivoFormIDSelector} ${ElementosComunesOKR.ObjetivoElements.hdnObjetivoID}`)[0].value;

        let success = function (response) {
            $(ElementosComunesOKR.ResultadoClaveElements.modalTitle).text('Resultado Clave');
            $(ElementosComunesOKR.ResultadoClaveElements.modalBody).html(response);
        };

        let error = function (response) {
            ajaxErrorMessage(response);
        };

        let objetivoParam = {
            objetivoId: objetivoID
        };

        _resultadoClaveService.GetKRView(objetivoParam, success, error)

    }

    const OnPrioridadChange = function () {
        SaveChanges();
    };

    function ConfirmacionEnvio() {
        Swal.fire({
            title: 'Envíar a Aprobación',
            html: "Se enviará una notificación a tu líder directo para que valide y apruebe tus OKR's, <br/> ¿Deseas continuar?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#FFA800',
            cancelButtonColor: '#8950FC',
            confirmButtonText: 'Envíar',
            cancelButtonText: "Cancelar",
        }).then((result) => {
            if (result.value === true) {
                SendToApproval();
            }
        });
    }

    function SaveChanges() {
        const model = GetModel();

        const success = function (response) {
            NotificaDatosGuardados(response);
            updatePesoTotalObejtivos();
        };
        const error = function (response) {
            ajaxErrorMessage(response);
        };

        _objetivoService.SaveChanges(model, success, error);
    }

    function SendToApproval() {
        Loading.Show();
        const model = GetModel();

        const success = function (response) {
            NotifySendToApproval(response);
            Loading.Hide();
        };
        const error = function (response) {
            ajaxErrorMessage(response);
            Loading.Hide();
        };

        _objetivoService.SendToApproval(model, success, error);
    }

    function GetModel() {
        const periodo = $(ElementosComunesOKR.PeriodoEvaluacionElements.yearPickerSelector).datepicker("getDate");

        const objetivos = [];
        const objetivosDOM = $(ElementosComunesOKR.ObjetivoElements.objetivoFormClass);
        jQuery.each(objetivosDOM, function (i, objetivo) {
            objetivos[i] = GetObjetivoModel(objetivo);
        });

        return {
            PeriodoEvaluacionID: $(ElementosComunesOKR.PeriodoEvaluacionElements.periodoEvaluacionID).val(),
            EmpleadoID: _empleadoIDConsultado,
            Periodo: periodo.toISOString(),
            Objetivos: objetivos
        };
    }

    function GetObjetivoModel(objetivoDOM) {
        const ObjetivoID = $(objetivoDOM).find(ElementosComunesOKR.ObjetivoElements.hdnObjetivoID)[0].value;
        const DescripcionObjetivo = $(objetivoDOM).find(ElementosComunesOKR.ObjetivoElements.txtDescripcionObjetivoID)[0].value;
        const ResultadoClaveVinculadoID = $(objetivoDOM).find(ElementosComunesOKR.ObjetivoElements.resultadoClaveVinculadoID)[0].value;
        const selectDimensiones = $(`${ElementosComunesOKR.ObjetivoElements.comboDimensionObjetivoIDPartial}${ObjetivoID}`).data("kendoDropDownList");
        const fechaEstimadaInicio = $($(objetivoDOM).find(ElementosComunesOKR.ObjetivoElements.startDateObjetivo)[0]).datepicker("getDate");
        const fechaEstimadaFin = $($(objetivoDOM).find(ElementosComunesOKR.ObjetivoElements.endDateObjetivo)[0]).datepicker("getDate");
        const selectAreaObjetivo = $(`#${ElementosComunesOKR.ObjetivoElements.areaObjetivoIDPartial}${ObjetivoID}`).data("kendoDropDownList");

        const dimensonID = selectDimensiones != undefined ? selectDimensiones.value() : null;
        const areaID = selectAreaObjetivo != undefined ? selectAreaObjetivo.value() : null;
        const ponderacionObjetivo = $(objetivoDOM).find(ElementosComunesOKR.ObjetivoElements.txtObjetivoPondracion)[0].value;

        return {
            ObjetivoID: ObjetivoID,
            DescripcionObjetivo: DescripcionObjetivo,
            ResultadoClaveVinculadoID: ResultadoClaveVinculadoID,
            DimensionID: dimensonID,
            FechaEstimadaInicio: fechaEstimadaInicio != null ? fechaEstimadaInicio.toISOString() : null,
            FechaEstimadaFin: fechaEstimadaFin != null ? fechaEstimadaFin.toISOString() : null,
            AreaID: areaID,
            Ponderacion: ponderacionObjetivo
        };
    }



    function NotificaDatosGuardados(exito) {
        if (exito) {
            toastr.options = {
                "closeButton": true,
                "debug": false,
                "newestOnTop": false,
                "progressBar": false,
                "positionClass": "toast-top-right",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "500",
                "hideDuration": "500",
                "timeOut": "2000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "slideDown",
                "hideMethod": "slideUp"
            };
            toastr.info("Datos autoguardados.");
        }
        else {
            toastr.options = {
                "closeButton": true,
                "debug": false,
                "newestOnTop": false,
                "progressBar": false,
                "positionClass": "toast-top-right",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "500",
                "hideDuration": "500",
                "timeOut": "4000",
                "extendedTimeOut": "2000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "slideDown",
                "hideMethod": "slideUp"
            };
            toastr.warning("Si el problema persiste, refresca la pantalla.", "Error al guardados datos");
        }
    }

    function NotifySendToApproval(result) {
        if (result.Exito === true) {
            Swal.fire({
                title: 'Envíado a aprobación',
                html: "Tu lider directo validara tus objetivos.",
                icon: 'success',
                showCancelButton: false,
                confirmButtonText: 'Ok'
            }).then((result) => {
                window.location.replace(window.location.origin);
            });
        }
        else {
            NotifyError(result, 'Ocurrío un problema al envíar tus objetivos.');
        }
    }

    function NotifyError(result, title) {
        for (var x = 0; x < validationForms.length; x++) {
            validationForms[x].validate();
        }
        let errorList = "<ul style='text-align: left;'>";
        for (var i = 0; i < result.Errores.length; i++) {
            errorList += `<li>${result.Errores[i]}</li>`
        }
        errorList += "</ul>";

        if (!title)
            title = "Ocurrío un problema"

        Swal.fire({
            title: title,
            html: errorList,
            width: 600,
            icon: 'warning',
            showCancelButton: false,
            confirmButtonText: 'Ok'
        });
    }



    function CleanSpacesOfString(texto) {
        let cleanText = texto.trimStart();
        cleanText = texto.trimEnd();
        while (cleanText.match(/ {2}/)) {
            cleanText = cleanText.replace(/ {2}/g, " ");
        }
        while (cleanText.match(/\n\n/)) {
            cleanText = cleanText.replace(/\n\n/g, "\n");
        }
        while (cleanText.match(/\t\t/)) {
            cleanText = cleanText.replace(/\t\t/g, "\t");
        }
        return cleanText;
    }

    function GetResultadoClaveParentSelected() {
        let radios = $(ElementosComunesOKR.ObjetivoElements.chkResultadoClaveSuperiorSelector);
        for (var i = 0; i < radios.length; i++) {
            if (radios[i].checked) {
                let radioID = $(`#${radios[i].id}`).data(ElementosComunesOKR.ObjetivoElements.chkResultadoClaveSuperiorIDData);
                return radioID;
            }
        }
    }

    const InitResultadosClaveSupervisor = function () {
        $(ElementosComunesOKR.ObjetivoElements.btnResultadosClaveSuperiorSelector).on("click", function () {
            const resultadoClaveVinculadoID = $(`#${_linkedObjetivoSelected} ${ElementosComunesOKR.ObjetivoElements.resultadoClaveVinculadoID}`)[0];
            const resultadoClaveParentSelected = GetResultadoClaveParentSelected();
            resultadoClaveVinculadoID.value = resultadoClaveParentSelected;

            if (resultadoClaveParentSelected !== undefined && resultadoClaveParentSelected > 0)
                $(`#${_linkedObjetivoSelected} ${ElementosComunesOKR.ObjetivoElements.resultadoClaveVinculadoClass}`).css({ "color": "#1BC5BD" });
            else
                $(`#${_linkedObjetivoSelected} ${ElementosComunesOKR.ObjetivoElements.resultadoClaveVinculadoClass}`).css({ "color": "" });

            $(ElementosComunesOKR.ObjetivoElements.btnModalResultadoClaveSuperiorCloseID).trigger("click");
            SaveChanges();
        });


        const resultadoClaveVinculadoID = $(`#${_linkedObjetivoSelected} ${ElementosComunesOKR.ObjetivoElements.resultadoClaveVinculadoID}`)[0];
        let radios = $(ElementosComunesOKR.ObjetivoElements.chkResultadoClaveSuperiorSelector);
        for (var i = 0; i < radios.length; i++) {
            let radioID = $(`#${radios[i].id}`).data(ElementosComunesOKR.ObjetivoElements.chkResultadoClaveSuperiorIDData);
            if (radioID == resultadoClaveVinculadoID.value) {
                radios[i].checked = true;
            }
        }
    };

    const InitTarjetasKR = function (okrSource) {
        InitControlKR(okrSource);
    }


    function refreshResultadosClave(objetivoId) {
        Loading.Show();
        let objetivoID = objetivoId;

        let success = function (response) {

            let containerName = ElementosComunesOKR.ObjetivoElements.containerResultadosClavePartialClass + objetivoID;

            $(containerName).html('');
            $(containerName).html(response);

            Loading.Hide();
        };

        let error = function (response) {
            ajaxErrorMessage(response);
            Loading.Hide();
        };

        let objetivoParam = {
            objetivoId: objetivoID
        };

        _resultadoClaveService.RefreshOKRView(objetivoParam, success, error)
    }


    function editResultadoClave(resultadoClaveId) {
        let krId = resultadoClaveId;

        let success = function (response) {
            $(ElementosComunesOKR.ResultadoClaveElements.modalTitle).text('Resultado Clave');
            $(ElementosComunesOKR.ResultadoClaveElements.modalBody).html(response);
        };

        let error = function (response) {
            ajaxErrorMessage(response);
        };

        let krParam = {
            resultadoClaveId: krId
        };

        _resultadoClaveService.GetKRUpdateView(krParam, success, error)
    }

    function deleteResultadoClave(e, resultadoClaveId, objetivoId) {
        Loading.Show();
        e.preventDefault();
        let krId = resultadoClaveId;

        let success = function (response) {
            if (response.success) {
                refreshResultadosClave(objetivoId);
                toastr.options = {
                    "closeButton": true,
                    "debug": false,
                    "newestOnTop": false,
                    "progressBar": false,
                    "positionClass": "toast-top-right",
                    "preventDuplicates": false,
                    "onclick": null,
                    "showDuration": "500",
                    "hideDuration": "500",
                    "timeOut": "2000",
                    "extendedTimeOut": "1000",
                    "showEasing": "swing",
                    "hideEasing": "linear",
                    "showMethod": "slideDown",
                    "hideMethod": "slideUp"
                };
                toastr.info("Registro eliminado.");
            }

            Loading.Hide();
        };

        let error = function (response) {
            Loading.Hide();
            ajaxErrorMessage(response);
        };

        let krParam = {
            resultadoClaveId: krId
        };

        _resultadoClaveService.DeleteKR(krParam, success, error)
    }

    function AproveAll() {
        Loading.Show();

        const model = GetModel();

        const success = function (response) {
            NotifyApproval(response);

            Loading.Hide();
        };
        const error = function (response) {
            ajaxErrorMessage(response);
            Loading.Hide();
        };

        _objetivoService.ApproveAll(model, success, error);
    }

    function NotifyApproval(result) {
        if (result.Exito === true) {
            modalMessage("success", "Aprobación exitosa");
        }
        else {
            NotifyError(result, 'Ocurrío un problema al aprobar los objetivos.');
        }
    }

    function RejectAll() {
        Loading.Show();

        const periodo = $(ElementosComunesOKR.PeriodoEvaluacionElements.yearPickerSelector).datepicker("getDate");

        const model = {
            PeriodoEvaluacionID: $(ElementosComunesOKR.PeriodoEvaluacionElements.periodoEvaluacionID).val(),
            EmpleadoID: _empleadoIDConsultado,
            Periodo: periodo.toISOString(),
            MotivoRechazo: $(ElementosComunesOKR.PeriodoEvaluacionElements.txtMotivoRechazo).val()
        };

        const success = function (response) {
            modalMessage("success", "Se han enviado los comentarios.");
            Loading.Hide();
        };
        const error = function (response) {
            ajaxErrorMessage(response);
            Loading.Hide();
        };

        _objetivoService.RejectAll(model, success, error);
    }

    function ShowLinkedOKRs() {
        Loading.Show();
        const periodo = $(ElementosComunesOKR.PeriodoEvaluacionElements.yearPickerSelector).datepicker("getDate");

        const success = function (response) {
            $(ElementosComunesOKR.ObjetivoElements.containerObjetivosVinculadosID).html(response);
            Loading.Hide();
        };
        const error = function (response) {
            ajaxErrorMessage(response);
            Loading.Hide();
        };

        _objetivoService.LoadLinkedOKRs(formatQueryStringDateObject(periodo), _empleadoIDConsultado, success, error);
    }

    function ShowApprovalInformation() {
        Loading.Show();
        const periodoID = $(ElementosComunesOKR.PeriodoEvaluacionElements.periodoEvaluacionID).val();

        const success = function (response) {
            $(ElementosComunesOKR.PeriodoEvaluacionElements.conatinerApprovalInfo).html(response);
            Loading.Hide();
        };
        const error = function (response) {
            ajaxErrorMessage(response);
            Loading.Hide();
        };

        _objetivoService.GetApprovalInformation(periodoID, success, error);
    }

    const OnDireccionEjecutivaRCFilterChange = function () {
        ReloadAreaRCFilter();
        ReloadDDLEmpleadoRCFilter();
    }

    const OnAreaRCFilterChange = function () {
        ReloadDDLEmpleadoRCFilter();
    };

    function ReloadAreaRCFilter() {
        var dropdown = $(ElementosComunesOKR.ObjetivoElements.ddlAreasRCFilter).data("kendoDropDownList");
        dropdown.dataSource.read();
        dropdown.refresh();
    }

    function ReloadDDLEmpleadoRCFilter() {
        var comboBox = $(ElementosComunesOKR.ObjetivoElements.ddlEmpleadosRCFilter).data("kendoComboBox");
        comboBox.dataSource.read();
        comboBox.refresh();
    }


    const GetSelectedDireccionEjecutivaForRCFilter = function () {
        return {
            direccionEjecutivaID: $(ElementosComunesOKR.ObjetivoElements.ddlDireccionEjecutivaRCFilter).data("kendoDropDownList").value()
        };
    };

    const GetSelectedDireccionEjecutivaAndAreaForRCFilter = function () {
        let searchValue = "";
        let filtroCombo = $(ElementosComunesOKR.ObjetivoElements.ddlEmpleadosRCFilter).data("kendoComboBox").dataSource.filter();
        if (filtroCombo != null && filtroCombo.filters != null && filtroCombo.filters.length > 0)
            searchValue = filtroCombo.filters[0].value;

        return {
            direccionEjecutivaID: $(ElementosComunesOKR.ObjetivoElements.ddlDireccionEjecutivaRCFilter).data("kendoDropDownList").value(),
            areaID: $(ElementosComunesOKR.ObjetivoElements.ddlAreasRCFilter).data("kendoDropDownList").value(),
            text: searchValue
        };
    };


    const InitMedicionObjetivo = function (model) {
        var objetivoFormIDSelector = `${ElementosComunesOKR.ObjetivoElements.objetivoFormIDPartial}${model.objetivoID}`;

        const saveObjetivoMedicionSelector = `${ElementosComunesOKR.ObjetivoElements.btnGuardarMedicionObjetivo}${model.objetivoID}`;

        $(saveObjetivoMedicionSelector).on("click", function (e) {
            e.preventDefault();
            validateMedicionExiste(objetivoFormIDSelector);
        });
        debugger;
        const chkBenchmarkobjetivoSelector = `${ElementosComunesOKR.ObjetivoElements.chkBenchmarkFormula}`;

        const containerBenchmarkobjetivoSelector = `${ElementosComunesOKR.ObjetivoElements.containerBenchmarkFormula}`;

        $(chkBenchmarkobjetivoSelector).change(function () {
            if (this.checked)
                $(containerBenchmarkobjetivoSelector).show();
            else
                $(containerBenchmarkobjetivoSelector).hide();
        });
    }

    function saveObjetivoMedicion(objetivoFormIDSelector) {
        Loading.Show();
        let model = getObjetivoMedicionModel();

        const containerObjetivoMedicionSelector = `${objetivoFormIDSelector} ${ElementosComunesOKR.ObjetivoElements.containerObjetivoMediciones}`;
        const modalObjetivoMedicionSelector = `${ElementosComunesOKR.ObjetivoElements.modalObjetivoMediciones}`;

        let success = function (response) {
            $(containerObjetivoMedicionSelector + model.ObjetivoId).html('');
            $(ElementosComunesOKR.ObjetivoElements.modalBodyObjetivoMedicion).html('');

            $(containerObjetivoMedicionSelector + model.ObjetivoId).html(response);

            $(modalObjetivoMedicionSelector).modal('hide');

            NotificaDatosGuardados(true);

            Loading.Hide();
        }

        let error = function (response) {
            Loading.Hide();
            ajaxErrorMessage(response);
        }

        _objetivoService.SaveObjetivoMedicion(model, success, error);
    }

    function getObjetivoMedicionModel(objetivoDOM) {
        let objetivoId = $(ElementosComunesOKR.ObjetivoElements.txtObjetivoMedicionHidden).val();
        let objetivoMedicion = $(ElementosComunesOKR.ObjetivoElements.txtObjetivoMedicionIDHidden);
        let tipoMedicionDDL = $(ElementosComunesOKR.ObjetivoElements.tipoMedicionObjetivo + objetivoId).data("kendoDropDownList");

        let objetivoMedicionID = objetivoMedicion != undefined ? objetivoMedicion.val() : 0;
        let tipoMedicionID = tipoMedicionDDL != undefined ? tipoMedicionDDL.value() : null;

        let valorMedicion = $(ElementosComunesOKR.ObjetivoElements.valorMedicionObjetivo).val();
        let ponderacionMedicion = $(ElementosComunesOKR.ObjetivoElements.txtMedicionPonderacion).val();

        //let tipoMedicionMedible = $(ElementosComunesOKR.ObjetivoElements.chkTipoMedicionMedible).is(':checked');

        let benchMark = $(ElementosComunesOKR.ObjetivoElements.txtBenchmarkMedicion).val();
        let formula = $(ElementosComunesOKR.ObjetivoElements.txtFormulaMedicion).val();

        return {
            ID: objetivoMedicionID,
            ObjetivoId: objetivoId,
            TipoMedicionId: tipoMedicionID,
            ValorMaximoMedicion: valorMedicion,
            PonderacionMedicion: ponderacionMedicion,
            //MedicionBinaria: tipoMedicionMedible,
            Benchmark: benchMark,
            Formula: formula
        }
    }

    function showObjetivoMedicionView(objetivoFormIDSelector, objetivoMedicionSelected, objetivoMedicionId) {
        Loading.Show();
        let objetivoId = $(`#${objetivoMedicionSelected} ${ElementosComunesOKR.ObjetivoElements.hdnObjetivoID}`)[0].value;

        let success = function (response) {
            $(ElementosComunesOKR.ObjetivoElements.modalBodyObjetivoMedicion).html('');
            $(ElementosComunesOKR.ObjetivoElements.modalBodyObjetivoMedicion).html(response);
            Loading.Hide();
        }

        let error = function (response) {
            Loading.Hide();
            ajaxErrorMessage(response);
        }

        _objetivoService.GetObjetivoMedicionView(objetivoMedicionId, objetivoId, success, error);
    }

    function validateMedicionExiste(objetivoFormIDSelector, objetivoMedicionSelected, objetivoMedicionId) {
        let model = getObjetivoMedicionModel();

        let success = function (response) {
            if (response.medicionExist)
                modalMessage("warning", "Atención", "El tipo de medición ya existe, intenta seleccionado una nueva.");
            else
                saveObjetivoMedicion(objetivoFormIDSelector)

        }

        let error = function (response) {
            ajaxErrorMessage(response);
        }

        _objetivoService.ValidateMedicionExistente(model, success, error);
    }

    function deleteObjetivoMedicion(objetivoFormIDSelector, objetivoMedicionId, objetivoId) {
        Loading.Show();

        let model = {
            objetivoMedicionId: objetivoMedicionId,
            objetivoId: objetivoId
        }

        const containerObjetivoMedicionSelector = `${objetivoFormIDSelector} ${ElementosComunesOKR.ObjetivoElements.containerObjetivoMediciones}`;
        const modalObjetivoMedicionSelector = `${ElementosComunesOKR.ObjetivoElements.modalObjetivoMediciones}`;

        let success = function (response) {
            $(containerObjetivoMedicionSelector + model.objetivoId).html('');
            $(containerObjetivoMedicionSelector + model.objetivoId).html(response);

            $(modalObjetivoMedicionSelector).modal('hide');

            NotificaDatosGuardados(true);
            Loading.Hide();
        }

        let error = function (response) {
            Loading.Hide();
            ajaxErrorMessage(response);
        }

        _objetivoService.DeleteObjetivoMedicion(model, success, error);
    }

    function updatePesoTotalObejtivos() {
        const periodoOKR = $(ElementosComunesOKR.PeriodoEvaluacionElements.yearPickerSelector).datepicker("getDate");

        let success = function (response) {
            $("div.sub-HeaderContainer").html("")
            $("div.sub-HeaderContainer").html(response);
        }

        let error = function (response) {
            ajaxErrorMessage(response);
        }

        _objetivoService.UpdatePesoTotalObejtivos(formatQueryStringDateObject(periodoOKR), _empleadoIDConsultado, success, error);
    }

    function validarObjetivosAprobados(periodoOKR) {

        let success = function (response) {

            if (response.success)
                window.location.href = response.redirectTo;
            else
                modalMessage("warning", "¡Oops!", "No puedes inciar tu <strong>Atuevaluación<strong> si tus objetivos <ul><li><span class='text-danger'><strong>No cuentan con una Ponderación (peso) definida.</strong></span></li></ul> ");
        }

        let error = function (response) {
            ajaxErrorMessage(response);
        }

        _objetivoService.ValidarObjetivosAprobados(formatQueryStringDateObject(periodoOKR), success, error);
    }

    const GetEmpleadoConsultado = function () {
        return _empleadoIDConsultado
    };

    return {
        InitController,
        InitYear,
        InitObjetivo,
        InitVinculacionResultadoClave,
        InitResultadosClaveSupervisor,
        OnDimensionChange,
        OnPrioridadChange,
        OnTipoMedicionChange,
        OnAreaObjetivoChange,
        InitTarjetasKR,
        OnDireccionEjecutivaRCFilterChange,
        OnAreaRCFilterChange,
        GetSelectedDireccionEjecutivaForRCFilter,
        GetSelectedDireccionEjecutivaAndAreaForRCFilter,
        InitMedicionObjetivo,
        InitObjetivoMediciones,
        GetEmpleadoConsultado,
        LoadActiveQuarterOfYear,
        InitObjetivoAcordeon
    };
})();