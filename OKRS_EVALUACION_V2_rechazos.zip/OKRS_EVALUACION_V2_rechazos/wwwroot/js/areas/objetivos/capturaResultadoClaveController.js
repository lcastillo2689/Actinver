﻿const CapturaResultadoClaveController = (function () {   

    let modelView = {
        fechaEjecucionInicio: '',
        fechaEjecucionFin: ''
    };

    let _participanteModificadoID = 0;
    let _isProgramatricFiltering = false;

    let _resultadoClaveService = null;

    const init = function (model, resultadoClaveService) {
        if (resultadoClaveService == null) {
            console.log("El servicio pasado al iniciar el controlador CapturaResultadoClaveController es null");
            return;
        }

        _resultadoClaveService = resultadoClaveService;

        modelView.fechaEjecucionInicio = model.fechaEjecucionInicio;
        modelView.fechaEjecucionFin = model.fechaEjecucionFin;

        initEventListeners();

    }


    function initDatePickerValues() {
        if (!$.isEmptyObject(modelView.fechaEjecucionInicio))
            $(ElementosComunesOKR.ResultadoClaveElements.datePickerStart).datepicker("setDate", modelView.fechaEjecucionInicio);


        if (!$.isEmptyObject(modelView.fechaEjecucionFin))
            $(ElementosComunesOKR.ResultadoClaveElements.datePickerEnd).datepicker("setDate", modelView.fechaEjecucionFin);
    }
    function formatQueryStringDateObject(date) {
        if (date == null)
            return null;
        return date.getMonth() + 1 + "-" + date.getDate() + "-" + date.getFullYear();
    }

    function modelParam() {
        let fechaInicio = $(ElementosComunesOKR.ResultadoClaveElements.datePickerStart).datepicker("getDate");
        let fechaFin = $(ElementosComunesOKR.ResultadoClaveElements.datePickerEnd).datepicker("getDate");
        let frecuencia = $(ElementosComunesOKR.ResultadoClaveElements.ddlFrecuencia).data("kendoDropDownList").value();
        let resultadoClaveMedicion = getMedicionModel();

        return {
            ObjetivoId: $(ElementosComunesOKR.ResultadoClaveElements.txtHiddenObjetivo).val(),
            ResultadoClaveID: $(ElementosComunesOKR.ResultadoClaveElements.txtHiddenResultadoClave).val(),
            Descripcion: $(ElementosComunesOKR.ResultadoClaveElements.txtDescripcionKR).val(),
            FechaEjecucionInicio: formatQueryStringDateObject(fechaInicio),
            FechaEjecucionFin: formatQueryStringDateObject(fechaFin),
            FrecuenciaId: frecuencia,
            Medicion: resultadoClaveMedicion
        }
    }

    function getMedicionModel() {
        let esMedible = $(ElementosComunesOKR.MedicionElements.chkMedibleNoMedible).prop('checked');
        let tipoMedicion = null;
        let valorMedicion = null;
        let medicionTareas = [];
        const resultadoClaveMedicionID = $(ElementosComunesOKR.MedicionElements.resultadoClaveMedicionID).val();

        if (esMedible) {
            tipoMedicion = $(ElementosComunesOKR.MedicionElements.ddlTipoMedicion + resultadoClaveMedicionID).data("kendoDropDownList").value();
            valorMedicion = $(ElementosComunesOKR.MedicionElements.txtValorMedicion).val();
        }
        else {
            let tareasNoMediblesDOM = $(ElementosComunesOKR.MedicionElements.tareaNoMedibleClass);
            jQuery.each(tareasNoMediblesDOM, function (i, tarea) {
                medicionTareas[i] = getModelTareaNoMedibleModel(tarea, 1);
            });
        }

        return {
            ResultadoClaveMedicionID: $(ElementosComunesOKR.MedicionElements.resultadoClaveMedicionID).val(),
            ResultadoClaveID: $(ElementosComunesOKR.ResultadoClaveElements.txtHiddenObjetivo).val(),
            EsMedible: esMedible,
            TipoMedicionID: tipoMedicion,
            ValorMaximoMedicion: valorMedicion,
            Tareas: medicionTareas
        }
    }

    function getModelTareaNoMedibleModel(tareaDOM, orden) {
        let descripcion = null;
        const descripcionDOM = $(tareaDOM).find("#Descripcion");
        if (descripcionDOM.length > 0)
            descripcion = descripcionDOM[0].value;

        let medicionTareaID = 0;
        const medicionTareaDOM = $(tareaDOM).find(ElementosComunesOKR.MedicionElements.medicionTareaID);
        if (medicionTareaDOM.length > 0)
            medicionTareaID = medicionTareaDOM[0].value;

        return {
            MedicionTareaID: medicionTareaID,
            ResultadoClaveMedicionID: $(ElementosComunesOKR.MedicionElements.resultadoClaveMedicionID).val(),
            Descripcion: descripcion,
            Orden: ++orden
        }
    }

    function initEventListeners() {
        let initDate = new Date(2022, 0, 1);

        let objetivoFormIDSelector = 'form-objetivo-' + $(ElementosComunesOKR.ResultadoClaveElements.txtHiddenObjetivo).val();

        let objetivoStartDatePicker = $(`#${objetivoFormIDSelector} ${ElementosComunesOKR.ResultadoClaveElements.objetivoStartDatePicker}`);
        let objetivoEndDatePicker = $(`#${objetivoFormIDSelector} ${ElementosComunesOKR.ResultadoClaveElements.objetivoEndDatePicker}`);

        let objetivoStartDate = objetivoStartDatePicker.datepicker("getDate");
        let objetivoEndDate = objetivoEndDatePicker.datepicker("getDate");

        $(ElementosComunesOKR.ResultadoClaveElements.txtDescripcionKR).change(function () {
            saveKRChanges();
        });

        $(ElementosComunesOKR.ResultadoClaveElements.datePickerStart)
            .datepicker({
                autoclose: true,
                format: "dd/MM/yyyy",
                orientation: "bottom right",
                language: "es",
                daysOfWeekDisabled: "0,6",
                startDate: objetivoStartDate == null ? initDate : objetivoStartDate,
                endDate: objetivoEndDate == null ? initDate : objetivoEndDate
            });

        $(ElementosComunesOKR.ResultadoClaveElements.datePickerEnd)
            .datepicker({
                autoclose: true,
                format: "dd/M/yyyy",
                orientation: "bottom right",
                language: "es",
                daysOfWeekDisabled: "0,6",
                startDate: objetivoStartDate == null ? initDate : objetivoStartDate,
                endDate: objetivoEndDate == null ? initDate : objetivoEndDate
            });

        initDatePickerValues();

        $(ElementosComunesOKR.ResultadoClaveElements.datePickerStart).datepicker().off("changeDate");
        $(ElementosComunesOKR.ResultadoClaveElements.datePickerStart)
            .datepicker().on("changeDate", function (e) {
                $(ElementosComunesOKR.ResultadoClaveElements.datePickerEnd).datepicker("setStartDate", $(this).datepicker("getDate"));
                saveKRChanges();
            });

        $(ElementosComunesOKR.ResultadoClaveElements.datePickerEnd).datepicker().off("changeDate");
        $(ElementosComunesOKR.ResultadoClaveElements.datePickerEnd)
            .datepicker().on("changeDate", function (e) {
                saveKRChanges();
            });


        AddValidacionesResultadoClave();

        $(ElementosComunesOKR.ResultadoClaveElements.btnKRFinish).off('click')
        $(ElementosComunesOKR.ResultadoClaveElements.btnKRFinish).on('click', function (e) {
            e.preventDefault();
            saveKRChanges();
            refreshResultadosClave();
        });

        $(ElementosComunesOKR.ResultadoClaveElements.btnCloseModal).off('click')
        $(ElementosComunesOKR.ResultadoClaveElements.btnCloseModal).on('click', function (e) {
            e.preventDefault();
            refreshResultadosClave();
        });

        $(document).off('hidden.bs.modal');
        $(document).on('hidden.bs.modal', '.modal',
            () => $('.modal:visible').length && $(document.body).addClass('modal-open'));

        if (objetivoStartDate == null || objetivoEndDate == null) {
            $(ElementosComunesOKR.ResultadoClaveElements.datePickerStart).prop('disabled', true);
            $(ElementosComunesOKR.ResultadoClaveElements.datePickerEnd).prop('disabled', true);
        }

    }

    function refreshResultadosClave() {
        Loading.Show();
        let objetivoID = $(ElementosComunesOKR.ResultadoClaveElements.txtHiddenObjetivo).val();

        let success = function (response) {

            let containerName = ".container-resultados-clave-" + objetivoID;

            $(containerName).html('');
            $(containerName).html(response);

            Loading.Hide();
        };

        let error = function (response) {
            ajaxErrorMessage(response);
            Loading.Hide();
        };

        let objetivoParam = {
            objetivoId: objetivoID
        };

        _resultadoClaveService.RefreshOKRView(objetivoParam, success, error)
    }

    function saveKRChanges() {

        let success = function (response) {
            NotificaDatosGuardados(response);
        };

        let error = function (response) {
            ajaxErrorMessage(response);
        };

        _resultadoClaveService.SaveKR(modelParam(), success, error);

    }

    function NotificaDatosGuardados(success) {
        if (success) {
            toastr.options = {
                "closeButton": true,
                "debug": false,
                "newestOnTop": false,
                "progressBar": false,
                "positionClass": "toast-top-right",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "500",
                "hideDuration": "500",
                "timeOut": "2000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "slideDown",
                "hideMethod": "slideUp"
            };
            toastr.info("Datos autoguardados.");
        }
        else {
            toastr.options = {
                "closeButton": true,
                "debug": false,
                "newestOnTop": false,
                "progressBar": false,
                "positionClass": "toast-top-right",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "500",
                "hideDuration": "500",
                "timeOut": "4000",
                "extendedTimeOut": "2000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "slideDown",
                "hideMethod": "slideUp"
            };
            toastr.warning("Si el problema persiste, refresca la pantalla.", "Error al guardados datos");
        }
    }

    const OnFrecuenciaChange = function () {
        saveKRChanges();
    };

    function AddValidacionesResultadoClave() {
        const fvrc = FormValidation.formValidation(
            document.getElementById(ElementosComunesOKR.ResultadoClaveElements.frmDescripcion),
            {
                fields: {
                    "Descripcion": {
                        validators: {
                            notEmpty: {
                                message: 'Por favor ingresa la descripción del Resultado Clave.'
                            }
                        }
                    }
                },

                plugins: {
                    trigger: new FormValidation.plugins.Trigger(),
                    bootstrap: new FormValidation.plugins.Bootstrap(),
                    submitButton: new FormValidation.plugins.SubmitButton(),
                    defaultSubmit: new FormValidation.plugins.DefaultSubmit(),
                }
            }
        );
    }

    const InitMedicion = function () {
        $(ElementosComunesOKR.MedicionElements.btnAddTareaNoMedible).off('click');
        $(ElementosComunesOKR.MedicionElements.btnAddTareaNoMedible).on('click', function (e) {
            e.preventDefault();
            addTareaNoMedible();
        });

        $(ElementosComunesOKR.MedicionElements.chkMedibleNoMedible).change(function () {
            ValidateNumberTareasNoMedibles();
            ShowPanelMedicion(1000);
            saveKRChanges();
        });

        $(ElementosComunesOKR.MedicionElements.txtValorMedicion).change(function () {
            saveKRChanges();
        });

        $(ElementosComunesOKR.MedicionElements.txtValorMedicion).on("keyup", function (event) {
            FloatThousandSeparatorKeyUpEvent(this, event);
        });


        $(ElementosComunesOKR.MedicionElements.descripcionTareaNoMedibleClass).on('change', function () {
            saveKRChanges();
        });

        handleRemoveTareaNoMedible();

        ShowPanelMedicion(0);
    }

    function handleRemoveTareaNoMedible() {
        $(ElementosComunesOKR.MedicionElements.btnRemoveTareaNoMedible).off("click");

        $(ElementosComunesOKR.MedicionElements.btnRemoveTareaNoMedible).on("click", function () {
            removeTareaNoMedible(this);
        });
    }

    function ValidateNumberTareasNoMedibles() {
        let tareasNoMediblesDOM = $(ElementosComunesOKR.MedicionElements.tareaNoMedibleClass);
        if (tareasNoMediblesDOM.length == 0)
            addTareaNoMedible();
    }

    function addTareaNoMedible() {
        Loading.Show();

        let success = function (response) {
            $(ElementosComunesOKR.MedicionElements.containerTareasNoMedibles).append(response);
            $(ElementosComunesOKR.MedicionElements.descripcionTareaNoMedibleClass).off('change');
            $(ElementosComunesOKR.MedicionElements.descripcionTareaNoMedibleClass).on('change', function () {
                saveKRChanges();
            });
            handleRemoveTareaNoMedible();
            Loading.Hide();
        };

        let error = function (response) {
            ajaxErrorMessage(response);
            Loading.Hide();
        };

        let resultadoClaveMedicionID = $(ElementosComunesOKR.MedicionElements.resultadoClaveMedicionID).val();

        _resultadoClaveService.AddTareaNoMedible(resultadoClaveMedicionID, success, error)
    }

    function removeTareaNoMedible(source) {
        Loading.Show();
        const tareaNoMedibleContainerIDSelector = source.closest(ElementosComunesOKR.MedicionElements.tareaNoMedibleClass);
        const tareaNoMedibleID = $(`#${tareaNoMedibleContainerIDSelector.id} ${ElementosComunesOKR.MedicionElements.medicionTareaID}`)[0].value;

        const success = function (response) {
            NotificaDatosGuardados(response);
            if (response === true) {
                tareaNoMedibleContainerIDSelector.remove();
            }
            Loading.Hide();
        };
        const error = function (response) {
            ajaxErrorMessage(response);
            Loading.Hide();
        };

        _resultadoClaveService.RemoveTareaNoMedible(tareaNoMedibleID, success, error);
    }

    function ShowPanelMedicion(milisenconds) {
        if ($(ElementosComunesOKR.MedicionElements.chkMedibleNoMedible).prop('checked')) {
            $(ElementosComunesOKR.MedicionElements.containerMedible).show(milisenconds);
            $(ElementosComunesOKR.MedicionElements.containerNoMedible).hide(milisenconds);
        }
        else {
            $(ElementosComunesOKR.MedicionElements.containerNoMedible).show(milisenconds);
            $(ElementosComunesOKR.MedicionElements.containerMedible).hide(milisenconds);
        }
    }

    const OnTipoMedicionChange = function () {
        saveKRChanges();
    };

    const OnDireccionEjecutivaChange = function () {
        ReloadArea();
        ReloadDDLEmpleado();
    }

    const OnAreaChange = function () {
        ReloadDDLEmpleado();
    };

    function ReloadArea() {
        var dropdown = $(ElementosComunesOKR.ParticipantesElements.ddlAreas).data("kendoDropDownList");
        dropdown.dataSource.read();
        dropdown.refresh();
    }

    function ReloadDDLEmpleado() {
        var comboBox = $(ElementosComunesOKR.ParticipantesElements.ddlEmpleados).data("kendoMultiSelect");
        comboBox.dataSource.read();
        comboBox.refresh();
    }

    const GetSelectedDireccionEjecutiva = function () {
        return {
            direccionEjecutivaID: $(ElementosComunesOKR.ParticipantesElements.ddlDireccionesEjecutivas).data("kendoDropDownList").value()
        };
    };

    const GetSelectedDireccionEjecutivaAndArea = function () {
        let multiSelectSearchValue = "";
        let filtroMultiSelect = $(ElementosComunesOKR.ParticipantesElements.ddlEmpleados).data("kendoMultiSelect").dataSource.filter();
        if (filtroMultiSelect != null && filtroMultiSelect.filters != null && filtroMultiSelect.filters.length > 0)
            multiSelectSearchValue = filtroMultiSelect.filters[0].value;

        return {
            direccionEjecutivaID: $(ElementosComunesOKR.ParticipantesElements.ddlDireccionesEjecutivas).data("kendoDropDownList").value(),
            areaID: $(ElementosComunesOKR.ParticipantesElements.ddlAreas).data("kendoDropDownList").value(),
            text: multiSelectSearchValue //$(ElementosComunesOKR.ParticipantesElements.ddlEmpleados).data("kendoMultiSelect").text()
        };
    };

    const InitParticipantes = function () {
        $(ElementosComunesOKR.ParticipantesElements.btnAgregarParticipante).on('click', function () {
            SaveParticipante();
        });

        $(ElementosComunesOKR.ParticipantesElements.btnCancelaEdicion).on('click', function () {
            setBtnAddParticipante();
            $(ElementosComunesOKR.ParticipantesElements.txtExplicacionParticipante).val("");
            $(ElementosComunesOKR.ParticipantesElements.ddlEmpleados).data("kendoComboBox").value("");
            $(ElementosComunesOKR.ParticipantesElements.empleadoParticipanteID).val("");
        });

        $(ElementosComunesOKR.ParticipantesElements.btnCloseModalEditParticipante).click(function () {
            $(ElementosComunesOKR.ParticipantesElements.modalParticipanteID).modal('hide');
        });

        $(ElementosComunesOKR.ParticipantesElements.btnSaveParticipanteEdit).click(function () {
            saveEditedParticipante();
        });

        AddEventHandlerPanelParticipantes();

        setBtnAddParticipante();
        tippy(ElementosComunesOKR.ParticipantesElements.participantesDetailDescriptionClass, { allowHTML: true, theme: "light", animation: "scale", placement: "top", inertia: true, maxWidth: 600 });
    };

    function AddEventHandlerPanelParticipantes() {
        $(ElementosComunesOKR.ParticipantesElements.btnEditParticipanteClass).on('click', function () {
            const button = $(this);
            const resultadoClaveParticipanteID = button.attr(ElementosComunesOKR.ParticipantesElements.dataResultadoClaveParticipanteID);
            editParticipante(resultadoClaveParticipanteID);
        });

        $(ElementosComunesOKR.ParticipantesElements.btnDeleteParticipanteClass).on('click', function () {
            const button = $(this);
            const resultadoClaveParticipanteID = button.attr(ElementosComunesOKR.ParticipantesElements.dataResultadoClaveParticipanteID);
            removeParticipante(resultadoClaveParticipanteID);
        });
    }

    function SaveParticipante() {
        let model = getModelParticipante();
        if (!ValidateParticipante(model))
            return;

        Loading.Show();
        const success = function (response) {
            NotificaDatosGuardados(true);
            ProcessSaveParticipante(response);
            Loading.Hide();
        };
        const error = function (response) {
            ajaxErrorMessage(response);
            Loading.Hide();
        };

        _resultadoClaveService.AddParticipantes(model, success, error);
    }

    function ValidateParticipante(model) {
        let texto = "";
        if (model.EmpleadosIDs.length === 0)
            texto += "<br />Debes seleccionar un empleado.";
        if (model.MotivoParticipacion.length == "")
            texto += "<br />Debes indicar el motivo de incluir al participante.";

        if (texto.length > 0) {
            modalMessage("error", "Información incompleta", texto);
            return false;
        }
        return true;
    }

    function ProcessSaveParticipante(response) {
        setBtnAddParticipante();
        $(ElementosComunesOKR.ParticipantesElements.panelParticipantes).html(response);
        AddEventHandlerPanelParticipantes();
        tippy(ElementosComunesOKR.ParticipantesElements.participantesDetailDescriptionClass, { allowHTML: true, theme: "light", animation: "scale", placement: "top", inertia: true, maxWidth: 600 });
        $(ElementosComunesOKR.ParticipantesElements.txtExplicacionParticipante).val("");
        $(ElementosComunesOKR.ParticipantesElements.ddlEmpleados).data("kendoMultiSelect").value("");
    }

    function getModelParticipante() {
        let empleadosIDs = $(ElementosComunesOKR.ParticipantesElements.ddlEmpleados).data("kendoMultiSelect").value()
        return {
            ResultadoClaveParticipanteID: $(ElementosComunesOKR.ParticipantesElements.empleadoParticipanteID).val(),
            ResultadoClaveID: $(ElementosComunesOKR.ResultadoClaveElements.txtHiddenResultadoClave).val(),
            EmpleadosIDs: empleadosIDs,
            MotivoParticipacion: $(ElementosComunesOKR.ParticipantesElements.txtExplicacionParticipante).val()
        };
    }

    function editParticipante(resultadoClaveParticipanteID) {
        Loading.Show();

        const success = function (response) {
            Loading.Hide();

            $(ElementosComunesOKR.ParticipantesElements.resultadoClaveParticipanteEditID).val(response.ResultadoClaveParticipanteID);
            $(ElementosComunesOKR.ParticipantesElements.empleadoParticipanteEditID).val(response.EmpleadoID);
            $(ElementosComunesOKR.ParticipantesElements.empleadoEditNombre).text(response.Empleado.Nombre);
            $(ElementosComunesOKR.ParticipantesElements.txtMotivoParticipanteEdit).val(response.MotivoParticipacion);

            $(ElementosComunesOKR.ParticipantesElements.modalParticipanteID).modal({
                show: true
            });
        };

        const error = function (response) {
            ajaxErrorMessage(response);
            Loading.Hide();
        };

        _resultadoClaveService.GetResultadoClaveParticipante(resultadoClaveParticipanteID, success, error);
    }

    function saveEditedParticipante() {
        let model = {
            ResultadoClaveParticipanteID: $(ElementosComunesOKR.ParticipantesElements.resultadoClaveParticipanteEditID).val(),
            ResultadoClaveID: $(ElementosComunesOKR.ResultadoClaveElements.txtHiddenResultadoClave).val(),
            EmpleadoID: $(ElementosComunesOKR.ParticipantesElements.empleadoParticipanteEditID).val(),
            MotivoParticipacion: $(ElementosComunesOKR.ParticipantesElements.txtMotivoParticipanteEdit).val()
        };

        Loading.Show();
        const success = function (response) {
            NotificaDatosGuardados(true);
            ProcessSaveParticipante(response);
            $(ElementosComunesOKR.ParticipantesElements.modalParticipanteID).modal('hide');
            Loading.Hide();
        };
        const error = function (response) {
            ajaxErrorMessage(response);
            Loading.Hide();
        };

        _resultadoClaveService.EditParticipante(model, success, error);
    }

    function setBtnAddParticipante() {
        $(ElementosComunesOKR.ParticipantesElements.btnAgregarParticipante).html('<i class="fa fa-plus"></i>Agregar');
        $(ElementosComunesOKR.ParticipantesElements.btnCancelaEdicion).hide();
    }


    function removeParticipante(resultadoClaveParticipanteID) {
        Loading.Show();

        const success = function (response) {
            NotificaDatosGuardados(true);
            ProcessSaveParticipante(response);
            Loading.Hide();
        };
        const error = function (response) {
            ajaxErrorMessage(response);
            Loading.Hide();
        };

        _resultadoClaveService.RemoveResultadoClaveParticipante(resultadoClaveParticipanteID, $(ElementosComunesOKR.ResultadoClaveElements.txtHiddenResultadoClave).val(), success, error);
    }

    const OnEmpleadoChange = function () {
        var combo = this;
        if (combo.value() === '-1')
            combo.select(-1);
    };

    const OnEmpleadoFiltering = function () {
        if (_isProgramatricFiltering) {
            $(ElementosComunesOKR.ParticipantesElements.ddlEmpleados).getKendoComboBox().value(_participanteModificadoID);
            setTimeout(function () {
                $(ElementosComunesOKR.ParticipantesElements.ddlEmpleados).getKendoComboBox().close();
            }, 100);
            _isProgramatricFiltering = false;
            _participanteModificadoID = 0;
            Loading.Hide();
        }
    };

    return {
        init,
        OnFrecuenciaChange,
        InitMedicion,
        OnTipoMedicionChange,
        OnAreaChange,
        OnDireccionEjecutivaChange,
        GetSelectedDireccionEjecutiva,
        GetSelectedDireccionEjecutivaAndArea,
        InitParticipantes,
        OnEmpleadoChange,
        OnEmpleadoFiltering
    }
})();