﻿const PeriodosCongeladosService = (function () {
    let _url = `${window.location.origin}/Objetivos/PeriodosCongelados`;

    const GetFreezedQuarters = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/GetFreezedQuarters`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const GetFreezedQuarter = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/GetFreezedQuarter`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const ReadKeyResultFreezedView = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_url}/ReadKeyResultFreezedView`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    return {
        GetFreezedQuarters,
        GetFreezedQuarter,
        ReadKeyResultFreezedView
    };

})();