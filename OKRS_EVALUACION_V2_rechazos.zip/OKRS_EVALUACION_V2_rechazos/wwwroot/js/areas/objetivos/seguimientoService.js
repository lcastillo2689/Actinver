﻿const SeguimientoService = (function () {
    let _urlAprobacion = `${window.location.origin}/Objetivos/Aprobacion/Index`;
    let _urlEvaluacion = `${window.location.origin}/Evaluacion/Autoevaluacion`;
    let _urlSeguimiento = `${window.location.origin}/Objetivos/Seguimiento`;


    const ShowAprobal = function (empleadoID) {
        let url = `${_urlAprobacion}?empleadoID=${empleadoID}`;
        window.open(url, '_blank').focus();
    }


    const VerAutoevaluacion = function (parameters, success, error) {
        $.ajax({
            dataype: "json",
            contentType: 'application/json; charset=utf-8',
            type: "GET",
            url: `${_urlEvaluacion}/GetAutoevaluacionEmpleado`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            }
        });
    };

    const GetEstadisticasRetroView = function (success, error) {
        $.ajax({
            dataype: "json",
            contentType: 'application/json; charset=utf-8',
            type: "GET",
            url: `${_urlSeguimiento}/GetEstadisticasRetroView`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            }
        });
    };

    return {
        ShowAprobal,
        VerAutoevaluacion,
        GetEstadisticasRetroView
    };

})();