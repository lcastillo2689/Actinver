﻿const VistaGloblaController = (function () {
    let _components = {
        datePickerPeriodo: "#year-date-picker",

        btnExportaExcel: "#btn-export-excel",
    };

    let _objetivoService = null;

    const initController = function (objetivoService) {

        _objetivoService = objetivoService;
        InitializeDatePicker();

        initEventListeners();
    };

    function initEventListeners() {
        $(_components.btnExportaExcel).on('click', function () {
            let periodoSelected = $(_components.datePickerPeriodo).datepicker("getDate");
            let periodoSelectedQueryString = formatQueryStringDateObject(periodoSelected);
            VistaGloablService.ExportObjetivos(periodoSelectedQueryString);
        });

        $("#opt-MenuAutoevaluacion").on('click', function () {
            validarObjetivosAprobados();
        });
    }

    function validarObjetivosAprobados() {
        const periodoOKR = $(ElementosComunesOKR.PeriodoEvaluacionElements.yearPickerSelector).datepicker("getDate");
        let success = function (response) {

            if (response.success)
                window.location.href = response.redirectTo;
            else
                modalMessage("warning", "¡Oops!", "No puedes inciar tu <strong>Atuevaluación<strong> si tus objetivos <ul><li><span class='text-danger'><strong>No han sido aprobados</strong></span></li><li><span class='text-danger'><strong>No cuentan con una Ponderación (peso) definida.</strong></span></li></ul> ");
        }

        let error = function (response) {
            ajaxErrorMessage(response);
        }

        _objetivoService.ValidarObjetivosAprobados(formatQueryStringDateObject(periodoOKR), success, error);
    }

    function InitializeDatePicker(periodo) {

        let currentDate = new Date();

        const initDate = new Date(2022, 0, 1);
        const maxDate = new Date(2022, 11, 31);

        if (currentDate < initDate)
            currentDate = initDate;

        $(_components.datePickerPeriodo).datepicker({
            format: "yyyy",
            viewMode: "years",
            minViewMode: "years",
            autoclose: true,
            startDate: initDate,
            minDate: initDate,
            endDate: maxDate,
            setDate: currentDate
        }).on('changeDate', function () {
            // LoadYear();
        });


        if (periodo !== undefined)
            $(_components.datePickerPeriodo).datepicker("setDate", periodo);
        else
            $(_components.datePickerPeriodo).datepicker("setDate", currentDate);
    }


    //function LoadYear() {
    //    Loading.Show();
    //    const periodo = $(_components.datePickerPeriodo).datepicker("getDate");

    //    const success = function (response) {
    //        Loading.Hide();
    //    };
    //    const error = function (response) {
    //        ajaxErrorMessage(response);
    //        Loading.Hide();
    //    };

    //    _objetivoService.LoadPeriod(formatQueryStringDateObject(periodo), _empleadoIDConsultado, success, error);
    //}
    return {
        initController
    }

})();