﻿var sbdll = {};

/*
dll.alertMessage(config)

config = {
    target: 'div-id'
    alertType : 'warning',
    title: 'titulo',
    message: 'mensaje'
};
*/
sbdll.alertMessage = function (config) {
    var id = new Date().getTime();
    var html = [
        '<div class="alert alert-', config.alertType, '" id="', id ,'" style="display:none;">',
            '<strong>', config.title , '</strong>' , config.message ,
        '</div>'
    ].join("");

    $(config.target).append(html);

    return $('#' + id);
};

function error_handler(e) {

    if (e.errors) {
        var message = "Errores:\n";
        $.each(e.errors, function (key, value) {
            if ('errors' in value) {
                $.each(value.errors, function () {
                    message += this + "\n";
                });
            }
        });
        swal({
            html: true,
            title: "Error",
            text: message,
            type: tipo,
            showCancelButton: false,
            closeOnConfirm: true,
            confirmButtonText: "OK",
            customClass: clasePersonalizada
        });
    }
}

function serialize(data) {
    for (var property in data) {
        if ($.isArray(data[property])) {
            serializeArray(property, data[property], data);
        }
    }
}

function serializeArray(prefix, array, result) {
    for (var i = 0; i < array.length; i++) {
        if ($.isPlainObject(array[i])) {
            for (var property in array[i]) {
                result[prefix + "[" + i + "]." + property] = array[i][property];
            }
        }
        else {
            result[prefix + "[" + i + "]"] = array[i];
        }
    }
}

function ReloadTooltips() {
    // global tooltips
    $('.tooltips').tooltip();

    // portlet tooltips
    $('.portlet > .portlet-title .fullscreen').tooltip({
        trigger: 'hover',
        container: 'body',
        title: 'Fullscreen'
    });
    $('.portlet > .portlet-title > .tools > .reload').tooltip({
        trigger: 'hover',
        container: 'body',
        title: 'Reload'
    });
    $('.portlet > .portlet-title > .tools > .remove').tooltip({
        trigger: 'hover',
        container: 'body',
        title: 'Remove'
    });
    $('.portlet > .portlet-title > .tools > .config').tooltip({
        trigger: 'hover',
        container: 'body',
        title: 'Settings'
    });
    $('.portlet > .portlet-title > .tools > .collapse, .portlet > .portlet-title > .tools > .expand').tooltip({
        trigger: 'hover',
        container: 'body',
        title: 'Collapse/Expand'
    });
}


function ValidaInputTextVacio(inputID, errorMessage) {
    var txt = $('#' + inputID).val();

    if (txt != null && txt != "") {
        $('#' + inputID + '_validationMessage').hide();
        $("span[data-valmsg-for='" + inputID + "']").hide();
    }
    else {
        if (document.getElementById(inputID).disabled != true) {
            if (errorMessage == null || errorMessage == "") {
                errorMessage = $("input[name=" + inputID + "]").data("val-required");
            }

            $('#' + inputID + '_validationMessage').text(errorMessage);
            $("span[data-valmsg-for='" + inputID + "']").text(errorMessage);

            $('#' + inputID + '_validationMessage').show();
            $("span[data-valmsg-for='" + inputID + "']").show();
        }
    }
}

function MuestraInputError(inputID, errorMessage) {
    var txt = $('#' + inputID).val();

    $('#' + inputID + '_validationMessage').text(errorMessage);
    $("span[data-valmsg-for='" + inputID + "']").text(errorMessage);

    $('#' + inputID + '_validationMessage').show();
    $("span[data-valmsg-for='" + inputID + "']").show();
}

function ValidaSeleccionKendoDropDown(dropID, errorMessage) {
    var drop = $("#" + dropID).data("kendoDropDownList");
    if (drop.value() != "" && drop.value() != null) {
        $('#' + dropID + '_validationMessage').hide();
        $("span[data-valmsg-for='" + dropID + "']").hide();
    }
    else {
        if (!$("#" + dropID).parent().find(".k-dropdown-wrap").hasClass("k-state-disabled")) {
            if (errorMessage == null || errorMessage == "") {
                errorMessage = $("input[name=" + dropID + "]").data("val-required");
            }

            $('#' + dropID + '_validationMessage').text(errorMessage);
            $("span[data-valmsg-for='" + dropID + "']").text(errorMessage);

            $('#' + dropID + '_validationMessage').show();
            $("span[data-valmsg-for='" + dropID + "']").show();
            return false;
        }
    }
    return true;
}

function ValidaKendoDatePicker(dpName, errorMessage) {

    var dpID = dpName.replace(".", "_").replace(".", "_").replace(".", "_").replace(".", "_").replace(".", "_");

    var fechatexto = $('#' + dpID).val();
    var datepicker = $("#" + dpID).data("kendoDatePicker");

    if (errorMessage == null || errorMessage == "") {
        errorMessage = $("input[name=" + dpID + "]").data("val-date");
    }

    if (errorMessage == null || errorMessage == "") {
        errorMessage = "@Etiquetas.FechaInvalidaErrorMessage";
    }

    if ((fechatexto != "" && fechatexto != null) && datepicker.value() == null) {
        $('#' + dpID + '_validationMessage').text(errorMessage);
        $("span[data-valmsg-for='" + dpName + "']").text(errorMessage);

        $('#' + dpID + '_validationMessage').show();
        $("span[data-valmsg-for='" + dpName + "']").show();
    }
    else if ((fechatexto != "" && fechatexto != null) && datepicker.value() != null) {
        if (ValidaFecha(kendo.toString(datepicker.value(), 'dd/MM/yyyy'))) {
            $('#' + dpID + '_validationMessage').hide();
            $("span[data-valmsg-for='" + dpName + "']").hide();
        }
        else {
            $('#' + dpID + '_validationMessage').text(errorMessage);
            $("span[data-valmsg-for='" + dpName + "']").text(errorMessage);

            $('#' + dpID + '_validationMessage').show();
            $("span[data-valmsg-for='" + dpName + "']").show();
        }
    }
    else {
        $('#' + dpID + '_validationMessage').hide();
        $("span[data-valmsg-for='" + dpName + "']").hide();
    }

}

function ValidaKendoDateTimePicker(dpName, errorMessage) {

    var dpID = dpName.replace(".", "_").replace(".", "_").replace(".", "_").replace(".", "_").replace(".", "_");

    var fechatexto = $('#' + dpID).val();
    var datepicker = $("#" + dpID).data("kendoDateTimePicker");

    if (errorMessage == null || errorMessage == "") {
        errorMessage = $("input[name=" + dpID + "]").data("val-date");
    }

    if (errorMessage == null || errorMessage == "") {
        errorMessage = "@Etiquetas.FechaInvalidaErrorMessage";
    }

    if ((fechatexto != "" && fechatexto != null) && datepicker.value() == null) {
        $('#' + dpID + '_validationMessage').text(errorMessage);
        $("span[data-valmsg-for='" + dpName + "']").text(errorMessage);

        $('#' + dpID + '_validationMessage').show();
        $("span[data-valmsg-for='" + dpName + "']").show();
    }
    else if ((fechatexto != "" && fechatexto != null) && datepicker.value() != null) {
        if (ValidaFecha(kendo.toString(datepicker.value(), 'dd/MM/yyyy'))) {
            $('#' + dpID + '_validationMessage').hide();
            $("span[data-valmsg-for='" + dpName + "']").hide();
        }
        else {
            $('#' + dpID + '_validationMessage').text(errorMessage);
            $("span[data-valmsg-for='" + dpName + "']").text(errorMessage);

            $('#' + dpID + '_validationMessage').show();
            $("span[data-valmsg-for='" + dpName + "']").show();
        }
    }
    else {
        $('#' + dpID + '_validationMessage').hide();
        $("span[data-valmsg-for='" + dpName + "']").hide();
    }

}

function ValidaNumeroEntero(inputID, errorMessage) {

    var txt = $('#' + inputID).val();
    var reg = new RegExp('^\\d+$');

    if (!reg.test(txt)) {
        $('#' + inputID + '_validationMessage').hide();
        $("span[data-valmsg-for='" + inputID + "']").hide();
    }
    else {
        if (document.getElementById(inputID).disabled != true) {
            if (errorMessage == null || errorMessage == "") {
                errorMessage = $("input[name=" + inputID + "]").data("val-required");
            }

            $('#' + inputID + '_validationMessage').text(errorMessage);
            $("span[data-valmsg-for='" + inputID + "']").text(errorMessage);

            $('#' + inputID + '_validationMessage').show();
            $("span[data-valmsg-for='" + inputID + "']").show();
        }
    }
}

function ValidaEmail(inputName, errorMessage) {

    var inputID = inputName.replace(".", "_").replace(".", "_").replace(".", "_").replace(".", "_").replace(".", "_");

    var txt = $('#' + inputID).val();
    var reg = /^(([^<>()\[\]\.,;:\s@@\"]+(\.[^<>()\[\]\.,;:\s@@\"]+)*)|(\".+\"))@@(([^<>()[\]\.,;:\s@@\"]+\.)+[^<>()[\]\.,;:\s@@\"]{2,})$/i;
    if (reg.test(txt)) {
        $('#' + inputID + '_validationMessage').hide();
        $("span[data-valmsg-for='" + inputName + "']").hide();
    }
    else {
        if (document.getElementById(inputID).disabled != true) {
            if (errorMessage == null || errorMessage == "") {
                errorMessage = $("input[name='" + inputName + "']").data("val-email");
            }

            $('#' + inputID + '_validationMessage').text(errorMessage);
            $("span[data-valmsg-for='" + inputName + "']").text(errorMessage);

            $('#' + inputID + '_validationMessage').show();
            $("span[data-valmsg-for='" + inputName + "']").show();
        }
    }
}

function ValidaFecha(fecha) {
    var dateParts = fecha.split("/");

    if (dateParts.length < 3) {
        return false;
    }

    var objDate = new Date(dateParts[2], dateParts[1] - 1, dateParts[0]);

    if (objDate.getFullYear() != dateParts[2]) {
        return false;
    }

    if (objDate.getMonth() != dateParts[1] - 1) {
        return false;
    }

    if (objDate.getDate() != dateParts[0]) {
        return false;
    }

    return true;
}

function formatValueAutocomplete(itemText, txtID) {
    var text = $('#' + txtID).val();
    var textMatcher = new RegExp(text, "ig");

    itemText = itemText.replace(textMatcher, function (match) {
        return "<span class='autocomplete-remarcado'>" + match + "</span>";
    });

    return itemText;
}

//$(document).ready(function () {
//    $(".page-quick-sidebar-chat-users .media-list > .media").click(function (e) {
//        if ($(this).closest('.tab-pane').hasClass('history-invoice-pending')) {
//            $('#divPendiente').show('200');
//            $('#divAprobado').hide('200');
//        } else {
//            $('#divAprobado').show('200');
//            $('#divPendiente').hide('200');
//        }
//    })
//})

