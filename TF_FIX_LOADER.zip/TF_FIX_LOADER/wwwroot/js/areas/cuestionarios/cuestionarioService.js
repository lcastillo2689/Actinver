﻿const CuestionarioService = function () {
    let _urlCuestionario = `${window.location.origin}/TrabajoFlexible/Cuestionario`;

    let GetEmpleadoCuestionario = function (parameters, success, error) {

        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlCuestionario}/GetEmpleadoCuestionarioView`,
            cache: false,
            async: true,
            data: parameters,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    }

    let UpdateCuestionarioEmpleado = function (parameters, success, error) {
        console.log(parameters);
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${_urlCuestionario}/UpdateCuestionarioEmpleado`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    let GetEstatusCuestionarioView = function (parameters, success, error) {

        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlCuestionario}/GetEstatusCuestionarioView`,
            cache: false,
            async: true,
            data: parameters,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    let GetEstatusCuestionarioEmpleadosView = function (parameters, success, error) {

        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlCuestionario}/GetEstatusCuestionarioEmpleadosView`,
            cache: false,
            async: true,
            data: parameters,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    let GetEstatusCuestionarioGestionView = function (parameters, success, error) {

        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlCuestionario}/GetCuestionarioGestionView`,
            cache: false,
            async: true,
            data: parameters,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    let UpdateCuestionarioConsideracionEmpleado = function (parameters, success, error) {
        console.log(parameters);
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${_urlCuestionario}/UpdateCuestionarioConsideracionEmpleado`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    let GetEmpleadoConsideracionView = function (parameters, success, error) {

        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlCuestionario}/GetEmpleadoConsideracionView`,
            cache: false,
            async: true,
            data: parameters,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };


    return {
        GetEmpleadoCuestionario,
        UpdateCuestionarioEmpleado,
        GetEstatusCuestionarioView,
        GetEstatusCuestionarioEmpleadosView,
        GetEstatusCuestionarioGestionView,
        UpdateCuestionarioConsideracionEmpleado,
        GetEmpleadoConsideracionView
    }
}();