﻿const GestorDocumentalService = (function () {
    let _window_location = "";
    let _window_location_origin = "";

    const Init = function () {
        if (typeof ur_baseurl !== 'undefined') {
            _window_location = ur_firepass_host + ur_baseurl + "../";
            _window_location_origin = ur_firepass_host + "../";
        }
        else {
            _window_location = `${window.location}`;
            _window_location_origin = `${window.location.origin}`;
        }
        console.log('window.location', _window_location);
        console.log('window.location.origin', _window_location_origin);
    };

    const url = `${_window_location_origin}/Evidencias/GestorDocumental`;

    const LoadCargarArchivosFormModalMarkup = function (model, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${url}/CargarArchivosFormModal`,
            data: model,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const LoadFileNodeFormModalMarkup = function (id, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${url}/FileNodeFormModal/${id}`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const LoadColaboradorFormModalMarkup = function (success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${url}/ColaboradorFormModal`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };
    
    const LoadMoverFormModalMarkup = function (model, success, error) {
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${url}/MoverFormModal`,
            data: model,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const MoveToFolder = function (model, success, error) {
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${url}/MoveToFolder`,
            data: model,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const LoadFilesContentMarkup = function (model, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${url}/FilesContent`,
            data: model,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const SaveFileNode = function (model, success, error) {
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${url}/SaveFileNode`,
            data: model,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    const DeleteFileNodes = function (fileNodesIds, success, error) {
        $.ajax({
            datatype: "json",
            type: "DELETE",
            url: `${url}/DeleteFileNodes`,
            data: { fileNodesIds },
            cache: false,
            async: true,
            success: function (response) {
                if (success) success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    return {
        Init,

        LoadCargarArchivosFormModalMarkup,
        LoadFileNodeFormModalMarkup,
        LoadFilesContentMarkup,
        LoadMoverFormModalMarkup,
        SaveFileNode,
        MoveToFolder,
        DeleteFileNodes,
        LoadColaboradorFormModalMarkup,
    };
})();
