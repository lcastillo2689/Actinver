﻿const EmpleadosSentimientosService = (function () {
    let _urlEmpleadoSentimiento = `${window.location.origin}/Seguimiento/Sentimientos`;
    let _urlEmpleadosSentimientos = `${window.location.origin}/Seguimiento/Sentimientos`;
    let _urlUpdateEmpleadoSentimiento = `${window.location.origin}/Seguimiento/Sentimientos`;

    let GetEmpleadoSentimiento = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlEmpleadoSentimiento}/GetEmpleadoSentimientoView`,
            cache: false,
            async: true,
            data: parameters,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    }

    let GetEmpleadosSentimientos = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlEmpleadosSentimientos}/GetEmpleadosSentimientosView`,
            cache: false,
            async: true,
            data: parameters,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    }

    let UpdateComentario = function (parameters, success, error) {
        console.log(parameters);
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${_urlUpdateEmpleadoSentimiento}/UpdateComentario`,
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    let GuardarEmpleadoSentimientoJson = function (parameters, success, error) {
        console.log(parameters);
        $.ajax({
            datatype: "json",
            type: "POST",
            url: `${_urlEmpleadoSentimiento}/GuardarEmpleadoSentimientoJson`,//GuardarEmpleadoSentimientoJson
            data: parameters,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    };

    return {
        GetEmpleadoSentimiento,
        GetEmpleadosSentimientos,
        UpdateComentario,
        GuardarEmpleadoSentimientoJson
    }
})();