﻿const SentimientosController = function () {
    let _elements = {
        divSentimientos: "#divSentimientos",
    };

    const Init = function () {
        console.log("js/SentimientosController");
        GetSentimientos();

    }

    function GetSentimientos() {
        let success = function (response) {

            $(_elements.divSentimientos).html('');
            $(_elements.divSentimientos).html(response);
        }

        let error = function (response) {
            ajaxErrorMessage(response);
        }

        SentimientosService.GetSentimientos(success, error);
    }

    return {
        Init,
    }
}();