﻿const _items = {

};

const Loading = (function () {
    let _window_location;
    let _window_location_origin;

    if (typeof ur_baseurl !== 'undefined') {
        _window_location = ur_firepass_host + ur_baseurl + "";
        _window_location_origin = ur_firepass_host + "";
    }
    else {
        _window_location = window.location + "/";
        _window_location_origin = window.location.origin + "/";
    }

    console.log('window.location', _window_location);
    console.log('window.location.origin', _window_location_origin);

    const show = function () {
        $.blockUI({
            overlayCSS: {
                backgroundColor: "#fff",
                opacity: "0.6",
            },
            css: {
                border: "none",
                padding: "15px",
                "-webkit-border-radius": ".25rem",
                "-moz-border-radius": ".25rem",
                width: "20%",
                left: "40%",
                backgroundColor: "transparent",
                "font-size": "20px",
            },
            baseZ: 100000,
            message: `<img width='100' height='100' src='${window.location.origin}/images/iconos/loading-2.gif' />`,
        });
    };

    const hide = function () {
        $.unblockUI();
    };

    return {
        Show: show,
        Hide: hide,
    };
})();

function formatThousandSeparatorNumber(nStr, digits) {
    if (!digits && digits !== 0) digits = 2;

    if (!nStr && nStr != 0) return "";

    const response = Number(parseFloat(nStr).toFixed(digits)).toLocaleString("en", { minimumFractionDigits: digits });

    return response !== "NaN" ? response : "";
}

function gridErrorRequestHandler(e) {
    const response = e.xhr;
    ajaxErrorMessage(response, "Error al leer los datos de la tabla");
}

function ajaxErrorMessage(response, errorTitle) {
    if (response && response.status === 401) {
        showAuthenticationError();
        return;
    }

    let message;
    if (response && response.status === 409) {
        message = response.responseText;
    } else {
        message = getErrorMessage(response);
    }

    modalMessage("error", errorTitle || "Ocurrió un error", message);
}

function modalMessage(icon, title, text, func) {
    swal.fire({
        title: title,
        html: text,
        icon: icon,
        showCancelButton: false,
        showLoaderOnConfirm: false,
        heightAuto: false,
    }).then(func);
}

function confirmationMessage(text, preconfirmFunction, thenFunction, subTitle) {
    Swal.fire({
        title: text,
        html: subTitle,
        icon: "warning",
        showCancelButton: true,
        heightAuto: false,
        confirmButtonText: "Sí",
        cancelButtonText: "No",
        confirmButtonColor: "#34bfa3",
        cancelButtonColor: "#f4516c",
        showLoaderOnConfirm: true,
        preConfirm: preconfirmFunction,
        reverseButtons: true,
        allowOutsideClick: () => !Swal.isLoading(),
    }).then((result) => {
        if (result.value && thenFunction) thenFunction();
    });
}

function showAuthenticationError() {
    Swal.fire({
        icon: "warning",
        title: "Error de Autenticación",
        html: "No se pudo autorizar la conexión con el servidor. Es probable que tu sesión haya expirado y debas iniciar sesión nuevamente.",
        confirmButtonText: "<i class='fa fa-sign-in-alt mr-3'></i>Iniciar sesión en otra ventana",
        footer: "Inicia sesión en otra ventana y luego regresa a ésta para que no pierdas los cambios no guardados.",
        showCloseButton: true,
        heightAuto: false,
        allowOutsideClick: false,
    }).then((result) => {
        if (result.value) window.open(window.location.origin, "_blank");
    });
}

function getErrorMessage(response) {
    let message = "<span style='font-weight: bold;'>Ponte en contacto con el equipo de desarrollo.</span>";

    const errorMessage = response ? response.getResponseHeader("x-error-message") : "";
    if (errorMessage) message += `<br />ErrorMessage: ${errorMessage}`;

    const errorId = response ? response.getResponseHeader("x-error-id") : "";
    if (errorId) message += `<br />ErrorId: ${errorId}`;

    return message;
}

function convertDateToSqlFormat(date) {
    date = date.trim();
    let string = "";
    const split = date.split("/");
    string = split[2] + "-" + split[1] + "-" + split[0];
    return string;
}

function formatQueryStringDateObject(date) {
    return date.getMonth() + 1 + "-" + date.getDate() + "-" + date.getFullYear();
}

function GetDatesForDatePickers() {
    const fechaInicialCookie = getCookie("fechaInicial");
    const fechaFinalCookie = getCookie("fechaFinal");
    const fechaConsultaCookie = getCookie("fechaConsulta");

    if (fechaInicialCookie && fechaFinalCookie && fechaConsultaCookie) {
        return {
            FirstDate: new Date(fechaInicialCookie),
            LastDate: new Date(fechaFinalCookie),
            FechaConsulta: new Date(fechaConsultaCookie),
        };
    }

    let lastDate = GetLastDateForReports();
    if (lastDate === null) {
        lastDate = new Date();
        lastDate = GetPreviousWorkDay(lastDate);
    }

    let firstDate = new Date(lastDate.getFullYear(), lastDate.getMonth(), 1);
    firstDate = GetPreviousWorkDay(firstDate);

    setCookie("fechaInicial", firstDate);
    setCookie("fechaFinal", lastDate);
    setCookie("fechaConsulta", lastDate);

    return {
        FirstDate: firstDate,
        LastDate: lastDate,
        FechaConsulta: lastDate,
    };
}

function GetPreviousWorkDay(fecha) {
    let day = 0;
    let strDate;
    let esFeriado = false;
    do {
        fecha.setDate(fecha.getDate() - 1);
        day = fecha.getDay();
        strDate = `${fecha.getDate()}/${fecha.getMonth() + 1}/${fecha.getFullYear()}`;
        esFeriado = include(DisableDatesForHolidays(), strDate);
    } while (day === 6 || day === 0 || esFeriado);
    return fecha;
}

function include(arr, obj) {
    return arr.indexOf(obj) !== -1;
}

function kendoGridMoneyString(str) {
    return `$${str}`.replace("$-", "-$");
}

function DateToString(fecha) {
    const anio = fecha.getFullYear();
    let mes = fecha.getMonth() + 1;
    mes = mes >= 10 ? mes : "0" + mes;
    let dia = fecha.getDate();
    dia = dia >= 10 ? dia : "0" + dia;
    return `${dia}/${mes}/${anio}`;
}

function DateToStringWithMonthName(fecha) {
    const formatter = new Intl.DateTimeFormat("es", { month: "short" });
    const anio = fecha.getFullYear();
    let mes = formatter.format(fecha);
    let dia = fecha.getDate();
    dia = dia >= 10 ? dia : "0" + dia;
    return `${dia}/${mes}/${anio}`;
}

function getCookie(cname) {
    const name = cname + "=";
    const decodedCookie = decodeURIComponent(document.cookie);
    const ca = decodedCookie.split(";");
    for (let i = 0; i < ca.length; i++) {
        let c = ca[i];

        while (c.charAt(0) == " ") c = c.substring(1);

        if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
    }
    return "";
}

function setCookie(name, value) {
    const cookieValue = encodeURIComponent(value);

    const expiration = new Date();
    const minutesToExpire = 40;
    expiration.setTime(expiration.getTime() + minutesToExpire * 60000);

    document.cookie = `${name}=${cookieValue}; expires=${expiration.toUTCString()} path=/`;
}

function removeCookie(name) {
    document.cookie = name + "=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;";
}
