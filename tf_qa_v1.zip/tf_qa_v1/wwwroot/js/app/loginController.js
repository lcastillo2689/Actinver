﻿const LoginController = (function () {
    let _login;

    const Init = function () {
        //new PerfectScrollbar(".card-body");
        _login = $("#kt_login");

        handleInit();
        handleRecoveryPassword();

        initSignInForm();
        initForgotForm();
    };

    function handleInit() {
        const error = $("#hd-error").val();
        if (error) {
            swal.fire({
                text: error,
                icon: "error",
                buttonsStyling: false,
                confirmButtonText: "Ok",
                customClass: {
                    confirmButton: "btn font-weight-bold btn-light-primary",
                },
            });
        }
    }

    function handleRecoveryPassword() {
        const error = $("#hd-recovery_password").val();
        if (error) {
            swal.fire({
                text: "Recibirás un correo con tus credenciales si los datos coinciden con los que tenemos registrados.",
                icon: "success",
                buttonsStyling: false,
                confirmButtonText: "Ok",
                customClass: {
                    confirmButton: "btn font-weight-bold btn-light-primary",
                },
            });
        }
    }

    function initSignInForm() {
        let validation = FormValidation.formValidation(KTUtil.getById("kt_login_signin_form"), {
            fields: {
                username: {
                    validators: {
                        notEmpty: {
                            message: "El usuario es requerido",
                        },
                    },
                },
                password: {
                    validators: {
                        notEmpty: {
                            message: "La contrase&ntilde;a es requerida",
                        },
                    },
                },
            },
            plugins: {
                trigger: new FormValidation.plugins.Trigger(),
                submitButton: new FormValidation.plugins.SubmitButton(),
                bootstrap: new FormValidation.plugins.Bootstrap(),
            },
        });

        $("#kt_login_signin_submit").on("click", function (e) {
            e.preventDefault();

            validation.validate().then(function (status) {
                if (status == "Valid") $("#kt_login_signin_form").submit();
            });
        });

        $("#kt_login_forgot").on("click", function (e) {
            e.preventDefault();
            showForm("forgot");
            setTimeout(function () {
                $("#kt_login_forgot_form input[name='username']").focus();
            }, 500);
        });
    }

    function initForgotForm(e) {
        let validation = FormValidation.formValidation(KTUtil.getById("kt_login_forgot_form"), {
            fields: {
                numNomina: {
                    validators: {
                        notEmpty: {
                            message: "El número de nomina es requerido",
                        },
                    },
                },
                email: {
                    validators: {
                        notEmpty: {
                            message: "El email es requerido",
                        },
                        emailAddress: {
                            message: "Se requiere un email v&aacute;lido",
                        },
                    },
                },
            },
            plugins: {
                trigger: new FormValidation.plugins.Trigger(),
                bootstrap: new FormValidation.plugins.Bootstrap(),
            },
        });

        $("#kt_login_forgot_submit").on("click", function (e) {
            e.preventDefault();

            validation.validate().then(function (status) {
                if (status == "Valid") {
                    $("#kt_login_forgot_form").submit();
                }
            });
        });

        $("#kt_login_forgot_cancel").on("click", function (e) {
            e.preventDefault();

            showForm("signin");
            setTimeout(function () {
                $("#kt_login_signin_form input[name='username']").focus();
            }, 500);
        });
    }

    function showForm(form) {
        var cls = "login-" + form + "-on";
        var form = "kt_login_" + form + "_form";

        _login.removeClass("login-forgot-on");
        _login.removeClass("login-signin-on");
        _login.removeClass("login-signup-on");

        _login.addClass(cls);

        KTUtil.animateClass(KTUtil.getById(form), "animate__animated animate__backInUp");
    }

    return {
        Init,
    };
})();
