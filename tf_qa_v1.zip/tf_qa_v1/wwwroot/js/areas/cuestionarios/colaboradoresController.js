﻿const ColaboradoresController = function () {
    let _elements = {
        divColaboradores: "#divColaboradores",
        divModalBody: "#modal-tf-body",
        divModalBodyOKR: "#modal-okr-body",
        divCuestionario: "#divCuestionario",
        divEstatusHO: '#divEstatusHO-',

        btnCalificar: ".btn-Calificar",
        btnGuardarCuestionarioGestion: "btn-GuardarCuestionarioExtraordianario",
        btnConsideracion: '.btn-consideracion',
        btnNotificacionDesempenio: ".btn-notificacionDesempenio",

        modalTrabajoFlexible: '#modal-trabajoFelxible',
        modalDetalleOKR: '#modal-resultadoOKR'

    };

    let _dataAttributes = {
        empleadoId: "data-num",
        estatusOKR: "data-estatus"
    };

    const Init = function () {
        getColaboradoresACargo();

    }

    const InitColaboradoresForm = function (empleados) {
        setControlEvents();
    }

    function getModelCuestionario(empleadoId) {
        return {
            empleadoId: empleadoId
        }
    }

    function setControlEvents() {
        $(_elements.btnCalificar).on('click', function (e) {
            e.preventDefault();
            let empleadoId = $(this).attr(_dataAttributes.empleadoId);

            let estatusOKR = $(this).attr(_dataAttributes.estatusOKR);
            if (estatusOKR ==  "False") {
                modalMessage("warning", "¡Atención!", "<span>El colaborador debe finalizar su proceso de OKR's Q1 para poder gestionar su Trabajo Flexible</span>");
                $(_elements.divCuestionario).html('');
            } else {
                showEmpleadoCuestionario(empleadoId);
            }



        });

        $(_elements.btnConsideracion).on('click', function (e) {
            e.preventDefault();

            let empleadoId = $(this).attr(_dataAttributes.empleadoId);

            showEmpleadoConsideracion(empleadoId);
        });

        $(_elements.btnNotificacionDesempenio).on('click', function (e) {
            e.preventDefault();

            let empleadoId = $(this).attr(_dataAttributes.empleadoId);

            showDetalleDesempenioOKR(empleadoId);
        });

        tippy(_elements.btnConsideracion, { theme: "light", animation: "scale", placement: "bottom", inertia: true });
        tippy(_elements.btnNotificacionDesempenio, { theme: "light", animation: "scale", placement: "right", inertia: true });
    }

    function showEmpleadoCuestionario(empleadoId) {
        let success = function (response) {

            $(_elements.divCuestionario).html('');
            $(_elements.divCuestionario).html(response);
        }

        let error = function (response) {
            ajaxErrorMessage(response);
        }

        CuestionarioService.GetEmpleadoCuestionario(getModelCuestionario(empleadoId), success, error);
    }

    function getColaboradoresACargo() {
        let success = function (response) {

            $(_elements.divColaboradores).html('');
            $(_elements.divColaboradores).html(response);
        }

        let error = function (response) {
            ajaxErrorMessage(response);
        }

        ColaboradoresService.GetColaboradoresACargo(success, error);
    }

    function showEmpleadoConsideracion(empleadoId) {
        let success = function (response) {

            $(_elements.divModalBody).html('');
            $(_elements.divModalBody).html(response);
            $(_elements.modalTrabajoFlexible).modal('show');
        }

        let error = function (response) {
            ajaxErrorMessage(response);
        }

        CuestionarioService.GetEmpleadoConsideracionView(getModelCuestionario(empleadoId), success, error);
    }

    function showDetalleDesempenioOKR(empleadoId) {
        let success = function (response) {

            $(_elements.divModalBodyOKR).html('');
            $(_elements.divModalBodyOKR).html(response);
            $(_elements.modalDetalleOKR).modal('show');
        }

        let error = function (response) {
            ajaxErrorMessage(response);
            Loading.Hide();
        }

        ColaboradoresService.GetDetalleDesempenioOKRView(getModelCuestionario(empleadoId), success, error);
    }


    return {
        Init,
        InitColaboradoresForm,
    }

}();