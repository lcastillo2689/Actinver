﻿const ColaboradoresService = (function () {
    let _urlColaboradores = `${window.location.origin}/TrabajoFlexible/Colaboradores`;

    let GetColaboradoresACargo = function (success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlColaboradores}/GetEmployeesView`,
            cache: false,
            async: true,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    }

    let GetDetalleDesempenioOKRView = function (parameters, success, error) {
        $.ajax({
            datatype: "json",
            type: "GET",
            url: `${_urlColaboradores}/GetDetalleDesempenioOKRView`,
            cache: false,
            async: true,
            data: parameters,
            success: function (response) {
                success(response);
            },
            error: function (response) {
                error(response);
            },
        });
    }

    return {
        GetColaboradoresACargo,
        GetDetalleDesempenioOKRView
    }
})();