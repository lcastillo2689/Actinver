﻿const CuestionarioController = function () {
    let formCuestionarioGestion = null;

    let _elements = {
        divEstatusHO: '#divEstatusHO-',
        divModalBodyOKR: "#modal-okr-body",

        swPregunta: '.chkPregutna',
        chkDay: '.chkDayHomeOffice',
        chkCuestionarioExtraordinario: "#chkCuestionarioExtraordinario",

        gridColaboradores: '#grid-colaboradores',

        btnSeguimiento: '.btn-seguimiento',
        btnSaveCuestionarioGestion: '#btn-GuardarCuestionarioExtraordianario',
        btnQueryEmpleados: "#btn-query-empleados",
        btnDetalleOKR: '.btn-detalleOKRS',

        modalCuestionarioGestionBody: '#modal-gestion-body',

        txtDescripcionConsideracion: '#txtDescripcionConsideracion',
        txtQuery: "#txt-query-empleados",

        frmCuestionarioGestion: "frm-Consideraciones",

        modalDetalleOKR: '#modal-resultadoOKR'
    };

    let _dataAttributes = {
        empleadoId: "data-num",
        cuestionarioEmpleadoId: "data-cuestionario",
        preguntaId: "data-pregunta",
        dayHomeOffice: "data-day"
    };

    let InitController = function () {
        setEventHandler();
    }

    let InitColaboradoresGestionController = function () {
        setColaboradoresEventHandler();
        setTxtQueryListeners();
    }

    let InitCuestionarioGestion = function () {
        setCuestionarioGestionEventHandler();
        initCuestionarioGestionFormValidaciones();
    }

    //#region Models
    function getCuestionarioModel(empleadoId, cuestionarioEmpleadoId, preguntaId, dayHomeOffice, chkState) {

        let preguntas = [];
        let daysHomeOffice = [];

        if (!$.isEmptyObject(dayHomeOffice)) {
            daysHomeOffice.push({
                Id: dayHomeOffice,
                DayActive: chkState
            });
        }

        if (!$.isEmptyObject(preguntaId)) {
            preguntas.push({
                Id: preguntaId,
                Calificacion: chkState
            });
        }

        let model = {
            Id: cuestionarioEmpleadoId,
            EmpleadoId: empleadoId,
            PreguntasModelViewList: preguntas,
            DiasHomeOfficeList: daysHomeOffice
        };

        return model;
    }

    function getEstatusHOModel(empleadoId, cuestionarioEmpleadoId) {
        let model = {
            Id: cuestionarioEmpleadoId,
            EmpleadoId: empleadoId
        };

        return model;
    }

    function getCuestionarioGestionViewModel(empleadoId) {
        let model = {
            empleadoId: empleadoId
        };

        return model;
    }

    function getCuestionarioGestionModel() {
        let cuestionarioEmpleadoId = $(_elements.txtDescripcionConsideracion).attr(_dataAttributes.cuestionarioEmpleadoId);
        let empleadoId = $(_elements.txtDescripcionConsideracion).attr(_dataAttributes.empleadoId);
        let descripcionConsideracion = $(_elements.txtDescripcionConsideracion).val();
        let estatusCuestionario = $(_elements.chkCuestionarioExtraordinario).is(':checked');

        let model = {
            Id: cuestionarioEmpleadoId,
            EmpleadoId: empleadoId,
            EmpleadoConsideracionModelView: {
                Descripcion: descripcionConsideracion,
                Autorizacion: estatusCuestionario
            }
        };

        return model;

        return model;
    }
    //#endregion

    function setEventHandler() {
        $(_elements.swPregunta).change(function (e) {
            let state = $(this).prop('checked');
            let empleadoId = $(this).attr(_dataAttributes.empleadoId);
            let cuestionarioEmpleadoId = $(this).attr(_dataAttributes.cuestionarioEmpleadoId);
            let preguntaId = $(this).attr(_dataAttributes.preguntaId);


            updateCuestionarioEmpleado(empleadoId, cuestionarioEmpleadoId, preguntaId, 0, state);
        })

        $(_elements.chkDay).change(function (e) {
            let state = $(this).prop('checked');
            let empleadoId = $(this).attr(_dataAttributes.empleadoId);
            let cuestionarioEmpleadoId = $(this).attr(_dataAttributes.cuestionarioEmpleadoId);
            let dayHomeOffice = $(this).attr(_dataAttributes.dayHomeOffice);

            updateCuestionarioEmpleado(empleadoId, cuestionarioEmpleadoId, 0, dayHomeOffice, state);
        })
    }

    function setColaboradoresEventHandler() {
        $(_elements.gridColaboradores).on("click", _elements.btnSeguimiento, function (e) {
            e.preventDefault();
            let empleadoID = $(this).attr(_dataAttributes.empleadoId);

            showCuestionarioGestion(empleadoID)
        });

    }

    function setCuestionarioGestionEventHandler() {
        $(_elements.btnSaveCuestionarioGestion).on("click", function (e) {
            e.preventDefault();

            formCuestionarioGestion.validate().then(function (status) {
                debugger;
                if (status === 'Invalid')
                    return false;

                if (status === 'Valid')
                    updateCuestionarioExceptionEmpleado();
            });
        });
    }

    function setTxtQueryListeners() {
        $(_elements.txtQuery).keyup(function (e) {
            if (e.keyCode === 13) TablesController.ReloadGrid(_elements.gridColaboradores);
        });

        $(_elements.btnQueryEmpleados).on("click", function () {
            TablesController.ReloadGrid(_elements.gridColaboradores);
        });

    }

    function initCuestionarioGestionFormValidaciones() {
        formCuestionarioGestion = FormValidation.formValidation(
            document.getElementById(_elements.frmCuestionarioGestion),
            {
                fields: {
                    "txtDescripcionConsideracion": {
                        validators: {
                            notEmpty: {
                                message: 'Requerido'
                            },
                            stringLength: {
                                min: 50,
                                max: 2500,
                                message: 'Por favor ingresa una descripción con longitud mínima de 50 caracteres'
                            }
                        }
                    },
                },

                plugins: {
                    trigger: new FormValidation.plugins.Trigger(),
                    bootstrap: new FormValidation.plugins.Bootstrap(),
                    submitButton: new FormValidation.plugins.SubmitButton(),
                    defaultSubmit: new FormValidation.plugins.DefaultSubmit(),
                }
            },
        );
    }

    function updateCuestionarioEmpleado(empleadoId, cuestionarioEmpleadoId, preguntaId, dayHomeOffice, chkState) {

        var model = getCuestionarioModel(empleadoId, cuestionarioEmpleadoId, preguntaId, dayHomeOffice, chkState);

        let success = function (response) {

            if (!response.updateSuccess)
                modalMessage("error", "Error", "<span>La evaluación no puede ser enviada a revisión</span><br /><span>Debes calificar todos los objetivos</span><br /><span>Describir el resultado del objetivo</span><br /><span>La ponderación (peso) de los objetivos debe sumar 100</span>");
            else {
                toastr.success("¡La información ha sido guardada correctamente!");

                showEstatusHO(empleadoId, cuestionarioEmpleadoId);
            }
        }

        let error = function (response) {
            ajaxErrorMessage(response);
        }

        CuestionarioService.UpdateCuestionarioEmpleado(model, success, error);
    }

    function showEstatusHO(empleadoId, cuestionarioEmpleadoId) {
        let success = function (response) {

            $(_elements.divEstatusHO + empleadoId).html('');
            $(_elements.divEstatusHO + empleadoId).html(response);
        }

        let error = function (response) {
            ajaxErrorMessage(response);
        }

        CuestionarioService.GetEstatusCuestionarioView(getEstatusHOModel(empleadoId, cuestionarioEmpleadoId), success, error);
    }

    function showCuestionarioGestion(empleadoId) {
        let success = function (response) {

            $(_elements.modalCuestionarioGestionBody).html('');
            $(_elements.modalCuestionarioGestionBody).html(response);
            $('#modal-gestion').modal('show');
        }

        let error = function (response) {
            ajaxErrorMessage(response);
        }

        CuestionarioService.GetEstatusCuestionarioGestionView(getCuestionarioGestionViewModel(empleadoId), success, error);
    }

    function updateCuestionarioExceptionEmpleado() {

        let model = getCuestionarioGestionModel();

        let success = function (response) {

            if (!response.updateSuccess) {
                modalMessage("error", "Error", "<span>La evaluación no puede ser enviada a revisión</span><br /><span>Debes calificar todos los objetivos</span><br /><span>Describir el resultado del objetivo</span><br /><span>La ponderación (peso) de los objetivos debe sumar 100</span>");

            }
            else {
                toastr.success("¡La información ha sido guardada correctamente!");
                TablesController.ReloadGrid(_elements.gridColaboradores);
                $('#modal-gestion').modal('hide');
            }
        }

        let error = function (response) {
            ajaxErrorMessage(response);
        }

        CuestionarioService.UpdateCuestionarioConsideracionEmpleado(model, success, error);
    }

    function showDetalleDesempenioOKR(empleadoId) {
        let success = function (response) {

            $(_elements.divModalBodyOKR).html('');
            $(_elements.divModalBodyOKR).html(response);
            $(_elements.modalDetalleOKR).modal('show');
        }

        let error = function (response) {
            ajaxErrorMessage(response);
            Loading.Hide();
        }

        ColaboradoresService.GetDetalleDesempenioOKRView(getCuestionarioGestionViewModel(empleadoId), success, error);
    }

    let QueryColaborador = function () {
        return {
            query: $(_elements.txtQuery).val(),
        };
    };

    let OnDataBoundColaborador = function (e) {
        tippy('.btn-seguimiento', { theme: "light", animation: "scale", placement: "right", inertia: true });
        tippy(".btn-comentarios", { theme: "light", animation: "scale", placement: "right", inertia: true });
        tippy(".btn-detalleOKRS", { theme: "light", animation: "scale", placement: "right", inertia: true });

        $(_elements.btnDetalleOKR).on('click', function (e) {
            e.preventDefault();

            let empleadoId = $(this).attr(_dataAttributes.empleadoId);

            showDetalleDesempenioOKR(empleadoId);
        });
    };

    return {
        InitController,
        InitColaboradoresGestionController,
        InitCuestionarioGestion,
        QueryColaborador,
        OnDataBoundColaborador
    }
}();