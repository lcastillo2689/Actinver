﻿const TablesController = (function () {
    let _toggleSelector = {
        togg: "Collapse",
        grid: "",
        icon: "",
        text: "",
        button: "",
    };

    const reloadGrid = function (gridSelector) {
        const grid = $(gridSelector).data("kendoGrid");
        if (grid) grid.dataSource.read();
    };

    const getData = function (gridSelector) {
        const grid = $(gridSelector).data("kendoGrid");
        return grid.dataSource.data();
    };

    const getDataSource = function (gridSelector) {
        const grid = $(gridSelector).data("kendoGrid");
        return grid.dataSource;
    };

    const setRightPage = function (gridSelector) {
        const grid = $(gridSelector).data("kendoGrid").dataSource;
        const page = grid.page();
        const totalPages = grid.totalPages();

        if (page > totalPages && totalPages > 0) grid.page(1);
    };

    const getAttributeInGrid = function (e, gridName, attribute) {
        const grid = $(gridName).data("kendoGrid");
        const dataItem = grid.dataItem(e.target.parentNode) || grid.dataItem(e.target.parentNode.parentNode);

        const properties = attribute.split(".");
        let navigationProperty = dataItem[properties[0]];

        for (let i = 1; i < properties.length; i++) navigationProperty = navigationProperty[properties[i]];

        return navigationProperty;
    };

    const setCellTooltip = function (elementClass, cellClass) {
        $("." + elementClass).map(function (i, obj) {
            const msg = $(obj).attr("data-original-title");

            $(obj).closest("td").addClass(cellClass);
            $(obj).closest("td").attr("data-container", "body");
            $(obj).closest("td").attr("data-placement", "top");
            $(obj).closest("td").attr("data-original-title", msg);
        });

        $("." + cellClass).tooltip();
        $("." + cellClass).on("show.bs.tooltip", function () {
            if (this && this.scrollWidth <= this.clientWidth) return false;
        });
    };

    const ToolTipClientTemplate = function (field) {
        let template = "";
        if (field) {
            template = "<span class='tooltipCell' data-container='body' data-placement='top' data-original-title='" + field + "'>" + field + "</span>";
        }
        return template;
    };

    const getGridCount = function (gridNameSelector) {
        const grid = $(gridNameSelector).data("kendoGrid");
        const dataSource = grid.dataSource;
        return dataSource.total();
    };

    const resizeGrid = function (gridSelector, rowHeight, extraContent, adJustPageSize = true) {
        const gridElement = $(gridSelector);
        const dataArea = gridElement.find(".k-grid-content");
        const otherElements = gridElement.children().not(".k-grid-content");

        extraContent = extraContent || 0;

        let otherElementsHeight = 0;
        otherElements.map(function (i, obj) {
            otherElementsHeight += $(obj).outerHeight();
        });

        const height = window.innerHeight;
        let newHeight = height - otherElementsHeight - 150 - extraContent;
        let containerHeight = newHeight + 20;

        $(gridSelector).css("height", containerHeight + "px");

        dataArea.height(newHeight);
        if (adJustPageSize) {
            adjustPageSize(gridSelector, rowHeight);
        }
    };

    const adjustPageSize = function (gridSelector, rowHeight, reloadData = true) {
        const gridElement = $(gridSelector);

        gridElement.data("kendoGrid").resize();

        const newHeight = gridElement.height();

        const headerHeight = $(".k-grid-header").height();
        const pagerHeight = $(".k-grid-pager").height();
        const footerHeigt = $(".k-grid-footer").height();
        rowHeight = rowHeight || 44;

        let numberOfRows = (newHeight - headerHeight - pagerHeight - footerHeigt - rowHeight * 2) / rowHeight;
        numberOfRows = Math.round(numberOfRows % 1 < 0.3 ? numberOfRows + 1 : numberOfRows);

        if (reloadData) {
            gridElement.data("kendoGrid").dataSource.pageSize(numberOfRows);
        }
    };

    const resizeGridAgrupado = function (gridSelector, extraContent) {
        const gridElement = $(gridSelector);
        const dataArea = gridElement.find(".k-grid-content");
        const otherElements = gridElement.children().not(".k-grid-content");
        extraContent = extraContent || 0;

        let otherElementsHeight = 0;
        otherElements.map(function (i, obj) {
            otherElementsHeight += $(obj).outerHeight();
        });
        otherElementsHeight = otherElementsHeight === 0 ? 79 : otherElementsHeight;

        const height = window.innerHeight;
        let newHeight = height - otherElementsHeight - 180 - extraContent;
        newHeight = newHeight < 150 ? 150 : newHeight;
        let containerHeight = newHeight + 80;

        $(gridSelector).css("height", containerHeight + "px");

        dataArea.height(newHeight);
        adjustPageSize(gridSelector, 50, false);
    };

    const onFilterMenuInit = function (e) {
        var ddl = e.container.find("select[data-role='dropdownlist']").data("kendoDropDownList");
        if (ddl) {
            ddl.value("contains");
            ddl.trigger("change");
        }
    };

    const TooltipTemplate = function (value) {
        return value ? `<span class='tooltipCell' data-container='body' data-placement='top' data-original-title='${value}'>${value}</span>` : "";
    };

    const InitializeGridGroupToggle = function (gridSelector, btnAccionSelector, iconSelector, textSelector) {
        _toggleSelector.grid = gridSelector;
        _toggleSelector.button = btnAccionSelector;
        _toggleSelector.icon = iconSelector;
        _toggleSelector.text = textSelector;
        $(_toggleSelector.button).click(toggleGroup);
    };

    const toggleGroup = function (e) {
        if (e.type !== "keypress" || kendo.keys.ENTER === e.keyCode) {
            var grid = $(_toggleSelector.grid).data("kendoGrid"),
                rows = grid.tbody.find(">tr.k-grouping-row");

            rows.each(function (e) {
                if (_toggleSelector.togg === "Collapse") {
                    grid.collapseGroup(this);
                } else {
                    grid.expandGroup(this);
                }
            });

            if (_toggleSelector.togg === "Collapse") {
                _toggleSelector.togg = "Expand";
                $(_toggleSelector.text).text("Expandir");
                $(_toggleSelector.icon).removeClass("fa-compress");
                $(_toggleSelector.icon).addClass("fa-expand");
            } else {
                _toggleSelector.togg = "Collapse";
                $(_toggleSelector.text).text("Colapsar");
                $(_toggleSelector.icon).removeClass("fa-expand");
                $(_toggleSelector.icon).addClass("fa-compress");
            }
        }
    };

    const highlightNegativeAmount = function (e, grid, columnNames, className) {
        const indexes = {};

        columnNames.forEach((columnName) => {
            const selector = `.k-grid-header [data-field="${columnName}"]`;
            const index = grid.wrapper.find(selector).index();
            indexes[columnName] = index;
        });

        const rows = e.sender.tbody.children();
        for (let tr of rows) {
            const row = $(tr);
            const dataItem = e.sender.dataItem(row);
            if (!dataItem) continue;

            for (let columnName of columnNames) {
                let value = dataItem.get(columnName);
                if (value < 0) {
                    let columnIndex = indexes[columnName];
                    let cell = row.context.children[columnIndex];
                    $(cell).addClass(className);
                }
            }
        }
    };

    return {
        ReloadGrid: reloadGrid,
        GetAttributeInGrid: getAttributeInGrid,
        SetCellTooltip: setCellTooltip,
        ResizeGrid: resizeGrid,
        SetRightPage: setRightPage,
        GetGridCount: getGridCount,
        OnFitlerMenuInit: onFilterMenuInit,
        AdjustPageSize: adjustPageSize,
        ResizeGridAgrupado: resizeGridAgrupado,
        TooltipTemplate,
        InitializeGridGroupToggle,
        ToolTipClientTemplate,
        GetData: getData,
        GetDataSource: getDataSource,
        HighlightNegativeAmount: highlightNegativeAmount,
    };
})();
