WowRating.addShape('HeartRed',
'<svg id="Warstwa_2" data-name="Warstwa 2" xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100"><path id="heart" d="M50.07,20.2l-4.3-4.3A25.47,25.47,0,0,0,10,15.8a25.23,25.23,0,0,0,0,35.6l4.3,4.3,35.8,35.8,35.6-35.6,4.4-4.4a25.17,25.17,0,1,0-35.6-35.6Z" fill="#c24849"/></svg>'
);
